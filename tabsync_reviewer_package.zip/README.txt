TabSyncBridge Reviewer Package

Contents:
- extension/: unpacked Chromium extension files.
- desktop-host/: native messaging bridge installer and runtime files.

Chrome/Chromium extension review:
1. Open chrome://extensions.
2. Enable Developer mode.
3. Choose Load unpacked.
4. Select the extension directory from this package.

Native messaging host setup:
1. Open a terminal in the desktop-host directory.
2. Run: node install.js --extension-id jokabacndcaecbfdmocicakhlhibjeab
3. Restart the browser after installation.

The installer writes OS-specific native messaging manifests with absolute paths for the reviewer machine.
Do not edit the sync port; TabSyncBridge uses local port 53317.
