'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');
const zlib = require('node:zlib');

const ZIP_LOCAL_FILE_HEADER_SIGNATURE = 0x04034b50;
const ZIP_CENTRAL_DIRECTORY_SIGNATURE = 0x02014b50;
const ZIP_END_OF_CENTRAL_DIRECTORY_SIGNATURE = 0x06054b50;
const COMPRESSION_METHOD_DEFLATE = 8;
const VERSION_NEEDED = 20;
const DEFAULT_EXTENSION_ID = 'jokabacndcaecbfdmocicakhlhibjeab';
const EXTENSION_ID_PATTERN = /^[a-p]{32}$/;

function configuredExtensionIDs(argv = process.argv.slice(2), env = process.env) {
  const candidates = [];

  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (argument === '--extension-id' && argv[index + 1]) {
      candidates.push(argv[index + 1]);
      index += 1;
    } else if (argument.startsWith('--extension-id=')) {
      candidates.push(argument.slice('--extension-id='.length));
    }
  }

  if (env.TABSYNC_EXTENSION_IDS) {
    candidates.push(env.TABSYNC_EXTENSION_IDS);
  }
  if (env.TABSYNC_EXTENSION_ID) {
    candidates.push(env.TABSYNC_EXTENSION_ID);
  }

  const ids = candidates
    .flatMap((candidate) => String(candidate).split(/[,\s]+/))
    .map((candidate) => candidate.trim().toLowerCase())
    .filter(Boolean);
  const uniqueIDs = [...new Set(ids.filter((candidate) => EXTENSION_ID_PATTERN.test(candidate)))];
  return uniqueIDs.length > 0 ? uniqueIDs : [DEFAULT_EXTENSION_ID];
}

async function collectFiles(rootDirectory) {
  const entries = await fs.readdir(rootDirectory, { withFileTypes: true });
  const files = [];

  for (const entry of entries) {
    const absolutePath = path.join(rootDirectory, entry.name);
    if (entry.isDirectory()) {
      files.push(...await collectFiles(absolutePath));
    } else if (entry.isFile()) {
      files.push(absolutePath);
    }
  }

  return files.sort();
}

async function buildEntries(rootDirectory, prefix = '', includeFile = () => true) {
  const absoluteRoot = path.resolve(rootDirectory);
  const files = await collectFiles(absoluteRoot);
  const entries = [];

  for (const absolutePath of files) {
    if (!includeFile(absolutePath)) {
      continue;
    }
    const stat = await fs.stat(absolutePath);
    const source = await fs.readFile(absolutePath);
    const relativePath = path.relative(absoluteRoot, absolutePath).split(path.sep).join('/');
    entries.push(makeZipEntry(`${prefix}${relativePath}`, source, stat.mtime));
  }

  return entries;
}

async function buildExtensionEntries(rootDirectory, prefix = '') {
  return buildEntries(rootDirectory, prefix);
}

async function buildHostEntries(rootDirectory, prefix = '') {
  return buildEntries(
    rootDirectory,
    prefix,
    (absolutePath) => path.extname(absolutePath) !== '.zip'
  );
}

function createCRCTable() {
  const table = new Uint32Array(256);
  for (let index = 0; index < 256; index += 1) {
    let value = index;
    for (let bit = 0; bit < 8; bit += 1) {
      value = (value & 1) !== 0 ? (0xedb88320 ^ (value >>> 1)) : (value >>> 1);
    }
    table[index] = value >>> 0;
  }
  return table;
}

const CRC_TABLE = createCRCTable();

function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) {
    crc = CRC_TABLE[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function toDosDateTime(date) {
  const year = Math.max(date.getFullYear(), 1980);
  const dosTime = ((date.getHours() & 0x1f) << 11)
    | ((date.getMinutes() & 0x3f) << 5)
    | Math.floor(date.getSeconds() / 2);
  const dosDate = (((year - 1980) & 0x7f) << 9)
    | (((date.getMonth() + 1) & 0x0f) << 5)
    | (date.getDate() & 0x1f);
  return { dosTime, dosDate };
}

function makeZipEntry(relativePath, source, modifiedAt = new Date()) {
  const compressed = zlib.deflateRawSync(source);
  const name = Buffer.from(relativePath, 'utf8');
  const { dosTime, dosDate } = toDosDateTime(modifiedAt);

  return {
    name,
    source,
    compressed,
    crc: crc32(source),
    dosTime,
    dosDate
  };
}

function buildZip(entries) {
  const localChunks = [];
  const centralChunks = [];
  let offset = 0;

  for (const entry of entries) {
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(ZIP_LOCAL_FILE_HEADER_SIGNATURE, 0);
    localHeader.writeUInt16LE(VERSION_NEEDED, 4);
    localHeader.writeUInt16LE(0, 6);
    localHeader.writeUInt16LE(COMPRESSION_METHOD_DEFLATE, 8);
    localHeader.writeUInt16LE(entry.dosTime, 10);
    localHeader.writeUInt16LE(entry.dosDate, 12);
    localHeader.writeUInt32LE(entry.crc, 14);
    localHeader.writeUInt32LE(entry.compressed.length, 18);
    localHeader.writeUInt32LE(entry.source.length, 22);
    localHeader.writeUInt16LE(entry.name.length, 26);
    localHeader.writeUInt16LE(0, 28);

    localChunks.push(localHeader, entry.name, entry.compressed);

    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(ZIP_CENTRAL_DIRECTORY_SIGNATURE, 0);
    centralHeader.writeUInt16LE(VERSION_NEEDED, 4);
    centralHeader.writeUInt16LE(VERSION_NEEDED, 6);
    centralHeader.writeUInt16LE(0, 8);
    centralHeader.writeUInt16LE(COMPRESSION_METHOD_DEFLATE, 10);
    centralHeader.writeUInt16LE(entry.dosTime, 12);
    centralHeader.writeUInt16LE(entry.dosDate, 14);
    centralHeader.writeUInt32LE(entry.crc, 16);
    centralHeader.writeUInt32LE(entry.compressed.length, 20);
    centralHeader.writeUInt32LE(entry.source.length, 24);
    centralHeader.writeUInt16LE(entry.name.length, 28);
    centralHeader.writeUInt16LE(0, 30);
    centralHeader.writeUInt16LE(0, 32);
    centralHeader.writeUInt16LE(0, 34);
    centralHeader.writeUInt16LE(0, 36);
    centralHeader.writeUInt32LE(0, 38);
    centralHeader.writeUInt32LE(offset, 42);

    centralChunks.push(centralHeader, entry.name);
    offset += localHeader.length + entry.name.length + entry.compressed.length;
  }

  const centralDirectoryOffset = offset;
  const centralDirectory = Buffer.concat(centralChunks);
  const localData = Buffer.concat(localChunks);
  const endRecord = Buffer.alloc(22);

  endRecord.writeUInt32LE(ZIP_END_OF_CENTRAL_DIRECTORY_SIGNATURE, 0);
  endRecord.writeUInt16LE(0, 4);
  endRecord.writeUInt16LE(0, 6);
  endRecord.writeUInt16LE(entries.length, 8);
  endRecord.writeUInt16LE(entries.length, 10);
  endRecord.writeUInt32LE(centralDirectory.length, 12);
  endRecord.writeUInt32LE(centralDirectoryOffset, 16);
  endRecord.writeUInt16LE(0, 20);

  return Buffer.concat([localData, centralDirectory, endRecord]);
}

function makeReviewerReadme(extensionIDs) {
  return [
    'TabSyncBridge Reviewer Package',
    '',
    'Contents:',
    '- extension/: unpacked Chromium extension files.',
    '- desktop-host/: native messaging bridge installer and runtime files.',
    '',
    'Chrome/Chromium extension review:',
    '1. Open chrome://extensions.',
    '2. Enable Developer mode.',
    '3. Choose Load unpacked.',
    '4. Select the extension directory from this package.',
    '',
    'Native messaging host setup:',
    '1. Open a terminal in the desktop-host directory.',
    `2. Run: node install.js --extension-id ${extensionIDs.join(',')}`,
    '3. Restart the browser after installation.',
    '',
    'The installer writes OS-specific native messaging manifests with absolute paths for the reviewer machine.',
    'Do not edit the sync port; TabSyncBridge uses local port 53317.',
    ''
  ].join('\n');
}

async function main() {
  const extensionDirectory = path.resolve(__dirname, '..', 'Extension');
  const extensionIDs = configuredExtensionIDs();
  const extensionOutputFile = path.resolve(__dirname, 'tabsync_ext.zip');
  const reviewerOutputFile = path.resolve(__dirname, 'tabsync_reviewer_package.zip');

  const extensionArchive = buildZip(await buildExtensionEntries(extensionDirectory));
  await fs.writeFile(extensionOutputFile, extensionArchive);

  const reviewerEntries = [
    makeZipEntry('README.txt', Buffer.from(makeReviewerReadme(extensionIDs), 'utf8')),
    ...await buildExtensionEntries(extensionDirectory, 'extension/'),
    ...await buildHostEntries(__dirname, 'desktop-host/')
  ];
  const reviewerArchive = buildZip(reviewerEntries);
  await fs.writeFile(reviewerOutputFile, reviewerArchive);

  process.stdout.write(`${extensionOutputFile}\n${reviewerOutputFile}\n`);
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exitCode = 1;
});
