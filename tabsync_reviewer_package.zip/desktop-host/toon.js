'use strict';

function escapeTOONValue(value) {
  return String(value ?? '')
    .replace(/\\/g, '\\\\')
    .replace(/\t/g, '\\t')
    .replace(/\n/g, '\\n');
}

function unescapeTOONValue(value) {
  let output = '';
  let escaping = false;

  for (const character of String(value ?? '')) {
    if (!escaping) {
      if (character === '\\') {
        escaping = true;
      } else {
        output += character;
      }
      continue;
    }

    if (character === 't') {
      output += '\t';
    } else if (character === 'n') {
      output += '\n';
    } else {
      output += character;
    }

    escaping = false;
  }

  return output;
}

function encodeTOON(name, header, rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  const lines = [`${name}[${safeRows.length}]{${header.join(',')}}:`];

  for (const row of safeRows) {
    const values = Array.isArray(row)
      ? row
      : header.map((column) => row?.[column] ?? '');
    lines.push(header.map((_, index) => escapeTOONValue(values[index] ?? '')).join('\t'));
  }

  return lines.join('\n');
}

function decodeTOON(payload) {
  if (typeof payload !== 'string' || payload.trim().length === 0) {
    return null;
  }

  const lines = payload.replace(/\r\n/g, '\n').split('\n');
  const headerLine = lines.shift() || '';
  const match = /^([A-Za-z0-9_]+)\[(\d+)\]\{([^}]*)\}:$/.exec(headerLine.trim());
  if (!match) {
    return null;
  }

  const [, name, countLiteral, headerLiteral] = match;
  const header = headerLiteral
    .split(',')
    .map((column) => column.trim())
    .filter(Boolean);
  const rowCount = Number.parseInt(countLiteral, 10) || 0;
  const rows = lines
    .slice(0, rowCount)
    .map((line) => line.split('\t').map(unescapeTOONValue));

  return {
    name,
    header,
    rows,
    indexByHeader: Object.fromEntries(header.map((column, index) => [column, index]))
  };
}

function toonValue(table, row, column, aliases = []) {
  for (const key of [column, ...aliases]) {
    const index = table?.indexByHeader?.[key];
    if (index != null && row?.[index] != null) {
      return row[index];
    }
  }

  return '';
}

module.exports = {
  escapeTOONValue,
  unescapeTOONValue,
  encodeTOON,
  decodeTOON,
  toonValue
};
