'use strict';

const { BridgeRuntime } = require('./bridge_runtime');

const MAX_NATIVE_MESSAGE_BYTES = 1024 * 1024;

let nativeBuffer = Buffer.alloc(0);
let runtime = null;

function writeNativeMessage(message) {
  const payload = Buffer.from(JSON.stringify(message), 'utf8');
  const header = Buffer.alloc(4);
  header.writeUInt32LE(payload.length, 0);
  process.stdout.write(header);
  process.stdout.write(payload);
}

async function initializeRuntime() {
  runtime = new BridgeRuntime();
  try {
    await runtime.start();
    writeNativeMessage(runtime.startupMessage());
  } catch (error) {
    writeNativeMessage({
      type: 'HOST_READY',
      ok: false,
      bridge_ready: false,
      bridge_state: 'error',
      bridge_message: error?.message || 'bridge_start_failed'
    });
  }
}

function consumeNativeMessages(chunk) {
  nativeBuffer = Buffer.concat([nativeBuffer, chunk]);

  while (nativeBuffer.length >= 4) {
    const payloadLength = nativeBuffer.readUInt32LE(0);
    if (payloadLength > MAX_NATIVE_MESSAGE_BYTES) {
      writeNativeMessage({
        type: 'HOST_ERROR',
        ok: false,
        error: `native_message_too_large:${payloadLength}`
      });
      process.exit(1);
    }

    const totalLength = 4 + payloadLength;
    if (nativeBuffer.length < totalLength) {
      return;
    }

    const payload = nativeBuffer.subarray(4, totalLength);
    nativeBuffer = nativeBuffer.subarray(totalLength);

    let message;
    try {
      message = JSON.parse(payload.toString('utf8'));
    } catch (error) {
      writeNativeMessage({
        type: 'HOST_ERROR',
        ok: false,
        error: error?.message || 'native_message_rejected'
      });
      continue;
    }

    Promise.resolve(runtime.handleNativeMessage(message))
      .then((response) => writeNativeMessage(response))
      .catch((error) => writeNativeMessage({
        type: 'HOST_ERROR',
        request_id: String(message?.request_id || ''),
        ok: false,
        error: error?.message || 'runtime_command_failed'
      }));
  }
}

async function shutdown() {
  try {
    if (runtime) {
      await runtime.stop();
    }
  } finally {
    process.exit(0);
  }
}

process.stdin.on('data', consumeNativeMessages);
process.stdin.on('end', () => {
  void shutdown();
});
process.stdin.on('error', (error) => {
  writeNativeMessage({
    type: 'HOST_ERROR',
    ok: false,
    error: error?.message || 'stdin_error'
  });
});
process.on('SIGINT', () => {
  void shutdown();
});
process.on('SIGTERM', () => {
  void shutdown();
});
process.stdin.resume();

void initializeRuntime();
