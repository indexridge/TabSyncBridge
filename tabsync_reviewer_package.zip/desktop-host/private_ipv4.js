'use strict';

const os = require('node:os');

function normalizeIPv4(address) {
  const value = String(address || '').trim().replace(/^::ffff:/, '');
  const match = /(\d{1,3}(?:\.\d{1,3}){3})$/.exec(value);
  return match ? match[1] : '';
}

function isPrivateIPv4(address) {
  const normalized = normalizeIPv4(address);
  return /^10\./.test(normalized)
    || /^192\.168\./.test(normalized)
    || /^172\.(1[6-9]|2\d|3[01])\./.test(normalized);
}

function isAPIPALike(address) {
  return /^169\.254\./.test(normalizeIPv4(address));
}

function ipv4ToInt(address) {
  return normalizeIPv4(address)
    .split('.')
    .reduce((value, part) => ((value << 8) | (Number.parseInt(part, 10) & 0xff)) >>> 0, 0);
}

function intToIPv4(value) {
  return [
    (value >>> 24) & 0xff,
    (value >>> 16) & 0xff,
    (value >>> 8) & 0xff,
    value & 0xff
  ].join('.');
}

function broadcastAddress(address, netmask) {
  const normalizedAddress = normalizeIPv4(address);
  const normalizedNetmask = normalizeIPv4(netmask);
  if (!normalizedAddress || !normalizedNetmask) {
    return '';
  }

  const addressValue = ipv4ToInt(normalizedAddress);
  const maskValue = ipv4ToInt(normalizedNetmask);
  const broadcastValue = (addressValue & maskValue) | (~maskValue >>> 0);
  return intToIPv4(broadcastValue >>> 0);
}

function prefixLengthFromNetmask(netmask) {
  const normalized = normalizeIPv4(netmask);
  if (!normalized) {
    return 24;
  }

  return normalized
    .split('.')
    .map((part) => Number.parseInt(part, 10).toString(2).padStart(8, '0'))
    .join('')
    .replace(/0+$/, '')
    .length;
}

function enumeratePrivateInterfaces() {
  const interfaces = os.networkInterfaces();
  const results = [];

  for (const [interfaceName, entries] of Object.entries(interfaces)) {
    for (const entry of entries || []) {
      const family = entry.family === 4 || entry.family === 'IPv4' ? 'IPv4' : String(entry.family || '');
      const address = normalizeIPv4(entry.address);
      if (family !== 'IPv4' || !address || entry.internal || !isPrivateIPv4(address) || isAPIPALike(address)) {
        continue;
      }

      results.push({
        interfaceName,
        address,
        netmask: normalizeIPv4(entry.netmask),
        prefixLength: prefixLengthFromNetmask(entry.netmask),
        broadcast: broadcastAddress(entry.address, entry.netmask)
      });
    }
  }

  return results.sort((left, right) => left.address.localeCompare(right.address));
}

function enumerateScanTargets(options = {}) {
  const includeSelf = options.includeSelf !== false;
  const maxHostsPerInterface = Number.isInteger(options.maxHostsPerInterface)
    ? Math.max(16, options.maxHostsPerInterface)
    : 256;
  const seen = new Set();
  const targets = [];

  for (const entry of enumeratePrivateInterfaces()) {
    const effectivePrefix = Math.max(entry.prefixLength, 24);
    const networkMask = effectivePrefix === 0
      ? 0
      : (0xffffffff << (32 - effectivePrefix)) >>> 0;
    const networkBase = ipv4ToInt(entry.address) & networkMask;
    const hostCount = Math.min(Math.max(1, (2 ** (32 - effectivePrefix)) - 2), maxHostsPerInterface);

    if (includeSelf && !seen.has(entry.address)) {
      seen.add(entry.address);
      targets.push(entry.address);
    }

    for (let offset = 1; offset <= hostCount; offset += 1) {
      const candidate = intToIPv4((networkBase + offset) >>> 0);
      if (!candidate || (!includeSelf && candidate === entry.address) || seen.has(candidate)) {
        continue;
      }

      seen.add(candidate);
      targets.push(candidate);
    }
  }

  return targets;
}

module.exports = {
  normalizeIPv4,
  isPrivateIPv4,
  ipv4ToInt,
  intToIPv4,
  broadcastAddress,
  enumeratePrivateInterfaces,
  enumerateScanTargets
};
