'use strict';

const crypto = require('node:crypto');
const fs = require('node:fs/promises');
const http = require('node:http');
const os = require('node:os');
const path = require('node:path');
const { encodeTOON, decodeTOON, toonValue } = require('./toon');
const { enumeratePrivateInterfaces, normalizeIPv4, isPrivateIPv4, ipv4ToInt } = require('./private_ipv4');
const { UDPDiscoveryService } = require('./udp_discovery');

const DEFAULT_PORT = 53317;
const DEFAULT_PROTOCOL_VERSION = 'tabsync.lan.v2';
const STATUS_PATH = '/v1/status';
const DISCOVERY_PATH = '/v1/discover';
const PAIR_PATH = '/v1/pair';
const WS_PATH = '/bridge';
const SESSION_TTL_MS = Number.parseInt(process.env.TABSYNC_SESSION_TTL_MS || `${24 * 60 * 60 * 1000}`, 10);
const CHALLENGE_TTL_MS = Number.parseInt(process.env.TABSYNC_CHALLENGE_TTL_MS || '20000', 10);
const SCAN_TIMEOUT_MS = Number.parseInt(process.env.TABSYNC_SCAN_TIMEOUT_MS || '350', 10);
const PENDING_ACTION_TTL_MS = Number.parseInt(process.env.TABSYNC_PENDING_ACTION_TTL_MS || `${10 * 60 * 1000}`, 10);
const MAX_PENDING_ACTIONS = 128;
const MAX_HTTP_BODY_BYTES = 64 * 1024;
const MAX_WS_FRAME_BYTES = 512 * 1024;
const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

function currentTimestamp() {
  return new Date().toISOString();
}

function parseTimestampMillis(rawValue) {
  const trimmed = String(rawValue || '').trim();
  if (!trimmed) {
    return 0;
  }

  const parsed = Date.parse(trimmed);
  return Number.isFinite(parsed) ? parsed : 0;
}

function remoteActionRequestedAtMillis(payload) {
  const table = decodeTOON(String(payload || ''));
  if (!table || table.name !== 'remote_tab_action') {
    return 0;
  }

  return parseTimestampMillis(toonValue(table, table.rows?.[0] || [], 'requested_at', ['requestedAt', 'created_at']));
}

function pendingActionExpiresAt(payload) {
  const now = Date.now();
  const requestedAtMillis = remoteActionRequestedAtMillis(payload);
  if (requestedAtMillis > 0 && now - requestedAtMillis > PENDING_ACTION_TTL_MS) {
    return '';
  }

  const baseMillis = requestedAtMillis > 0 ? requestedAtMillis : now;
  const expiresAtMillis = Math.min(baseMillis + PENDING_ACTION_TTL_MS, now + PENDING_ACTION_TTL_MS);
  return expiresAtMillis > now ? new Date(expiresAtMillis).toISOString() : '';
}

function pendingActionIsFresh(item) {
  const now = Date.now();
  const expiresAtMillis = parseTimestampMillis(item?.expiresAt);
  if (expiresAtMillis > 0 && expiresAtMillis <= now) {
    return false;
  }

  const actionTimestampMillis = remoteActionRequestedAtMillis(item?.payload) || parseTimestampMillis(item?.createdAt);
  return !actionTimestampMillis || now - actionTimestampMillis <= PENDING_ACTION_TTL_MS;
}

function isSyncableTabURL(rawValue) {
  const trimmed = String(rawValue || '').trim();
  if (!trimmed) {
    return false;
  }

  try {
    const url = new URL(trimmed);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (_) {
    return false;
  }
}

function randomID() {
  return crypto.randomUUID();
}

function toBase64URL(value) {
  return Buffer.from(value)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/g, '');
}

function fromBase64URL(value) {
  const normalized = String(value || '')
    .replace(/-/g, '+')
    .replace(/_/g, '/');
  const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
  return Buffer.from(padded, 'base64');
}

function createPairingKey(pairingCode, serverNonce, clientNonce) {
  return crypto
    .createHash('sha256')
    .update(`tabsync-aes128|${String(pairingCode || '')}|${String(serverNonce || '')}|${String(clientNonce || '')}`, 'utf8')
    .digest()
    .subarray(0, 16);
}

function encryptPayload(key, payload) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-128-gcm', key, iv);
  const plaintext = Buffer.from(JSON.stringify(payload), 'utf8');
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const tag = cipher.getAuthTag();

  return {
    iv: toBase64URL(iv),
    ciphertext: toBase64URL(encrypted),
    tag: toBase64URL(tag)
  };
}

function decryptPayload(key, envelope) {
  const decipher = crypto.createDecipheriv('aes-128-gcm', key, fromBase64URL(envelope.iv));
  decipher.setAuthTag(fromBase64URL(envelope.tag));
  const plaintext = Buffer.concat([
    decipher.update(fromBase64URL(envelope.ciphertext)),
    decipher.final()
  ]);
  return JSON.parse(plaintext.toString('utf8'));
}

function corsHeaders(extraHeaders = {}) {
  return {
    'access-control-allow-origin': '*',
    'access-control-allow-methods': 'GET, POST, OPTIONS',
    'access-control-allow-headers': 'content-type',
    'cache-control': 'no-store',
    ...extraHeaders
  };
}

function writeJSON(response, statusCode, payload) {
  response.writeHead(statusCode, corsHeaders({
    'content-type': 'application/json; charset=utf-8'
  }));
  response.end(JSON.stringify(payload));
}

async function readJSONRequest(request) {
  const chunks = [];
  let length = 0;

  for await (const chunk of request) {
    length += chunk.length;
    if (length > MAX_HTTP_BODY_BYTES) {
      throw new Error('request_body_too_large');
    }
    chunks.push(chunk);
  }

  const body = Buffer.concat(chunks).toString('utf8').trim();
  return body ? JSON.parse(body) : {};
}

function createAcceptValue(key) {
  return crypto.createHash('sha1').update(key + WS_GUID, 'utf8').digest('base64');
}

function encodeFrame(opcode, payload) {
  const body = Buffer.isBuffer(payload) ? payload : Buffer.from(payload, 'utf8');
  const header = [];
  header.push(0x80 | (opcode & 0x0f));

  if (body.length < 126) {
    header.push(body.length);
  } else if (body.length < 65536) {
    header.push(126);
    const length = Buffer.alloc(2);
    length.writeUInt16BE(body.length, 0);
    header.push(...length);
  } else {
    header.push(127);
    const length = Buffer.alloc(8);
    length.writeBigUInt64BE(BigInt(body.length), 0);
    header.push(...length);
  }

  return Buffer.concat([Buffer.from(header), body]);
}

function parseFrames(buffer) {
  const frames = [];
  let cursor = 0;

  while (buffer.length - cursor >= 2) {
    const firstByte = buffer[cursor];
    const secondByte = buffer[cursor + 1];
    const opcode = firstByte & 0x0f;
    const masked = (secondByte & 0x80) !== 0;
    let offset = cursor + 2;
    let length = secondByte & 0x7f;

    if (length === 126) {
      if (buffer.length - cursor < 4) {
        break;
      }
      length = buffer.readUInt16BE(cursor + 2);
      offset = cursor + 4;
    } else if (length === 127) {
      if (buffer.length - cursor < 10) {
        break;
      }
      const longLength = buffer.readBigUInt64BE(cursor + 2);
      if (longLength > BigInt(MAX_WS_FRAME_BYTES)) {
        throw new Error('ws_frame_too_large');
      }
      length = Number(longLength);
      offset = cursor + 10;
    }

    if (length > MAX_WS_FRAME_BYTES) {
      throw new Error('ws_frame_too_large');
    }

    const maskBytes = masked ? 4 : 0;
    const frameLength = offset + maskBytes + length;
    if (buffer.length < frameLength) {
      break;
    }

    let payload = buffer.subarray(offset + maskBytes, frameLength);
    if (masked) {
      const mask = buffer.subarray(offset, offset + 4);
      const unmasked = Buffer.alloc(payload.length);
      for (let index = 0; index < payload.length; index += 1) {
        unmasked[index] = payload[index] ^ mask[index % 4];
      }
      payload = unmasked;
    }

    frames.push({ opcode, payload });
    cursor = frameLength;
  }

  return { frames, remainder: buffer.subarray(cursor) };
}

function closeSocket(socket, code, reason) {
  const reasonBytes = Buffer.from(String(reason || ''), 'utf8');
  const payload = Buffer.alloc(2 + reasonBytes.length);
  payload.writeUInt16BE(code, 0);
  reasonBytes.copy(payload, 2);
  socket.write(encodeFrame(0x8, payload));
  socket.end();
}

function stateFilePath() {
  if (process.platform === 'win32') {
    const appData = process.env.APPDATA || path.join(os.homedir(), 'AppData', 'Roaming');
    return path.join(appData, 'TabSync', 'bridge_state.json');
  }

  return path.join(os.homedir(), '.tabsync', 'bridge_state.json');
}

async function ensureParentDirectory(filePath) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
}

class BridgeRuntime {
  constructor() {
    this.port = DEFAULT_PORT;
    this.protocolVersion = DEFAULT_PROTOCOL_VERSION;
    this.statusPath = STATUS_PATH;
    this.discoveryPath = DISCOVERY_PATH;
    this.pairPath = PAIR_PATH;
    this.wsPath = WS_PATH;
    this.statePath = stateFilePath();
    this.server = null;
    this.ready = false;
    this.bridgeState = 'starting';
    this.bridgeMessage = 'Starting Desktop Bridge';
    this.deviceId = randomID();
    this.bridgeId = randomID();
    this.hostName = os.hostname() || 'tabsync-bridge';
    this.pairingCode = crypto.randomInt(0, 1_000_000).toString().padStart(6, '0');
    this.pairingAnchor = {
      sessionID: '',
      manualCode: this.pairingCode,
      createdAt: '',
      expiresAt: ''
    };
    this.primaryHostIP = '';
    this.challenges = new Map();
    this.sessions = new Map();
    this.socketSessions = new Map();
    this.tabStateByOrigin = new Map();
    this.hiddenDeviceOrigins = new Set();
    this.pendingActions = [];
    this.pendingSaveTimer = null;
    this.udpDiscovery = new UDPDiscoveryService({
      port: this.port,
      protocolVersion: this.protocolVersion,
      getBridgeSnapshot: (remoteAddress) => this.discoverySnapshotFor(remoteAddress)
    });
  }

  async start() {
    await this.loadState();
    this.refreshLocalTopology();
    this.pruneExpiredState();

    if (!this.primaryHostIP) {
      throw new Error('No private IPv4 interface is available');
    }

    this.server = http.createServer((request, response) => {
      void this.handleHTTPRequest(request, response);
    });
    this.server.on('upgrade', (request, socket) => {
      this.handleUpgrade(request, socket);
    });

    await new Promise((resolve, reject) => {
      const onError = (error) => {
        this.server.off('listening', onListening);
        reject(error);
      };
      const onListening = () => {
        this.server.off('error', onError);
        resolve();
      };

      this.server.once('error', onError);
      this.server.once('listening', onListening);
      this.server.listen(this.port, '0.0.0.0');
    });

    try {
      await this.udpDiscovery.start();
    } catch (error) {
      if (this.server) {
        await new Promise((resolve) => this.server.close(() => resolve()));
        this.server = null;
      }
      throw error;
    }
    this.ready = true;
    this.bridgeState = 'ready';
    this.bridgeMessage = 'Desktop Bridge Ready';
  }

  async stop() {
    if (this.pendingSaveTimer) {
      clearTimeout(this.pendingSaveTimer);
      this.pendingSaveTimer = null;
    }

    await this.saveState();

    for (const socketState of this.socketSessions.values()) {
      try {
        socketState.socket.destroy();
      } catch (_) {
      }
    }

    if (this.server) {
      await new Promise((resolve) => this.server.close(() => resolve()));
    }

    if (this.udpDiscovery) {
      await this.udpDiscovery.stop();
    }
  }

  async loadState() {
    try {
      const raw = await fs.readFile(this.statePath, 'utf8');
      const parsed = JSON.parse(raw);
      if (typeof parsed?.deviceId === 'string' && parsed.deviceId) {
        this.deviceId = parsed.deviceId;
      }
      if (typeof parsed?.bridgeId === 'string' && parsed.bridgeId) {
        this.bridgeId = parsed.bridgeId;
      }
      if (typeof parsed?.pairingCode === 'string' && /^\d{6}$/.test(parsed.pairingCode)) {
        this.pairingCode = parsed.pairingCode;
      }
      if (typeof parsed?.pairingAnchor?.manualCode === 'string' && /^\d{6}$/.test(parsed.pairingAnchor.manualCode)) {
        this.pairingAnchor = {
          sessionID: String(parsed.pairingAnchor.sessionID || '').trim(),
          manualCode: parsed.pairingAnchor.manualCode,
          createdAt: String(parsed.pairingAnchor.createdAt || '').trim(),
          expiresAt: String(parsed.pairingAnchor.expiresAt || '').trim()
        };
        this.pairingCode = this.pairingAnchor.manualCode;
      }

      for (const session of Array.isArray(parsed?.sessions) ? parsed.sessions : []) {
        if (!session?.id || !session?.resumeToken) {
          continue;
        }
        this.sessions.set(session.id, {
          ...session,
          socket: null
        });
      }

      this.hiddenDeviceOrigins = new Set(
        (Array.isArray(parsed?.hiddenDeviceOrigins) ? parsed.hiddenDeviceOrigins : [])
          .map((item) => String(item || '').trim())
          .filter(Boolean)
      );

      for (const [originId, rows] of Object.entries(parsed?.tabStateByOrigin || {})) {
        if (!originId || !Array.isArray(rows)) {
          continue;
        }
        if (this.hiddenDeviceOrigins.has(originId)) {
          continue;
        }
        const syncableRows = rows
          .filter((row) => isSyncableTabURL(row?.url))
          .map((row) => [row.tab_id, row]);
        if (syncableRows.length > 0) {
          this.tabStateByOrigin.set(originId, new Map(syncableRows));
        }
      }

      this.pendingActions = (Array.isArray(parsed?.pendingActions) ? parsed.pendingActions : [])
        .filter((item) => item?.payload && item?.targetOriginId && pendingActionIsFresh(item))
        .slice(-MAX_PENDING_ACTIONS);
    } catch (_) {
      await this.saveState();
    }
  }

  scheduleSave() {
    if (this.pendingSaveTimer) {
      clearTimeout(this.pendingSaveTimer);
    }

    this.pendingSaveTimer = setTimeout(() => {
      this.pendingSaveTimer = null;
      void this.saveState();
    }, 120);
  }

  async saveState() {
    const payload = {
      version: 2,
      deviceId: this.deviceId,
      bridgeId: this.bridgeId,
      pairingCode: this.currentPairingCode(),
      pairingAnchor: this.pairingAnchor,
      sessions: Array.from(this.sessions.values()).map((session) => ({
        id: session.id,
        clientId: session.clientId,
        originId: session.originId,
        bridgeIP: session.bridgeIP,
        clientIP: session.clientIP,
        resumeToken: session.resumeToken,
        createdAt: session.createdAt,
        lastSeenAt: session.lastSeenAt,
        expiresAt: session.expiresAt
      })),
      tabStateByOrigin: Object.fromEntries(
        Array.from(this.tabStateByOrigin.entries()).map(([originId, rows]) => [originId, Array.from(rows.values())])
      ),
      hiddenDeviceOrigins: Array.from(this.hiddenDeviceOrigins).sort(),
      pendingActions: this.pendingActions.slice(-MAX_PENDING_ACTIONS)
    };

    await ensureParentDirectory(this.statePath);
    await fs.writeFile(this.statePath, JSON.stringify(payload, null, 2), 'utf8');
  }

  refreshLocalTopology() {
    const primary = enumeratePrivateInterfaces()[0] || null;
    this.primaryHostIP = primary?.address || '';
    if (!this.primaryHostIP) {
      this.ready = false;
      this.bridgeState = 'unavailable';
      this.bridgeMessage = 'No private IPv4 interface is available';
    }
  }

  resolveServerIP(localAddress) {
    return normalizeIPv4(localAddress) || this.primaryHostIP || enumeratePrivateInterfaces()[0]?.address || '';
  }

  normalizeClientIP(address) {
    return normalizeIPv4(address) || String(address || '').replace(/^::ffff:/, '').trim();
  }

  currentPairingCode() {
    const anchorCode = String(this.pairingAnchor?.manualCode || '').trim();
    if (/^\d{6}$/.test(anchorCode)) {
      return anchorCode;
    }

    return this.pairingCode;
  }

  pairingAnchorTOON(hostIP = this.primaryHostIP) {
    return encodeTOON(
      'pairing_anchor',
      ['bridge_id', 'device_id', 'anchor_session_id', 'manual_code', 'host_ip', 'host_port', 'issued_at', 'expires_at'],
      [[
        this.bridgeId,
        this.deviceId,
        String(this.pairingAnchor?.sessionID || ''),
        this.currentPairingCode(),
        hostIP,
        String(this.port),
        String(this.pairingAnchor?.createdAt || currentTimestamp()),
        String(this.pairingAnchor?.expiresAt || '')
      ]]
    );
  }

  applyPairingAnchor(payload = {}) {
    const manualCode = String(payload.manual_code || payload.manualCode || '').replace(/\D/g, '').slice(0, 6);
    if (manualCode.length !== 6) {
      throw new Error('invalid_pairing_anchor');
    }

    this.pairingAnchor = {
      sessionID: String(payload.anchor_session_id || payload.anchorSessionID || payload.session_id || '').trim(),
      manualCode,
      createdAt: String(payload.created_at || payload.createdAt || currentTimestamp()).trim(),
      expiresAt: String(payload.expires_at || payload.expiresAt || '').trim()
    };
    this.pairingCode = manualCode;
    this.scheduleSave();
  }

  resolveHostIPForRemote(remoteAddress) {
    const normalizedRemote = normalizeIPv4(remoteAddress);
    const interfaces = enumeratePrivateInterfaces();
    if (!normalizedRemote) {
      return interfaces[0]?.address || this.primaryHostIP || '';
    }

    const remoteValue = ipv4ToInt(normalizedRemote);
    for (const entry of interfaces) {
      const maskValue = entry.netmask ? ipv4ToInt(entry.netmask) : ((0xffffffff << (32 - entry.prefixLength)) >>> 0);
      if ((ipv4ToInt(entry.address) & maskValue) === (remoteValue & maskValue)) {
        return entry.address;
      }
    }

    return interfaces[0]?.address || this.primaryHostIP || '';
  }

  discoverySnapshotFor(remoteAddress = '') {
    const hostIP = this.resolveHostIPForRemote(remoteAddress);
    return {
      ready: this.ready,
      bridgeID: this.bridgeId,
      deviceID: this.deviceId,
      hostName: this.hostName,
      hostIP,
      port: this.port,
      websocketURL: hostIP ? `ws://${hostIP}:${this.port}${this.wsPath}` : '',
      bridgeState: this.ready ? 'ready' : this.bridgeState,
      resumeSupported: true
    };
  }

  pruneExpiredState() {
    const now = Date.now();

    for (const [challengeId, challenge] of this.challenges.entries()) {
      if ((challenge.expiresAtMS || 0) <= now) {
        this.challenges.delete(challengeId);
      }
    }

    for (const [sessionId, session] of this.sessions.entries()) {
      if ((Date.parse(session.expiresAt || '') || 0) <= now) {
        this.sessions.delete(sessionId);
      }
    }

    const previousPendingCount = this.pendingActions.length;
    this.pendingActions = this.pendingActions.filter((item) => (Date.parse(item.expiresAt || '') || 0) > now);
    if (this.pendingActions.length !== previousPendingCount) {
      this.scheduleSave();
    }
  }

  currentPairingRecord(hostIP = this.primaryHostIP) {
    const issuedAt = currentTimestamp();
    const websocketURL = hostIP ? `ws://${hostIP}:${this.port}${this.wsPath}` : '';
    const pairingCode = this.currentPairingCode();
    const pairingTOON = encodeTOON(
      'pairing',
      ['protocol', 'bridge_id', 'device_id', 'host_ip', 'host_port', 'ws_url', 'manual_code', 'secret_code', 'resume_supported', 'issued_at'],
      [[
        this.protocolVersion,
        this.bridgeId,
        this.deviceId,
        hostIP,
        String(this.port),
        websocketURL,
        pairingCode,
        pairingCode,
        'true',
        issuedAt
      ]]
    );

    return {
      bridgeID: this.bridgeId,
      deviceID: this.deviceId,
      hostIP,
      port: this.port,
      websocketURL,
      manualCode: pairingCode,
      secretCode: pairingCode,
      issuedAt,
      pairingTOON
    };
  }

  currentHostStatusTOON(hostIP = this.primaryHostIP) {
    return encodeTOON(
      'bridge_status',
      ['bridge_id', 'device_id', 'host_name', 'host_ip', 'host_port', 'bridge_state', 'resume_supported', 'session_count', 'updated_at'],
      [[
        this.bridgeId,
        this.deviceId,
        this.hostName,
        hostIP,
        String(this.port),
        this.ready ? 'ready' : this.bridgeState,
        'true',
        String(this.socketSessions.size),
        currentTimestamp()
      ]]
    );
  }

  buildNativeSnapshot(type = 'HOST_STATE') {
    const pairing = this.currentPairingRecord(this.primaryHostIP);
    return {
      type,
      ok: this.ready,
      bridge_ready: this.ready,
      bridge_state: this.ready ? 'ready' : this.bridgeState,
      bridge_message: this.ready ? 'Ready' : this.bridgeMessage,
      bridge_id: this.bridgeId,
      device_id: this.deviceId,
      host_name: this.hostName,
      host_ip: pairing.hostIP,
      local_ip: pairing.hostIP,
      host_port: pairing.port,
      port: pairing.port,
      ws_url: pairing.websocketURL,
      websocket_url: pairing.websocketURL,
      manual_code: pairing.manualCode,
      secret_code: pairing.secretCode,
      anchor_session_id: String(this.pairingAnchor?.sessionID || ''),
      pairing_anchor_toon: this.pairingAnchorTOON(pairing.hostIP),
      pairing_toon: pairing.pairingTOON,
      toon: pairing.pairingTOON,
      host_status_toon: this.currentHostStatusTOON(pairing.hostIP),
      discovery_mode: 'udp'
    };
  }

  issueDiscoveryChallenge(hostIP) {
    const challenge = {
      id: randomID(),
      serverNonce: toBase64URL(crypto.randomBytes(16)),
      hostIP,
      issuedAt: currentTimestamp(),
      expiresAtMS: Date.now() + CHALLENGE_TTL_MS
    };
    this.challenges.set(challenge.id, challenge);
    this.pruneExpiredState();
    return challenge;
  }

  async handleHTTPRequest(request, response) {
    this.pruneExpiredState();
    this.refreshLocalTopology();

    if (request.method === 'OPTIONS') {
      response.writeHead(204, corsHeaders());
      response.end();
      return;
    }

    const requestURL = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
    const hostIP = this.resolveServerIP(request.socket.localAddress);

    if (request.method === 'GET' && requestURL.pathname === this.statusPath) {
      writeJSON(response, this.ready ? 200 : 503, {
        ok: this.ready,
        protocol: this.protocolVersion,
        bridge_id: this.bridgeId,
        device_id: this.deviceId,
        host_name: this.hostName,
        host_ip: hostIP,
        host_port: this.port,
        ws_path: this.wsPath,
        bridge_state: this.ready ? 'ready' : this.bridgeState,
        resume_supported: true,
        updated_at: currentTimestamp(),
        host_status_toon: this.currentHostStatusTOON(hostIP)
      });
      return;
    }

    if (!this.ready) {
      writeJSON(response, 503, {
        ok: false,
        error: this.bridgeMessage || 'bridge_unavailable'
      });
      return;
    }

    if (request.method === 'GET' && requestURL.pathname === this.discoveryPath) {
      const challenge = this.issueDiscoveryChallenge(hostIP);
      writeJSON(response, 200, {
        ok: true,
        protocol: this.protocolVersion,
        bridge_id: this.bridgeId,
        device_id: this.deviceId,
        host_name: this.hostName,
        host_ip: hostIP,
        host_port: this.port,
        ws_path: this.wsPath,
        challenge_id: challenge.id,
        challenge_nonce: challenge.serverNonce,
        resume_supported: true,
        discovery_mode: 'udp',
        issued_at: challenge.issuedAt,
        expires_at: new Date(challenge.expiresAtMS).toISOString()
      });
      return;
    }

    if (request.method === 'POST' && requestURL.pathname === this.pairPath) {
      try {
        const payload = await readJSONRequest(request);
        const challenge = this.challenges.get(String(payload.challenge_id || ''));
        if (!challenge || challenge.expiresAtMS <= Date.now()) {
          writeJSON(response, 401, {
            ok: false,
            error: 'challenge_expired'
          });
          return;
        }

        const clientId = String(payload.client_id || '').trim();
        const clientNonce = String(payload.client_nonce || '').trim();
        if (!clientId || !clientNonce || !payload.iv || !payload.ciphertext || !payload.tag) {
          writeJSON(response, 400, {
            ok: false,
            error: 'invalid_pair_request'
          });
          return;
        }

        const key = createPairingKey(this.currentPairingCode(), challenge.serverNonce, clientNonce);
        const decrypted = decryptPayload(key, payload);
        if (decrypted?.purpose !== 'tabsync.bridge.pair.v1' || decrypted?.client_id !== clientId) {
          writeJSON(response, 401, {
            ok: false,
            error: 'pair_proof_rejected'
          });
          return;
        }
        if (decrypted?.requested_server_ip && String(decrypted.requested_server_ip).trim() !== challenge.hostIP) {
          writeJSON(response, 401, {
            ok: false,
            error: 'server_ip_binding_failed'
          });
          return;
        }

        const sessionId = randomID();
        const resumeToken = toBase64URL(crypto.randomBytes(24));
        const observedClientIP = this.normalizeClientIP(request.socket.remoteAddress);
        const expiresAt = new Date(Date.now() + SESSION_TTL_MS).toISOString();
        const session = {
          id: sessionId,
          clientId,
          originId: String(decrypted.origin_id || decrypted.device_id || clientId).trim() || clientId,
          bridgeIP: challenge.hostIP,
          clientIP: observedClientIP,
          resumeToken,
          createdAt: currentTimestamp(),
          lastSeenAt: currentTimestamp(),
          expiresAt,
          socket: null
        };
        this.sessions.set(sessionId, session);
        this.challenges.delete(challenge.id);
        this.scheduleSave();

        writeJSON(response, 200, {
          ok: true,
          session_id: sessionId,
          bridge_id: this.bridgeId,
          device_id: this.deviceId,
          ...encryptPayload(key, {
            purpose: 'tabsync.bridge.ack.v1',
            session_id: sessionId,
            resume_token: resumeToken,
            websocket_url: `ws://${challenge.hostIP}:${this.port}${this.wsPath}`,
            bound_server_ip: challenge.hostIP,
            observed_client_ip: observedClientIP,
            bridge_id: this.bridgeId,
            bridge_device_id: this.deviceId,
            issued_at: currentTimestamp(),
            expires_at: expiresAt
          })
        });
      } catch (error) {
        writeJSON(response, 400, {
          ok: false,
          error: error?.message || 'pairing_failed'
        });
      }
      return;
    }

    writeJSON(response, 404, {
      ok: false,
      error: 'not_found'
    });
  }

  handleUpgrade(request, socket) {
    this.pruneExpiredState();
    const requestURL = new URL(request.url || '/', `http://${request.headers.host || 'localhost'}`);
    const upgradeHeader = String(request.headers.upgrade || '').toLowerCase();
    const connectionHeader = String(request.headers.connection || '').toLowerCase();
    const websocketKey = request.headers['sec-websocket-key'];

    if (!this.ready || requestURL.pathname !== this.wsPath || upgradeHeader !== 'websocket' || !connectionHeader.includes('upgrade') || typeof websocketKey !== 'string') {
      socket.write('HTTP/1.1 400 Bad Request\r\nConnection: close\r\n\r\n');
      socket.destroy();
      return;
    }

    const sessionId = String(requestURL.searchParams.get('session_id') || '').trim();
    const resumeToken = String(requestURL.searchParams.get('resume_token') || '').trim();
    const clientId = String(requestURL.searchParams.get('client_id') || '').trim();
    const originId = String(requestURL.searchParams.get('origin_id') || '').trim();
    const session = this.sessions.get(sessionId);
    const observedClientIP = this.normalizeClientIP(request.socket.remoteAddress);
    const directLocalSession = !sessionId
      && !resumeToken
      && Boolean(clientId)
      && isPrivateIPv4(observedClientIP);
    const validResumableSession = Boolean(
      session
      && resumeToken
      && session.resumeToken === resumeToken
      && clientId
      && session.clientId === clientId
      && (Date.parse(session.expiresAt || '') || 0) > Date.now()
    );

    if (!validResumableSession && !directLocalSession) {
      socket.write('HTTP/1.1 401 Unauthorized\r\nConnection: close\r\n\r\n');
      socket.destroy();
      return;
    }

    const acceptValue = createAcceptValue(websocketKey);
    socket.write([
      'HTTP/1.1 101 Switching Protocols',
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Accept: ${acceptValue}`,
      '\r\n'
    ].join('\r\n'));

    if (session?.socket) {
      try {
        closeSocket(session.socket, 1012, 'session_replaced');
      } catch (_) {
      }
    }

    socket.setNoDelay(true);
    const resolvedSessionId = directLocalSession ? `direct-${randomID()}` : sessionId;
    const socketState = {
      socket,
      sessionId: resolvedSessionId,
      clientId,
      originId: originId || session?.originId || clientId,
      buffer: Buffer.alloc(0),
      directLocalSession
    };

    if (session) {
      session.originId = socketState.originId;
      session.lastSeenAt = currentTimestamp();
      session.socket = socket;
      this.scheduleSave();
    }
    this.socketSessions.set(resolvedSessionId, socketState);

    this.sendVerification(
      socketState,
      'verified',
      directLocalSession
        ? 'direct_lan'
        : crypto.createHash('sha256').update(session.resumeToken, 'utf8').digest('hex').slice(0, 12)
    );
    if (!directLocalSession) {
      this.sendSnapshotsTo(socketState);
      this.deliverPendingActionsTo(socketState);
    }

    socket.on('data', (chunk) => {
      try {
        socketState.buffer = Buffer.concat([socketState.buffer, chunk]);
        const { frames, remainder } = parseFrames(socketState.buffer);
        socketState.buffer = remainder;

        for (const frame of frames) {
          if (frame.opcode === 0x8) {
            socket.end();
            return;
          }

          if (frame.opcode === 0x9) {
            socket.write(encodeFrame(0xA, frame.payload));
            continue;
          }

          if (frame.opcode !== 0x1) {
            continue;
          }

          this.handleTOONMessage(socketState, frame.payload.toString('utf8'));
        }
      } catch (_) {
        closeSocket(socket, 1008, 'invalid_frame');
      }
    });

    const cleanup = () => {
      const current = this.sessions.get(sessionId);
      if (current) {
        current.socket = null;
        current.lastSeenAt = currentTimestamp();
      }
      this.socketSessions.delete(resolvedSessionId);
      if (current) {
        this.scheduleSave();
      }
    };

    socket.on('close', cleanup);
    socket.on('end', cleanup);
    socket.on('error', cleanup);
  }

  sendVerification(socketState, status, signature) {
    const payload = encodeTOON(
      'verification',
      ['status', 'signature', 'peer_device_id', 'received_at'],
      [[
        status,
        signature,
        this.deviceId,
        currentTimestamp()
      ]]
    );
    socketState.socket.write(encodeFrame(0x1, Buffer.from(payload, 'utf8')));
  }

  sendSnapshotsTo(socketState) {
    for (const [originId, rows] of this.tabStateByOrigin.entries()) {
      if (!originId || originId === socketState.originId || rows.size === 0) {
        continue;
      }

      const payload = encodeTOON(
        'tabs',
        ['tab_id', 'origin_id', 'device_id', 'url', 'title', 'last_updated_timestamp', 'device_name', 'browser_name', 'platform'],
        Array.from(rows.values()).map((row) => ([
          row.tab_id,
          row.origin_id,
          row.device_id,
          row.url,
          row.title,
          row.last_updated_timestamp,
          row.device_name,
          row.browser_name,
          row.platform
        ]))
      );
      socketState.socket.write(encodeFrame(0x1, Buffer.from(payload, 'utf8')));
    }
  }

  handleTOONMessage(socketState, payload) {
    const table = decodeTOON(payload);
    if (!table) {
      return;
    }

    const firstRow = table.rows[0] || [];
    const claimedOriginId = String(toonValue(table, firstRow, 'origin_id', ['device_id', 'source_device_id']) || '').trim();
    const trustedOriginId = String(socketState.originId || socketState.clientId || '').trim();
    const originId = trustedOriginId || claimedOriginId || socketState.clientId;

    socketState.originId = originId;
    const session = this.sessions.get(socketState.sessionId);
    if (session) {
      session.originId = originId;
      session.lastSeenAt = currentTimestamp();
    }

    if (table.name === 'heartbeat') {
      const event = String(toonValue(table, firstRow, 'event') || '').trim().toLowerCase();
      if (event === 'ping') {
        const response = encodeTOON(
          'heartbeat',
          ['event', 'origin_id', 'device_id', 'sent_at'],
          [[
            'pong',
            this.deviceId,
            this.deviceId,
            currentTimestamp()
          ]]
        );
        socketState.socket.write(encodeFrame(0x1, Buffer.from(response, 'utf8')));
      }
      return;
    }

    if (table.name === 'bridge_session') {
      const event = String(toonValue(table, firstRow, 'event') || '').trim().toLowerCase();
      if (socketState.directLocalSession && event !== 'extension_direct') {
        this.sendSnapshotsTo(socketState);
        this.deliverPendingActionsTo(socketState);
      }
      return;
    }

    if (table.name === 'tabs') {
      const previousRows = this.tabStateByOrigin.get(originId) || new Map();
      this.replaceSnapshot(originId, table);
      const outboundPayload = table.rows.length === 0 && previousRows.size > 0
        ? this.deleteDeltaForRows(originId, previousRows)
        : payload;
      this.broadcast(outboundPayload, {
        excludeSessionId: socketState.sessionId,
        sourceOriginId: originId
      });
      this.scheduleSave();
      return;
    }

    if (table.name === 'tab_origin_snapshot') {
      const snapshotOriginId = String(
        toonValue(table, firstRow, 'origin_id', ['device_id', 'source_device_id'])
        || originId
      ).trim();
      const browserName = String(toonValue(table, firstRow, 'browser_name', ['browser']) || '').trim().toLowerCase();
      const platform = String(toonValue(table, firstRow, 'platform') || '').trim().toLowerCase();
      const countLiteral = String(toonValue(table, firstRow, 'tab_count', ['count', 'tabs']) || '').trim();
      const tabCount = Number.parseInt(countLiteral, 10);
      let outboundPayload = payload;

      if (snapshotOriginId && Number.isFinite(tabCount) && tabCount <= 0) {
        const previousRows = this.tabStateByOrigin.get(snapshotOriginId) || new Map();
        this.tabStateByOrigin.delete(snapshotOriginId);
        if (platform === 'ios' || browserName === 'safari') {
          this.removeIOSSafariSnapshots();
        }
        if (previousRows.size > 0) {
          outboundPayload = this.deleteDeltaForRows(snapshotOriginId, previousRows);
        }
        this.scheduleSave();
      }

      this.broadcast(outboundPayload, {
        excludeSessionId: socketState.sessionId,
        sourceOriginId: snapshotOriginId || originId
      });
      return;
    }

    if (table.name === 'tabs_delta') {
      this.applyDelta(originId, table);
      this.broadcast(payload, {
        excludeSessionId: socketState.sessionId,
        sourceOriginId: originId
      });
      this.scheduleSave();
      return;
    }

    if (table.name === 'remote_tab_action') {
      const targetOriginId = String(toonValue(table, firstRow, 'target_device_id', ['target', 'target_origin_id']) || '').trim();
      const deliveredCount = this.broadcast(payload, {
        excludeSessionId: socketState.sessionId,
        sourceOriginId: originId,
        targetOriginId
      });
      if (targetOriginId && deliveredCount === 0) {
        this.queuePendingAction(payload, {
          sourceOriginId: originId,
          targetOriginId
        });
      }
      return;
    }

    if (table.name === 'device_visibility') {
      const targets = this.deviceVisibilityTargetOriginIds(table);
      for (const targetOriginId of targets) {
        this.removeSnapshotTarget(targetOriginId);
      }
      this.broadcast(payload, {
        excludeSessionId: socketState.sessionId,
        sourceOriginId: originId
      });
      this.scheduleSave();
      return;
    }

    this.broadcast(payload, {
      excludeSessionId: socketState.sessionId,
      sourceOriginId: originId
    });
  }

  deviceVisibilityTargetOriginIds(table) {
    const targets = new Set();
    for (const row of table.rows) {
      const action = String(toonValue(table, row, 'action') || '').trim().toUpperCase();
      if (
        action !== 'REMOVE_DEVICE'
        && action !== 'ACTION:REMOVE_DEVICE'
        && action !== 'HIDE_DEVICE'
        && action !== 'REMOVE'
        && action !== 'HIDE'
      ) {
        continue;
      }

      const explicitTarget = String(
        toonValue(table, row, 'target_origin_id', ['target_device_id', 'device_id'])
        || ''
      ).trim();
      if (explicitTarget) {
        targets.add(explicitTarget);
        continue;
      }

      const sourceDeviceId = String(toonValue(table, row, 'source_device_id') || '').trim();
      const legacyTarget = sourceDeviceId ? '' : String(toonValue(table, row, 'origin_id') || '').trim();
      if (legacyTarget) {
        targets.add(legacyTarget);
      }
    }

    return Array.from(targets);
  }

  removeSnapshotTarget(targetOriginId) {
    const normalizedTarget = String(targetOriginId || '').trim();
    if (!normalizedTarget) {
      return;
    }

    this.tabStateByOrigin.delete(normalizedTarget);
    this.hiddenDeviceOrigins.add(normalizedTarget);
    for (const [originId, rows] of this.tabStateByOrigin.entries()) {
      for (const [tabId, row] of rows.entries()) {
        if (String(row?.origin_id || '').trim() === normalizedTarget
          || String(row?.device_id || '').trim() === normalizedTarget) {
          rows.delete(tabId);
        }
      }
      if (rows.size === 0) {
        this.tabStateByOrigin.delete(originId);
      }
    }
  }

  isIOSSafariRow(row) {
    const platform = String(row?.platform || '').trim().toLowerCase();
    const browserName = String(row?.browser_name || row?.browser || '').trim().toLowerCase();
    const originId = String(row?.origin_id || row?.device_id || '').trim().toLowerCase();
    return platform === 'ios'
      || originId.startsWith('ios-')
      || originId.startsWith('safari-ios')
      || (browserName === 'safari' && platform !== 'macos' && platform !== 'desktop');
  }

  removeIOSSafariSnapshots() {
    let didChange = false;
    for (const [originId, rows] of this.tabStateByOrigin.entries()) {
      for (const [tabId, row] of rows.entries()) {
        if (this.isIOSSafariRow(row)) {
          rows.delete(tabId);
          didChange = true;
        }
      }
      if (rows.size === 0) {
        this.tabStateByOrigin.delete(originId);
      }
    }
    return didChange;
  }

  replaceSnapshot(originId, table) {
    if (this.hiddenDeviceOrigins.has(originId)) {
      this.tabStateByOrigin.delete(originId);
      return;
    }

    const rows = new Map();

    for (const row of table.rows) {
      const claimedOriginId = String(toonValue(table, row, 'origin_id', ['device_id', 'device']) || '').trim();
      if (claimedOriginId && claimedOriginId !== originId) {
        continue;
      }

      const resolvedDeviceId = String(toonValue(table, row, 'device_id', ['device']) || originId).trim() || originId;
      if (this.hiddenDeviceOrigins.has(claimedOriginId) || this.hiddenDeviceOrigins.has(resolvedDeviceId)) {
        continue;
      }
      const tab = {
        origin_id: originId,
        device_id: resolvedDeviceId,
        tab_id: String(toonValue(table, row, 'tab_id', ['id']) || '').trim(),
        url: String(toonValue(table, row, 'url') || '').trim(),
        title: String(toonValue(table, row, 'title') || '').trim(),
        last_updated_timestamp: String(toonValue(table, row, 'last_updated_timestamp', ['updated_at']) || currentTimestamp()).trim(),
        device_name: String(
          toonValue(table, row, 'device_name', ['host_name', 'display_name'])
          || this.hostName
        ).trim(),
        browser_name: String(
          toonValue(table, row, 'browser_name', ['browser', 'client_name'])
          || 'Browser'
        ).trim(),
        platform: String(
          toonValue(table, row, 'platform')
          || 'desktop'
        ).trim()
      };

      if (!tab.tab_id || !isSyncableTabURL(tab.url)) {
        continue;
      }

      rows.set(tab.tab_id, tab);
    }

    if (Array.from(rows.values()).some((row) => this.isIOSSafariRow(row))) {
      this.removeIOSSafariSnapshots();
    }
    this.tabStateByOrigin.set(originId, rows);
  }

  applyDelta(originId, table) {
    if (this.hiddenDeviceOrigins.has(originId)) {
      this.tabStateByOrigin.delete(originId);
      return;
    }

    const currentRows = this.tabStateByOrigin.get(originId) || new Map();

    for (const row of table.rows) {
      const change = String(toonValue(table, row, 'change', ['action', 'op']) || 'upsert').trim().toLowerCase();
      const claimedOriginId = String(toonValue(table, row, 'origin_id', ['device_id', 'device']) || '').trim();
      if (claimedOriginId && claimedOriginId !== originId) {
        continue;
      }

      const resolvedDeviceId = String(toonValue(table, row, 'device_id', ['device']) || originId).trim() || originId;
      if (this.hiddenDeviceOrigins.has(claimedOriginId) || this.hiddenDeviceOrigins.has(resolvedDeviceId)) {
        continue;
      }
      const tab = {
        origin_id: originId,
        device_id: resolvedDeviceId,
        tab_id: String(toonValue(table, row, 'tab_id', ['id']) || '').trim(),
        url: String(toonValue(table, row, 'url') || '').trim(),
        title: String(toonValue(table, row, 'title') || '').trim(),
        last_updated_timestamp: String(toonValue(table, row, 'last_updated_timestamp', ['updated_at']) || currentTimestamp()).trim(),
        device_name: String(
          toonValue(table, row, 'device_name', ['host_name', 'display_name'])
          || this.hostName
        ).trim(),
        browser_name: String(
          toonValue(table, row, 'browser_name', ['browser', 'client_name'])
          || 'Browser'
        ).trim(),
        platform: String(
          toonValue(table, row, 'platform')
          || 'desktop'
        ).trim()
      };

      if (!tab.tab_id) {
        continue;
      }

      if (change === 'delete') {
        currentRows.delete(tab.tab_id);
        continue;
      }

      if (!isSyncableTabURL(tab.url)) {
        currentRows.delete(tab.tab_id);
        continue;
      }

      currentRows.set(tab.tab_id, tab);
    }

    this.tabStateByOrigin.set(originId, currentRows);
  }

  deleteDeltaForRows(originId, rows) {
    const values = Array.from(rows.values());
    return encodeTOON(
      'tabs_delta',
      ['change', 'tab_id', 'origin_id', 'device_id', 'url', 'title', 'last_updated_timestamp', 'device_name', 'browser_name', 'platform'],
      values.map((row) => ([
        'delete',
        row.tab_id,
        originId,
        row.device_id || originId,
        row.url,
        row.title || '',
        currentTimestamp(),
        row.device_name || this.hostName,
        row.browser_name || 'Browser',
        row.platform || 'desktop'
      ]))
    );
  }

  broadcast(payload, options = {}) {
    let deliveredCount = 0;

    for (const [sessionId, socketState] of this.socketSessions.entries()) {
      if (sessionId === options.excludeSessionId) {
        continue;
      }

      if (options.sourceOriginId && socketState.originId === options.sourceOriginId) {
        continue;
      }

      if (options.targetOriginId && socketState.originId !== options.targetOriginId) {
        continue;
      }

      try {
        socketState.socket.write(encodeFrame(0x1, Buffer.from(payload, 'utf8')));
        deliveredCount += 1;
      } catch (_) {
      }
    }

    return deliveredCount;
  }

  queuePendingAction(payload, options = {}) {
    const targetOriginId = String(options.targetOriginId || '').trim();
    const normalizedPayload = String(payload || '').trim();
    if (!targetOriginId || !normalizedPayload) {
      return;
    }

    const createdAt = currentTimestamp();
    const expiresAt = pendingActionExpiresAt(normalizedPayload);
    if (!expiresAt) {
      return;
    }

    const key = crypto
      .createHash('sha256')
      .update(`${targetOriginId}|${normalizedPayload}`, 'utf8')
      .digest('hex');

    this.pendingActions = this.pendingActions.filter((item) => item.key !== key);
    this.pendingActions.push({
      key,
      payload: normalizedPayload,
      sourceOriginId: String(options.sourceOriginId || '').trim(),
      targetOriginId,
      createdAt,
      expiresAt
    });
    if (this.pendingActions.length > MAX_PENDING_ACTIONS) {
      this.pendingActions.splice(0, this.pendingActions.length - MAX_PENDING_ACTIONS);
    }
    this.scheduleSave();
  }

  deliverPendingActionsTo(socketState) {
    const originId = String(socketState?.originId || socketState?.clientId || '').trim();
    if (!originId || this.pendingActions.length === 0) {
      return 0;
    }

    let deliveredCount = 0;
    const remaining = [];
    for (const item of this.pendingActions) {
      if (!pendingActionIsFresh(item)) {
        continue;
      }

      if (item.targetOriginId !== originId) {
        remaining.push(item);
        continue;
      }

      try {
        socketState.socket.write(encodeFrame(0x1, Buffer.from(item.payload, 'utf8')));
        deliveredCount += 1;
      } catch (_) {
        remaining.push(item);
      }
    }

    if (remaining.length !== this.pendingActions.length) {
      this.pendingActions = remaining;
      this.scheduleSave();
    }

    return deliveredCount;
  }

  async scanLocalBridges() {
    const selfSnapshot = this.discoverySnapshotFor('');
    const candidates = await this.udpDiscovery.scan({
      includeSelf: false,
      originID: this.deviceId,
      timeoutMs: Math.max(SCAN_TIMEOUT_MS * 2, 900)
    });
    const deduped = new Map();

    if (selfSnapshot.hostIP) {
      deduped.set(`${selfSnapshot.hostIP}:${selfSnapshot.port}:${selfSnapshot.deviceID}`, {
        hostIP: selfSnapshot.hostIP,
        port: selfSnapshot.port,
        deviceID: selfSnapshot.deviceID,
        bridgeID: selfSnapshot.bridgeID,
        hostName: selfSnapshot.hostName,
        websocketURL: selfSnapshot.websocketURL,
        bridgeState: selfSnapshot.bridgeState,
        resumeSupported: true,
        discoveredAt: currentTimestamp(),
        source: 'self'
      });
    }

    for (const candidate of Array.isArray(candidates) ? candidates : []) {
      const key = `${candidate.hostIP}:${candidate.port}:${candidate.deviceID}`;
      if (deduped.has(key)) {
        continue;
      }
      deduped.set(key, candidate);
    }

    return Array.from(deduped.values()).sort((left, right) => {
      if (left.source === 'self' && right.source !== 'self') {
        return 1;
      }
      if (right.source === 'self' && left.source !== 'self') {
        return -1;
      }
      return left.hostIP.localeCompare(right.hostIP);
    });
  }

  discoveryScanTOON(candidates) {
    return encodeTOON(
      'bridge_scan',
      ['host_ip', 'host_port', 'device_id', 'bridge_id', 'host_name', 'ws_url', 'bridge_state', 'resume_supported', 'source', 'discovered_at'],
      (Array.isArray(candidates) ? candidates : []).map((candidate) => ([
        candidate.hostIP,
        String(candidate.port),
        candidate.deviceID,
        candidate.bridgeID,
        String(candidate.hostName || ''),
        String(candidate.websocketURL || ''),
        candidate.bridgeState,
        candidate.resumeSupported === false ? 'false' : 'true',
        candidate.source,
        candidate.discoveredAt
      ]))
    );
  }

  async handleNativeMessage(message) {
    this.pruneExpiredState();
    this.refreshLocalTopology();

    const requestId = String(message?.request_id || '').trim();
    const commandType = String(message?.type || '').trim().toUpperCase();

    if (!commandType) {
      return {
        request_id: requestId,
        type: 'HOST_ERROR',
        ok: false,
        error: 'missing_type'
      };
    }

    if (commandType === 'PING') {
      return {
        request_id: requestId,
        ...this.buildNativeSnapshot('HOST_PONG')
      };
    }

    if (commandType === 'GET_HOST_STATE' || commandType === 'HOST_STATUS') {
      return {
        request_id: requestId,
        ...this.buildNativeSnapshot('HOST_STATE')
      };
    }

    if (commandType === 'PAIRING_STATE' || commandType === 'GENERATE_PAIRING_STATE') {
      return {
        request_id: requestId,
        ...this.buildNativeSnapshot('PAIRING_STATE')
      };
    }

    if (commandType === 'SET_PAIRING_ANCHOR' || commandType === 'SYNC_PAIRING_ANCHOR') {
      this.applyPairingAnchor(message);
      return {
        request_id: requestId,
        ...this.buildNativeSnapshot('PAIRING_STATE')
      };
    }

    if (commandType === 'DISCOVER_LOCAL_BRIDGES' || commandType === 'SCAN_PRIVATE_IPV4') {
      const candidates = await this.scanLocalBridges();
      return {
        request_id: requestId,
        type: 'DISCOVERY_SCAN',
        ok: true,
        bridge_ready: this.ready,
        bridge_state: this.ready ? 'ready' : this.bridgeState,
        bridge_message: this.ready ? 'Bridge Reachable' : this.bridgeMessage,
        candidates,
        toon: this.discoveryScanTOON(candidates),
        host_status_toon: this.currentHostStatusTOON(this.primaryHostIP),
        discovery_mode: 'udp'
      };
    }

    return {
      request_id: requestId,
      type: 'HOST_ERROR',
      ok: false,
      error: `unsupported_command:${commandType}`
    };
  }

  startupMessage() {
    return this.buildNativeSnapshot('HOST_READY');
  }
}

module.exports = {
  BridgeRuntime
};
