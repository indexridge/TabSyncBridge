'use strict';

const crypto = require('node:crypto');
const dgram = require('node:dgram');
const { encodeTOON, decodeTOON, toonValue } = require('./toon');
const { enumeratePrivateInterfaces, enumerateScanTargets, normalizeIPv4 } = require('./private_ipv4');

const DEFAULT_SCAN_TIMEOUT_MS = Number.parseInt(process.env.TABSYNC_UDP_SCAN_TIMEOUT_MS || '900', 10);
const DEFAULT_MAX_HOSTS_PER_INTERFACE = Number.parseInt(process.env.TABSYNC_UDP_SCAN_MAX_HOSTS || '256', 10);

function currentTimestamp() {
  return new Date().toISOString();
}

class UDPDiscoveryService {
  constructor(options = {}) {
    this.port = 53317;
    this.protocolVersion = String(options.protocolVersion || 'tabsync.lan.v2').trim();
    this.acceptedProtocolVersions = new Set([
      this.protocolVersion,
      'tabsync.lan.v2',
      'tabsync.localsend.v1'
    ]);
    this.getBridgeSnapshot = typeof options.getBridgeSnapshot === 'function'
      ? options.getBridgeSnapshot
      : () => null;
    this.socket = null;
    this.pendingScans = new Map();
  }

  async start() {
    if (this.socket) {
      return;
    }

    const socket = dgram.createSocket({ type: 'udp4', reuseAddr: true });
    await new Promise((resolve, reject) => {
      const handleError = (error) => {
        socket.off('listening', handleListening);
        reject(error);
      };
      const handleListening = () => {
        socket.off('error', handleError);
        resolve();
      };

      socket.once('error', handleError);
      socket.once('listening', handleListening);
      socket.bind(this.port, '0.0.0.0');
    });

    socket.setBroadcast(true);
    socket.on('message', (message, rinfo) => this.handleMessage(message, rinfo));
    socket.on('error', () => {
    });
    this.socket = socket;
  }

  async stop() {
    const socket = this.socket;
    this.socket = null;

    for (const [requestID, pending] of this.pendingScans.entries()) {
      clearTimeout(pending.timer);
      this.pendingScans.delete(requestID);
      pending.resolve(Array.from(pending.candidates.values()));
    }

    if (!socket) {
      return;
    }

    await new Promise((resolve) => socket.close(() => resolve()));
  }

  buildProbe(requestID, originID) {
    return encodeTOON(
      'bridge_probe',
      ['protocol', 'request_id', 'origin_id', 'requested_at'],
      [[
        this.protocolVersion,
        requestID,
        String(originID || ''),
        currentTimestamp()
      ]]
    );
  }

  buildLegacyProbe(requestID, originID) {
    return JSON.stringify({
      protocol: 'tabsync.localsend.v1',
      request_id: requestID,
      type: 'probe',
      device_id: String(originID || ''),
      device: 'TabSyncBridge Desktop Bridge',
      port: this.port,
      path: '/bridge',
      bridge_state: 'ready'
    });
  }

  buildAnnouncement(requestID, snapshot, source = 'udp') {
    return encodeTOON(
      'bridge_announce',
      ['protocol', 'request_id', 'bridge_id', 'device_id', 'host_name', 'host_ip', 'host_port', 'bridge_state', 'ws_url', 'resume_supported', 'source', 'responded_at'],
      [[
        this.protocolVersion,
        requestID,
        String(snapshot?.bridgeID || ''),
        String(snapshot?.deviceID || ''),
        String(snapshot?.hostName || ''),
        String(snapshot?.hostIP || ''),
        String(snapshot?.port || this.port),
        String(snapshot?.bridgeState || 'ready'),
        String(snapshot?.websocketURL || ''),
        snapshot?.resumeSupported === false ? 'false' : 'true',
        source,
        currentTimestamp()
      ]]
    );
  }

  buildLegacyAnnouncement(requestID, snapshot) {
    return JSON.stringify({
      protocol: 'tabsync.localsend.v1',
      request_id: requestID,
      type: 'announce',
      device_id: String(snapshot?.deviceID || ''),
      device: String(snapshot?.hostName || ''),
      host_ip: String(snapshot?.hostIP || ''),
      port: Number.parseInt(String(snapshot?.port || this.port), 10) || this.port,
      path: '/bridge',
      bridge_state: String(snapshot?.bridgeState || 'ready')
    });
  }

  scanTargets(options = {}) {
    const targets = new Set();
    const includeBroadcast = options.includeBroadcast !== false;
    const includeUnicastSweep = options.includeUnicastSweep !== false;

    if (includeBroadcast) {
      for (const entry of enumeratePrivateInterfaces()) {
        if (entry.broadcast) {
          targets.add(entry.broadcast);
        }
      }
    }

    if (includeUnicastSweep) {
      for (const target of enumerateScanTargets({
        includeSelf: options.includeSelf === true,
        maxHostsPerInterface: Number.isInteger(options.maxHostsPerInterface)
          ? options.maxHostsPerInterface
          : DEFAULT_MAX_HOSTS_PER_INTERFACE
      })) {
        targets.add(target);
      }
    }

    return Array.from(targets.values());
  }

  async send(message, hostIP) {
    if (!this.socket || !hostIP) {
      return false;
    }

    const payload = Buffer.from(String(message || ''), 'utf8');
    await new Promise((resolve, reject) => {
      this.socket.send(payload, this.port, hostIP, (error) => {
        if (error) {
          reject(error);
          return;
        }
        resolve();
      });
    });
    return true;
  }

  async scan(options = {}) {
    if (!this.socket) {
      throw new Error('udp_discovery_unavailable');
    }

    const requestID = crypto.randomUUID();
    const pending = {
      candidates: new Map(),
      resolve: null,
      timer: null
    };

    const resultsPromise = new Promise((resolve) => {
      pending.resolve = resolve;
      pending.timer = setTimeout(() => {
        this.pendingScans.delete(requestID);
        resolve(Array.from(pending.candidates.values()));
      }, Number.parseInt(String(options.timeoutMs || DEFAULT_SCAN_TIMEOUT_MS), 10) || DEFAULT_SCAN_TIMEOUT_MS);
    });

    this.pendingScans.set(requestID, pending);
    const probes = [
      this.buildProbe(requestID, String(options.originID || '')),
      this.buildLegacyProbe(requestID, String(options.originID || ''))
    ];
    const targets = this.scanTargets(options);

    await Promise.all(
      targets.flatMap((hostIP) => probes.map((probe) => this.send(probe, hostIP).catch(() => false)))
    );

    return resultsPromise;
  }

  handleMessage(message, rinfo) {
    const payload = Buffer.isBuffer(message) ? message.toString('utf8') : String(message || '');
    const table = decodeTOON(payload);
    if (!table) {
      this.handleJSONMessage(payload, rinfo);
      return;
    }

    if (!table || table.rows.length === 0) {
      return;
    }

    const row = table.rows[0];
    const protocol = String(toonValue(table, row, 'protocol') || '').trim();
    if (!this.protocolIsAccepted(protocol)) {
      return;
    }

    if (table.name === 'bridge_probe') {
      void this.handleProbe(table, row, rinfo);
      return;
    }

    if (table.name === 'bridge_announce') {
      this.handleAnnouncement(table, row, rinfo);
    }
  }

  protocolIsAccepted(value) {
    const protocol = String(value || '').trim();
    return !protocol || this.acceptedProtocolVersions.has(protocol);
  }

  handleJSONMessage(payload, rinfo) {
    let packet = null;
    try {
      packet = JSON.parse(String(payload || ''));
    } catch (_) {
      return;
    }

    if (!packet || typeof packet !== 'object' || !this.protocolIsAccepted(packet.protocol)) {
      return;
    }

    const type = String(packet.type || '').trim().toLowerCase();
    if (type === 'probe') {
      void this.handleJSONProbe(packet, rinfo);
      return;
    }

    if (type === 'announce' || String(packet.bridge_state || '').trim().toLowerCase() === 'ready') {
      this.handleJSONAnnouncement(packet, rinfo);
    }
  }

  async handleJSONProbe(packet, rinfo) {
    const snapshot = this.getBridgeSnapshot(normalizeIPv4(rinfo?.address || ''));
    if (!snapshot?.hostIP || snapshot.ready === false || snapshot.bridgeState === 'unavailable') {
      return;
    }

    const response = this.buildLegacyAnnouncement(String(packet.request_id || ''), snapshot);
    await this.send(response, normalizeIPv4(rinfo?.address || ''));
  }

  handleJSONAnnouncement(packet, rinfo) {
    const hostIP = normalizeIPv4(packet.host_ip || rinfo?.address || '');
    const deviceID = String(packet.device_id || '').trim();
    if (!hostIP || !deviceID) {
      return;
    }

    const port = Number.parseInt(String(packet.port || this.port), 10) || this.port;
    const rawPath = String(packet.path || '/bridge').trim();
    const path = rawPath.startsWith('/') ? rawPath : `/${rawPath}`;
    const candidate = {
      hostIP,
      port,
      deviceID,
      bridgeID: String(packet.bridge_id || '').trim(),
      hostName: String(packet.device || packet.host_name || '').trim(),
      websocketURL: String(packet.ws_url || `ws://${hostIP}:${port}${path}`).trim(),
      bridgeState: String(packet.bridge_state || 'ready').trim(),
      resumeSupported: packet.resume_supported === false ? false : String(packet.resume_supported || '').trim().toLowerCase() !== 'false',
      discoveredAt: currentTimestamp(),
      source: 'udp-json'
    };

    const requestID = String(packet.request_id || '').trim();
    if (requestID && this.pendingScans.has(requestID)) {
      this.storeCandidate(this.pendingScans.get(requestID), candidate);
      return;
    }

    for (const pending of this.pendingScans.values()) {
      this.storeCandidate(pending, candidate);
    }
  }

  async handleProbe(table, row, rinfo) {
    const requestID = String(toonValue(table, row, 'request_id') || '').trim();
    if (!requestID) {
      return;
    }

    const snapshot = this.getBridgeSnapshot(normalizeIPv4(rinfo?.address || ''));
    if (!snapshot?.hostIP || snapshot.ready === false || snapshot.bridgeState === 'unavailable') {
      return;
    }

    const response = this.buildAnnouncement(requestID, snapshot);
    await this.send(response, normalizeIPv4(rinfo?.address || ''));
  }

  handleAnnouncement(table, row, rinfo) {
    const requestID = String(toonValue(table, row, 'request_id') || '').trim();
    const pending = this.pendingScans.get(requestID);
    if (!pending) {
      return;
    }

    const hostIP = normalizeIPv4(toonValue(table, row, 'host_ip') || rinfo?.address || '');
    const deviceID = String(toonValue(table, row, 'device_id') || '').trim();
    if (!hostIP || !deviceID) {
      return;
    }

    const port = Number.parseInt(String(toonValue(table, row, 'host_port', ['port']) || this.port), 10) || this.port;
    this.storeCandidate(pending, {
      hostIP,
      port,
      deviceID,
      bridgeID: String(toonValue(table, row, 'bridge_id') || '').trim(),
      hostName: String(toonValue(table, row, 'host_name') || '').trim(),
      websocketURL: String(toonValue(table, row, 'ws_url') || `ws://${hostIP}:${port}/bridge`).trim(),
      bridgeState: String(toonValue(table, row, 'bridge_state') || 'ready').trim(),
      resumeSupported: String(toonValue(table, row, 'resume_supported') || 'true').trim().toLowerCase() !== 'false',
      discoveredAt: String(toonValue(table, row, 'responded_at') || currentTimestamp()).trim(),
      source: String(toonValue(table, row, 'source') || 'udp').trim()
    });
  }

  storeCandidate(pending, candidate) {
    if (!pending || !candidate?.hostIP || !candidate?.deviceID) {
      return;
    }

    const port = Number.parseInt(String(candidate.port || this.port), 10) || this.port;
    const key = `${candidate.hostIP}:${port}:${candidate.deviceID}`;
    pending.candidates.set(key, {
      ...candidate,
      port
    });
  }
}

module.exports = {
  UDPDiscoveryService
};
