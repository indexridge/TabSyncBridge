'use strict';

const fs = require('node:fs/promises');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

const HOST_NAME = 'com.tabsync.bridge';
const DEFAULT_EXTENSION_ID = 'jokabacndcaecbfdmocicakhlhibjeab';
const EXTENSION_ID_PATTERN = /^[a-p]{32}$/;

function configuredExtensionIDs(argv = process.argv.slice(2), env = process.env) {
  const candidates = [];

  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (argument === '--extension-id' && argv[index + 1]) {
      candidates.push(argv[index + 1]);
      index += 1;
    } else if (argument.startsWith('--extension-id=')) {
      candidates.push(argument.slice('--extension-id='.length));
    }
  }

  if (env.TABSYNC_EXTENSION_IDS) {
    candidates.push(env.TABSYNC_EXTENSION_IDS);
  }
  if (env.TABSYNC_EXTENSION_ID) {
    candidates.push(env.TABSYNC_EXTENSION_ID);
  }

  const ids = candidates
    .flatMap((candidate) => String(candidate).split(/[,\s]+/))
    .map((candidate) => candidate.trim().toLowerCase())
    .filter(Boolean);
  const uniqueIDs = [...new Set(ids.filter((candidate) => EXTENSION_ID_PATTERN.test(candidate)))];
  return uniqueIDs.length > 0 ? uniqueIDs : [DEFAULT_EXTENSION_ID];
}

function manifestJSON(launcherPath, extensionIDs) {
  return JSON.stringify(
    {
      name: HOST_NAME,
      description: 'TabSyncBridge native messaging host',
      path: launcherPath,
      type: 'stdio',
      allowed_origins: extensionIDs.map((extensionID) => `chrome-extension://${extensionID}/`)
    },
    null,
    2
  );
}

function posixLauncher(entryPath) {
  return [
    '#!/bin/sh',
    `exec "${process.execPath}" "${entryPath}" "$@"`,
    ''
  ].join('\n');
}

function windowsLauncher(entryPath) {
  return [
    '@echo off',
    `"${process.execPath}" "${entryPath}" %*`,
    ''
  ].join('\r\n');
}

async function writeFileWithParents(filePath, content, mode) {
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, content, 'utf8');
  if (mode != null) {
    await fs.chmod(filePath, mode);
  }
}

async function resolveBridgePath() {
  const bridgePath = path.resolve(__dirname, 'bridge.js');
  await fs.access(bridgePath);
  return bridgePath;
}

function encodeTOON(name, header, rows) {
  const intro = `${name}[${rows.length}]{${header.join(',')}}:`;
  const body = rows.map((row) => header.map((_, index) => escapeValue(row[index] ?? '')).join('\t'));
  return [intro, ...body].join('\n');
}

function escapeValue(value) {
  return String(value)
    .replace(/\\/g, '\\\\')
    .replace(/\t/g, '\\t')
    .replace(/\n/g, '\\n');
}

async function installDarwin(bridgePath, extensionIDs) {
  const launcherPath = path.resolve(__dirname, 'tabsync_host_macos.sh');
  const manifestTargets = [
    ['chrome', path.resolve(os.homedir(), 'Library', 'Application Support', 'Google', 'Chrome', 'NativeMessagingHosts', `${HOST_NAME}.json`)],
    ['chromium', path.resolve(os.homedir(), 'Library', 'Application Support', 'Chromium', 'NativeMessagingHosts', `${HOST_NAME}.json`)],
    ['edge', path.resolve(os.homedir(), 'Library', 'Application Support', 'Microsoft Edge', 'NativeMessagingHosts', `${HOST_NAME}.json`)],
    ['brave', path.resolve(os.homedir(), 'Library', 'Application Support', 'BraveSoftware', 'Brave-Browser', 'NativeMessagingHosts', `${HOST_NAME}.json`)],
    ['vivaldi', path.resolve(os.homedir(), 'Library', 'Application Support', 'Vivaldi', 'NativeMessagingHosts', `${HOST_NAME}.json`)]
  ];

  await writeFileWithParents(launcherPath, posixLauncher(bridgePath), 0o755);
  for (const [, manifestPath] of manifestTargets) {
    await writeFileWithParents(manifestPath, manifestJSON(launcherPath, extensionIDs));
  }

  return manifestTargets.map(([browser, manifestPath]) => ([
    'darwin',
    'installed',
    manifestPath,
    launcherPath,
    bridgePath,
    '',
    browser,
    extensionIDs.join(',')
  ]));
}

async function installLinux(bridgePath, extensionIDs) {
  const launcherPath = path.resolve(__dirname, 'tabsync_host_linux.sh');
  const manifestTargets = [
    ['chrome', path.resolve(os.homedir(), '.config', 'google-chrome', 'NativeMessagingHosts', `${HOST_NAME}.json`)],
    ['chromium', path.resolve(os.homedir(), '.config', 'chromium', 'NativeMessagingHosts', `${HOST_NAME}.json`)],
    ['edge', path.resolve(os.homedir(), '.config', 'microsoft-edge', 'NativeMessagingHosts', `${HOST_NAME}.json`)],
    ['brave', path.resolve(os.homedir(), '.config', 'BraveSoftware', 'Brave-Browser', 'NativeMessagingHosts', `${HOST_NAME}.json`)],
    ['vivaldi', path.resolve(os.homedir(), '.config', 'vivaldi', 'NativeMessagingHosts', `${HOST_NAME}.json`)]
  ];

  await writeFileWithParents(launcherPath, posixLauncher(bridgePath), 0o755);
  for (const [, manifestPath] of manifestTargets) {
    await writeFileWithParents(manifestPath, manifestJSON(launcherPath, extensionIDs));
  }

  return manifestTargets.map(([browser, manifestPath]) => ([
    'linux',
    'installed',
    manifestPath,
    launcherPath,
    bridgePath,
    '',
    browser,
    extensionIDs.join(',')
  ]));
}

async function installWindows(bridgePath, extensionIDs) {
  const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local');
  const launcherPath = path.resolve(__dirname, 'tabsync_host_windows.cmd');
  const targets = [
    {
      browser: 'chrome',
      manifestPath: path.resolve(localAppData, 'Google', 'Chrome', 'User Data', 'NativeMessagingHosts', `${HOST_NAME}.json`),
      registryKey: `HKCU\\Software\\Google\\Chrome\\NativeMessagingHosts\\${HOST_NAME}`
    },
    {
      browser: 'chromium',
      manifestPath: path.resolve(localAppData, 'Chromium', 'User Data', 'NativeMessagingHosts', `${HOST_NAME}.json`),
      registryKey: `HKCU\\Software\\Chromium\\NativeMessagingHosts\\${HOST_NAME}`
    },
    {
      browser: 'edge',
      manifestPath: path.resolve(localAppData, 'Microsoft', 'Edge', 'User Data', 'NativeMessagingHosts', `${HOST_NAME}.json`),
      registryKey: `HKCU\\Software\\Microsoft\\Edge\\NativeMessagingHosts\\${HOST_NAME}`
    },
    {
      browser: 'brave',
      manifestPath: path.resolve(localAppData, 'BraveSoftware', 'Brave-Browser', 'User Data', 'NativeMessagingHosts', `${HOST_NAME}.json`),
      registryKey: `HKCU\\Software\\BraveSoftware\\Brave-Browser\\NativeMessagingHosts\\${HOST_NAME}`
    },
    {
      browser: 'vivaldi',
      manifestPath: path.resolve(localAppData, 'Vivaldi', 'User Data', 'NativeMessagingHosts', `${HOST_NAME}.json`),
      registryKey: `HKCU\\Software\\Vivaldi\\NativeMessagingHosts\\${HOST_NAME}`
    }
  ];

  await writeFileWithParents(launcherPath, windowsLauncher(bridgePath));
  const rows = [];

  for (const target of targets) {
    await writeFileWithParents(target.manifestPath, manifestJSON(launcherPath, extensionIDs));

    const result = spawnSync(
      'reg',
      ['add', target.registryKey, '/ve', '/t', 'REG_SZ', '/d', target.manifestPath, '/f'],
      { encoding: 'utf8' }
    );

    if (result.status !== 0) {
      throw new Error(result.stderr || result.stdout || `Failed to register ${target.registryKey}`);
    }

    rows.push([
      'win32',
      'installed',
      target.manifestPath,
      launcherPath,
      bridgePath,
      target.registryKey,
      target.browser,
      extensionIDs.join(',')
    ]);
  }

  return rows;
}

async function installHost() {
  const bridgePath = await resolveBridgePath();
  const extensionIDs = configuredExtensionIDs();

  if (process.platform === 'darwin') {
    return installDarwin(bridgePath, extensionIDs);
  }

  if (process.platform === 'linux') {
    return installLinux(bridgePath, extensionIDs);
  }

  if (process.platform === 'win32') {
    return installWindows(bridgePath, extensionIDs);
  }

  throw new Error(`Unsupported platform: ${process.platform}`);
}

async function main() {
  const rows = await installHost();
  process.stdout.write(
    `${encodeTOON(
      'native_host_registration',
      ['platform', 'status', 'manifest_path', 'launcher_path', 'bridge_path', 'registry_key', 'browser', 'extension_id'],
      rows
    )}\n`
  );
}

main().catch((error) => {
  process.stderr.write(`${encodeTOON(
    'native_host_registration_error',
    ['platform', 'status', 'message'],
    [[
      process.platform,
      'failed',
      error.stack || error.message
    ]]
  )}\n`);
  process.exitCode = 1;
});
