const OFFSCREEN_DOCUMENT_PATH = 'offscreen.html';
const OFFSCREEN_KEEPALIVE_REASON = 'WORKERS';
const OFFSCREEN_JUSTIFICATION = 'Run the TabSyncBridge local transport in an offscreen extension context while the service worker handles events.';
const CONNECTIVITY_ALARM_NAME = 'tabsync-connectivity-monitor';
const FAST_RECONNECT_ALARM_NAME = 'tabsync-fast-reconnect';
const CONNECTIVITY_ALARM_PERIOD_MINUTES = 1;
const FAST_RECONNECT_ALARM_DELAY_MINUTES = 0.5;
const ACTIVE_SYNC_PORT_NAME = 'tabsync-active-sync';
const SYNC_PORT = 53317;
const COMPLETE_IPV4_PATTERN = /^(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;
const STARTUP_REMOTE_CLOSE_GUARD_MS = 30 * 1000;
const STORAGE_KEYS = Object.freeze({
  deviceID: 'deviceId',
  pairingState: 'tabsync_local_pairing',
  savedRoute: 'tabsync_saved_direct_route',
  offscreenState: 'offscreen_state_toon',
  offscreenRuntimeState: 'tabsync_offscreen_runtime_state',
  linkedDevices: 'offscreen_linked_devices_toon',
  offscreenSignal: 'offscreen_signal_toon',
  hiddenDevices: 'tabsync_hidden_device_ids',
  closeQueue: 'tabsync_close_queue_toon',
  startupCloseGuard: 'tabsync_startup_close_guard',
  browserSessionGuard: 'tabsync_browser_session_guard'
});
const CLOSE_QUEUE_HEADER = Object.freeze([
  'tab_id',
  'origin_id',
  'device_id',
  'url',
  'title',
  'last_updated_timestamp',
  'device_name',
  'browser_name',
  'platform',
  'requested_at',
  'source_device_id'
]);
const CLOSE_QUEUE_MAX_AGE_MS = 24 * 60 * 60 * 1000;
const CLOSE_QUEUE_FLUSH_INTERVAL_MS = 5_000;

let offscreenDocumentPromise = null;
let connectivityFingerprint = '';
let lastRestoreAttemptAt = 0;
let lastCloseQueueFlushAt = 0;
let closeQueueFlushPromise = null;
let startupCloseGuardSnapshot = null;
const activeSyncPorts = new Set();
const startupReconnectTimers = new Set();

function storageArea() {
  return chrome.storage?.local ?? null;
}

async function storageGet(keys) {
  const area = storageArea();
  if (!area?.get) {
    return {};
  }

  try {
    return await area.get(keys);
  } catch (_) {
    return {};
  }
}

async function storageSet(values) {
  const area = storageArea();
  if (!area?.set) {
    return false;
  }

  try {
    await area.set(values);
    return true;
  } catch (_) {
    return false;
  }
}

function sessionStorageArea() {
  return chrome.storage?.session ?? null;
}

async function sessionStorageGet(keys) {
  const area = sessionStorageArea();
  if (!area?.get) {
    return {};
  }

  try {
    return await area.get(keys);
  } catch (_) {
    return {};
  }
}

async function sessionStorageSet(values) {
  const area = sessionStorageArea();
  if (!area?.set) {
    return false;
  }

  try {
    await area.set(values);
    return true;
  } catch (_) {
    return false;
  }
}

function escapeTOONValue(value) {
  return String(value ?? '')
    .replace(/\\/g, '\\\\')
    .replace(/\t/g, '\\t')
    .replace(/\n/g, '\\n');
}

function unescapeTOONValue(value) {
  let output = '';
  let escaped = false;

  for (const character of String(value ?? '')) {
    if (!escaped) {
      if (character === '\\') {
        escaped = true;
      } else {
        output += character;
      }
      continue;
    }

    if (character === 't') {
      output += '\t';
    } else if (character === 'n') {
      output += '\n';
    } else {
      output += character;
    }

    escaped = false;
  }

  return output;
}

function encodeTOON(name, header, rows) {
  const safeRows = Array.isArray(rows) ? rows : [];
  const lines = [`${name}[${safeRows.length}]{${header.join(',')}}:`];

  for (const row of safeRows) {
    const values = Array.isArray(row)
      ? row
      : header.map((column) => row?.[column] ?? '');
    lines.push(header.map((_, index) => escapeTOONValue(values[index] ?? '')).join('\t'));
  }

  return lines.join('\n');
}

function decodeTOON(rawValue) {
  if (typeof rawValue !== 'string' || rawValue.trim().length === 0) {
    return null;
  }

  const lines = rawValue.replace(/\r\n/g, '\n').split('\n');
  const headerLine = lines.shift() || '';
  const match = /^([A-Za-z0-9_]+)\[(\d+)\]\{([^}]*)\}:$/.exec(headerLine.trim());
  if (!match) {
    return null;
  }

  const [, name, rowCountLiteral, headerLiteral] = match;
  const header = headerLiteral.split(',').map((column) => column.trim()).filter(Boolean);
  const rowCount = Number.parseInt(rowCountLiteral, 10) || 0;
  const rows = lines
    .slice(0, rowCount)
    .map((line) => line.split('\t').map(unescapeTOONValue));

  return {
    name,
    header,
    rows,
    indexByHeader: Object.fromEntries(header.map((column, index) => [column, index]))
  };
}

function toonValue(table, row, column, aliases = []) {
  for (const key of [column, ...aliases]) {
    const index = table?.indexByHeader?.[key];
    if (index != null && row?.[index] != null) {
      return row[index];
    }
  }

  return '';
}

function parseTimestampMillis(rawValue) {
  const trimmed = String(rawValue || '').trim();
  if (!trimmed) {
    return 0;
  }

  const parsed = Date.parse(trimmed);
  return Number.isFinite(parsed) ? parsed : 0;
}

function remoteActionRequestedAtMillis(parsed, row) {
  return parseTimestampMillis(toonValue(parsed, row, 'requested_at', ['requestedAt', 'created_at']));
}

function isValidStartupGuard(guard) {
  return Boolean(guard && typeof guard === 'object' && parseTimestampMillis(guard.startedAt));
}

async function armStartupRemoteCloseGuard(reason) {
  const sessionStored = await sessionStorageGet([STORAGE_KEYS.browserSessionGuard]);
  const existingGuard = sessionStored[STORAGE_KEYS.browserSessionGuard];
  if (isValidStartupGuard(existingGuard)) {
    startupCloseGuardSnapshot = existingGuard;
    await storageSet({ [STORAGE_KEYS.startupCloseGuard]: existingGuard });
    return existingGuard;
  }

  const startedAtMillis = Date.now();
  startupCloseGuardSnapshot = {
    reason: String(reason || 'startup'),
    startedAt: new Date(startedAtMillis).toISOString(),
    expiresAt: new Date(startedAtMillis + STARTUP_REMOTE_CLOSE_GUARD_MS).toISOString()
  };
  await sessionStorageSet({ [STORAGE_KEYS.browserSessionGuard]: startupCloseGuardSnapshot });
  await storageSet({ [STORAGE_KEYS.startupCloseGuard]: startupCloseGuardSnapshot });
  return startupCloseGuardSnapshot;
}

async function remoteCloseReplayDecision(parsed, row) {
  const now = Date.now();
  const requestedAtMillis = remoteActionRequestedAtMillis(parsed, row);
  const stored = startupCloseGuardSnapshot
    ? {}
    : await storageGet([STORAGE_KEYS.startupCloseGuard]);
  const guard = startupCloseGuardSnapshot || stored[STORAGE_KEYS.startupCloseGuard] || {};
  const startedAtMillis = parseTimestampMillis(guard.startedAt);
  const expiresAtMillis = parseTimestampMillis(guard.expiresAt);
  if (startedAtMillis && requestedAtMillis && requestedAtMillis < startedAtMillis - 1000) {
    return { ignore: true, reason: 'startup_replayed_remote_close' };
  }

  if (!startedAtMillis || !expiresAtMillis || now > expiresAtMillis) {
    return { ignore: false };
  }

  if (!requestedAtMillis) {
    return { ignore: true, reason: 'untimestamped_startup_remote_close' };
  }

  return { ignore: true, reason: 'startup_remote_close_holdoff' };
}

function resolveLocalDeviceID(context = {}) {
  const stateTable = decodeTOON(String(context?.offscreenState?.state_toon || context?.state_toon || ''));
  const stateRow = stateTable?.rows?.[0] || [];
  const documentTable = decodeTOON(String(context?.offscreenState?.document_toon || context?.document_toon || ''));
  const documentRow = documentTable?.rows?.[0] || [];

  return String(
    toonValue(stateTable, stateRow, 'device_id', ['origin_id']) ||
    toonValue(documentTable, documentRow, 'device_id', ['origin_id']) ||
    context?.storedDeviceID ||
    ''
  ).trim();
}

function sanitizeTOONPayload(rawValue, context = {}) {
  const original = String(rawValue || '');
  const parsed = decodeTOON(original);
  if (!parsed) {
    return original;
  }

  const localDeviceID = String(context.localDeviceID || '').trim();
  let filteredRows = parsed.rows;

  if (parsed.name === 'bridge_scan') {
    filteredRows = parsed.rows.filter((row) => {
      const source = String(toonValue(parsed, row, 'source') || '').trim().toLowerCase();
      const deviceID = String(toonValue(parsed, row, 'device_id', ['origin_id']) || '').trim();
      return source !== 'self' && (!localDeviceID || deviceID !== localDeviceID);
    });
  } else if (parsed.name === 'linked_devices' || parsed.name === 'tabs' || parsed.name === 'tabs_delta') {
    filteredRows = parsed.rows.filter((row) => {
      const originID = String(
        toonValue(parsed, row, 'origin_id', ['device_id', 'peer_device_id', 'client_id']) || ''
      ).trim();
      const deviceID = String(
        toonValue(parsed, row, 'device_id', ['origin_id', 'peer_device_id', 'client_id']) || ''
      ).trim();
      const url = String(toonValue(parsed, row, 'url') || '').trim();
      return isSyncableTabURL(url)
        && (!localDeviceID || (originID !== localDeviceID && deviceID !== localDeviceID));
    });
  } else {
    return original;
  }

  return encodeTOON(parsed.name, parsed.header, filteredRows);
}

function sanitizeOffscreenState(offscreenState, context = {}) {
  if (!offscreenState || typeof offscreenState !== 'object') {
    return null;
  }

  return {
    ...offscreenState,
    tabs_toon: sanitizeTOONPayload(offscreenState.tabs_toon, context),
    linked_devices_toon: sanitizeTOONPayload(offscreenState.linked_devices_toon, context),
    discovery_toon: sanitizeTOONPayload(offscreenState.discovery_toon, context)
  };
}

function storedOffscreenRuntimeState(stored) {
  const runtimeState = stored?.[STORAGE_KEYS.offscreenRuntimeState];
  if (runtimeState && typeof runtimeState === 'object') {
    return runtimeState;
  }

  const legacyState = stored?.[STORAGE_KEYS.offscreenState];
  if (legacyState && typeof legacyState === 'object') {
    return legacyState;
  }

  const stateTOON = typeof legacyState === 'string' ? legacyState : '';
  if (!stateTOON.trim()) {
    return null;
  }

  return {
    state_toon: stateTOON,
    updated_at: ''
  };
}

async function getOrCreateDeviceID() {
  const stored = await storageGet(STORAGE_KEYS.deviceID);
  if (stored[STORAGE_KEYS.deviceID]) {
    return stored[STORAGE_KEYS.deviceID];
  }

  const created = crypto.randomUUID();
  await storageSet({ [STORAGE_KEYS.deviceID]: created });
  return created;
}

async function hasOffscreenDocument() {
  if (!chrome.offscreen?.createDocument) {
    return false;
  }

  if (typeof chrome.offscreen.hasDocument === 'function') {
    return chrome.offscreen.hasDocument();
  }

  if (typeof chrome.runtime?.getContexts === 'function') {
    const contexts = await chrome.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [chrome.runtime.getURL(OFFSCREEN_DOCUMENT_PATH)]
    });
    return contexts.length > 0;
  }

  return false;
}

async function ensureOffscreenDocument() {
  if (!chrome.offscreen?.createDocument) {
    return false;
  }

  if (await hasOffscreenDocument()) {
    return true;
  }

  if (!offscreenDocumentPromise) {
    offscreenDocumentPromise = chrome.offscreen.createDocument({
      url: OFFSCREEN_DOCUMENT_PATH,
      reasons: [OFFSCREEN_KEEPALIVE_REASON],
      justification: OFFSCREEN_JUSTIFICATION
    })
      .then(() => true)
      .catch(() => false)
      .finally(() => {
        offscreenDocumentPromise = null;
      });
  }

  return offscreenDocumentPromise;
}

async function callOffscreen(message) {
  const ready = await ensureOffscreenDocument();
  if (!ready) {
    return { ok: false, error: 'offscreen_unavailable' };
  }

  try {
    return await chrome.runtime.sendMessage(message);
  } catch (error) {
    return { ok: false, error: error?.message || 'offscreen_message_failed' };
  }
}

async function persistOffscreenEvent(message) {
  const stored = await storageGet([
    STORAGE_KEYS.deviceID,
    STORAGE_KEYS.pairingState
  ]);
  const localDeviceID = resolveLocalDeviceID({
    state_toon: String(message?.state_toon || ''),
    document_toon: String(message?.document_toon || ''),
    pairingState: stored[STORAGE_KEYS.pairingState] || null,
    storedDeviceID: stored[STORAGE_KEYS.deviceID] || ''
  });
  const sanitizedOffscreenState = sanitizeOffscreenState({
    reason: String(message?.reason || ''),
    document_toon: String(message?.document_toon || ''),
    state_toon: String(message?.state_toon || ''),
    tabs_toon: String(message?.tabs_toon || ''),
    linked_devices_toon: String(message?.linked_devices_toon || ''),
    verification_toon: String(message?.verification_toon || ''),
    signal_toon: String(message?.signal_toon || ''),
    discovery_toon: String(message?.discovery_toon || ''),
    updated_at: new Date().toISOString()
  }, { localDeviceID });

  await storageSet({
    [STORAGE_KEYS.offscreenSignal]: String(sanitizedOffscreenState?.signal_toon || ''),
    [STORAGE_KEYS.linkedDevices]: String(sanitizedOffscreenState?.linked_devices_toon || ''),
    [STORAGE_KEYS.offscreenState]: String(sanitizedOffscreenState?.state_toon || ''),
    [STORAGE_KEYS.offscreenRuntimeState]: sanitizedOffscreenState
  });
}

function connectionStateFromTOON(rawValue) {
  const parsed = decodeTOON(String(rawValue || ''));
  const row = parsed?.rows?.[0] || [];
  return String(toonValue(parsed, row, 'connection_state', ['state']) || 'idle').trim().toLowerCase();
}

function shouldReconnectForState(state) {
  const normalized = String(state || '').trim().toLowerCase();
  return normalized === 'idle'
    || normalized === 'disconnected'
    || normalized === 'failed'
    || normalized === 'error'
    || normalized === 'unavailable';
}

function hasSavedDirectRoute(pairingState) {
  if (!pairingState || typeof pairingState !== 'object') {
    return false;
  }

  return Boolean(
    normalizePopupHostInput(pairingState.localIP || pairingState.local_ip || pairingState.host_ip || '')
    || normalizePopupHostInput(extractHostFromURL(pairingState.wsURL || pairingState.ws_url || pairingState.websocket_url || ''))
  );
}

function normalizeSavedRoute(savedRoute) {
  if (!savedRoute) {
    return null;
  }

  const routeObject = typeof savedRoute === 'string'
    ? {
        localIP: normalizePopupHostInput(savedRoute) || extractHostFromURL(savedRoute),
        wsURL: savedRoute
      }
    : savedRoute;
  if (!routeObject || typeof routeObject !== 'object') {
    return null;
  }

  const hostIP = normalizePopupHostInput(
    routeObject.localIP
    || routeObject.local_ip
    || routeObject.hostIP
    || routeObject.host_ip
    || extractHostFromURL(routeObject.wsURL || routeObject.ws_url || routeObject.websocket_url || '')
    || ''
  );
  const wsURL = hostIP ? `ws://${hostIP}:${SYNC_PORT}/bridge` : '';
  if (!hostIP || !wsURL) {
    return null;
  }

  return {
    localIP: hostIP,
    port: SYNC_PORT,
    bridgeURL: `http://${hostIP}:${SYNC_PORT}`,
    wsURL,
    updatedAt: String(routeObject.updatedAt || routeObject.updated_at || new Date().toISOString())
  };
}

function pairingStateWithSavedRoute(pairingState, savedRoute) {
  const route = normalizeSavedRoute(savedRoute);
  const base = pairingState && typeof pairingState === 'object' ? pairingState : {};
  if (!route) {
    return Object.keys(base).length > 0 ? base : null;
  }

  const baseHasRoute = hasSavedDirectRoute(base);
  const next = {
    ...base,
    localIP: baseHasRoute ? (base.localIP || route.localIP) : route.localIP,
    port: SYNC_PORT,
    bridgeURL: base.bridgeURL || route.bridgeURL,
    wsURL: baseHasRoute ? (base.wsURL || route.wsURL) : route.wsURL,
    bridgeReady: base.bridgeReady ?? true,
    bridgeState: base.bridgeState || 'ready',
    bridgeMessage: base.bridgeMessage || 'Reconnecting to saved route',
    connectRequested: true,
    connectionState: base.connectionState || 'connecting',
    lastError: ''
  };

  return next;
}

async function ensureSavedRouteConnectIntent(pairingState) {
  if (!hasSavedDirectRoute(pairingState) || pairingState?.connectRequested === true) {
    return pairingState;
  }

  const nextPairingState = {
    ...pairingState,
    connectRequested: true,
    connectionState: shouldReconnectForState(pairingState?.connectionState) || !pairingState?.connectionState
      ? 'connecting'
      : pairingState.connectionState,
    bridgeReady: pairingState?.bridgeReady ?? true,
    bridgeState: pairingState?.bridgeState || 'ready',
    bridgeMessage: pairingState?.bridgeMessage || 'Reconnecting to saved route',
    lastError: ''
  };
  await storageSet({ [STORAGE_KEYS.pairingState]: nextPairingState });
  return nextPairingState;
}

function buildConnectivitySnapshot(stored) {
  const pairingState = pairingStateWithSavedRoute(
    stored[STORAGE_KEYS.pairingState] || null,
    stored[STORAGE_KEYS.savedRoute] || null
  );
  const offscreenState = storedOffscreenRuntimeState(stored);
  const offscreenConnectionState = connectionStateFromTOON(offscreenState?.state_toon || '');
  const pairingConnectionState = String(pairingState?.connectionState || '').trim().toLowerCase();
  const connectionState = String(
    offscreenConnectionState && offscreenConnectionState !== 'idle'
      ? offscreenConnectionState
      : pairingConnectionState ||
    'idle'
  ).trim().toLowerCase();

  return {
    pairingState,
    offscreenState,
    connectionState,
    peerReachable: connectionState === 'connected'
      && Boolean(pairingState?.peerReachable ?? pairingState?.peer_reachable ?? false)
  };
}

function buildConnectivityFingerprint(snapshot) {
  return JSON.stringify({
    localIP: String(snapshot?.pairingState?.localIP || ''),
    wsURL: String(snapshot?.pairingState?.wsURL || ''),
    sessionID: String(snapshot?.pairingState?.sessionID || ''),
    online: globalThis.navigator?.onLine === false ? 'offline' : 'online'
  });
}

async function ensureConnectivityAlarm() {
  if (!chrome.alarms?.create) {
    return false;
  }

  chrome.alarms.create(CONNECTIVITY_ALARM_NAME, {
    periodInMinutes: CONNECTIVITY_ALARM_PERIOD_MINUTES
  });
  return true;
}

async function scheduleFastReconnect(_reason) {
  if (!chrome.alarms?.create) {
    return false;
  }

  try {
    chrome.alarms.create(FAST_RECONNECT_ALARM_NAME, {
      delayInMinutes: FAST_RECONNECT_ALARM_DELAY_MINUTES
    });
    return true;
  } catch (_) {
    return false;
  }
}

async function clearFastReconnect() {
  try {
    await chrome.alarms?.clear?.(FAST_RECONNECT_ALARM_NAME);
  } catch (_) {
  }
}

async function requestRestoreLink(reason, forceRefresh = false) {
  const now = Date.now();
  if (!forceRefresh && now - lastRestoreAttemptAt < 1500) {
    return { ok: true, throttled: true };
  }

  lastRestoreAttemptAt = now;
  return callOffscreen({
    type: 'OFFSCREEN_RESTORE_LINK',
    reason,
    forceRefresh
  });
}

async function evaluateConnectivity(reason, forceRefresh = false) {
  const stored = await storageGet([
    STORAGE_KEYS.pairingState,
    STORAGE_KEYS.savedRoute,
    STORAGE_KEYS.offscreenState,
    STORAGE_KEYS.offscreenRuntimeState
  ]);
  const snapshot = buildConnectivitySnapshot(stored);

  if (!snapshot.pairingState) {
    return fetchOffscreenTransportStatus({
      initialize: true,
      forceRefresh,
      reason: `${reason}_missing_pairing`
    });
  }

  snapshot.pairingState = await ensureSavedRouteConnectIntent(snapshot.pairingState);

  if (!snapshot.pairingState?.connectRequested) {
    return { ok: true, skipped: 'manual_connect_required' };
  }

  const nextFingerprint = buildConnectivityFingerprint(snapshot);
  const fingerprintChanged = connectivityFingerprint && connectivityFingerprint !== nextFingerprint;
  connectivityFingerprint = nextFingerprint;

  const disconnectedStates = new Set(['idle', 'disconnected', 'error', 'failed', 'unavailable']);
  const connectedButNotReachable = snapshot.connectionState === 'connected' && !snapshot.peerReachable;
  const linkingButNotReachable = snapshot.connectionState === 'connecting' && !snapshot.peerReachable;
  if (forceRefresh || fingerprintChanged || disconnectedStates.has(snapshot.connectionState) || connectedButNotReachable || linkingButNotReachable) {
    const result = await requestRestoreLink(
      fingerprintChanged ? `${reason}_network_changed` : reason,
      forceRefresh || fingerprintChanged
    );
    await scheduleFastReconnect(reason);
    return result;
  }

  await clearFastReconnect();
  return { ok: true, skipped: 'connection_healthy' };
}

async function fetchOffscreenTransportStatus(options = {}) {
  const stored = await storageGet([
    STORAGE_KEYS.deviceID,
    STORAGE_KEYS.pairingState,
    STORAGE_KEYS.savedRoute,
    STORAGE_KEYS.offscreenState,
    STORAGE_KEYS.offscreenRuntimeState,
    STORAGE_KEYS.linkedDevices,
    STORAGE_KEYS.offscreenSignal
  ]);
  const live = await callOffscreen({
    type: options.initialize ? 'OFFSCREEN_INIT_TRANSPORT' : 'OFFSCREEN_GET_STATE',
    initialize: Boolean(options.initialize),
    forceRefresh: Boolean(options.forceRefresh),
    reason: String(options.reason || 'transport_status')
  });
  const pairingState = await ensureSavedRouteConnectIntent(pairingStateWithSavedRoute(
    live?.state || stored[STORAGE_KEYS.pairingState] || null,
    stored[STORAGE_KEYS.savedRoute] || null
  ));
  const rawOffscreenState = live?.offscreen || storedOffscreenRuntimeState(stored);
  const localDeviceID = resolveLocalDeviceID({
    offscreenState: rawOffscreenState,
    pairingState,
    storedDeviceID: stored[STORAGE_KEYS.deviceID] || ''
  });
  const mergedOffscreenState = rawOffscreenState
    ? {
        ...rawOffscreenState,
        linked_devices_toon: String(
          rawOffscreenState.linked_devices_toon
          || stored[STORAGE_KEYS.linkedDevices]
          || ''
        ),
        signal_toon: String(
          rawOffscreenState.signal_toon
          || stored[STORAGE_KEYS.offscreenSignal]
          || ''
        )
      }
    : null;
  const offscreenState = sanitizeOffscreenState(
    mergedOffscreenState,
    { localDeviceID }
  );

  return {
    ok: Boolean(live?.ok || pairingState || offscreenState),
    error: live?.ok ? '' : String(live?.error || ''),
    pairing: live?.pairing || live?.state || pairingState || null,
    state: pairingState,
    offscreen: offscreenState,
    signal: String(live?.signal || stored[STORAGE_KEYS.offscreenSignal] || ''),
    transportOwner: String(live?.transport_owner || 'offscreen'),
    statusSource: live?.ok ? 'offscreen' : 'storage',
    localDeviceID
  };
}

async function initializeBackgroundTransport(reason) {
  await ensureOffscreenDocument();
  await ensureConnectivityAlarm();
  const status = await fetchOffscreenTransportStatus({
    initialize: true,
    reason,
    forceRefresh: reason === 'startup' || reason === 'installed'
  });
  await evaluateConnectivity(`${reason}_startup_restore`, true);
  await sendTabData(`${reason}_startup_snapshot`);
  scheduleStartupReconnectBurst(reason);
  return status;
}

function scheduleStartupReconnectBurst(reason) {
  for (const timer of startupReconnectTimers) {
    clearTimeout(timer);
  }
  startupReconnectTimers.clear();

  for (const delay of [1_000, 3_000, 7_000, 15_000, 30_000]) {
    const timer = setTimeout(() => {
      startupReconnectTimers.delete(timer);
      void evaluateConnectivity(`${reason}_startup_retry_${delay}`, true);
    }, delay);
    startupReconnectTimers.add(timer);
  }
}

async function initializeSavedRouteOnWorkerStart(reason) {
  const stored = await storageGet([
    STORAGE_KEYS.pairingState,
    STORAGE_KEYS.savedRoute
  ]);
  const pairingState = pairingStateWithSavedRoute(
    stored[STORAGE_KEYS.pairingState] || null,
    stored[STORAGE_KEYS.savedRoute] || null
  );
  if (!hasSavedDirectRoute(pairingState)) {
    return { ok: true, skipped: 'no_saved_route' };
  }

  await storageSet({
    [STORAGE_KEYS.pairingState]: {
      ...pairingState,
      connectionState: 'connecting',
      peerReachable: false,
      peerState: 'waiting',
      lastError: ''
    },
    [STORAGE_KEYS.savedRoute]: normalizeSavedRoute(pairingState) || stored[STORAGE_KEYS.savedRoute] || null
  });
  return initializeBackgroundTransport(reason);
}

function normalizePairingResponse(response) {
  const envelope = response && typeof response === 'object' ? response : {};
  const payload = envelope.pairing && typeof envelope.pairing === 'object'
    ? envelope.pairing
    : envelope.state && typeof envelope.state === 'object'
      ? envelope.state
      : envelope;
  const hasTransportRoute = Boolean(
    payload.resumeToken
    || payload.resume_token
    || payload.sessionID
    || payload.session_id
    || payload.wsURL
    || payload.ws_url
    || payload.websocket_url
    || payload.localIP
    || payload.local_ip
    || payload.host_ip
  );
  const localDeviceID = String(
    envelope.localDeviceID
    || resolveLocalDeviceID({
      offscreenState: envelope.offscreen || null
    })
  ).trim();
  const offscreenState = sanitizeOffscreenState(envelope.offscreen || null, { localDeviceID });
  const stateTable = decodeTOON(String(offscreenState?.state_toon || ''));
  const stateRow = stateTable?.rows?.[0] || [];
  const bridgeReady = Boolean(payload.bridgeReady ?? payload.ok);
  const bridgeState = String(payload.bridgeState || payload.bridge_state || (bridgeReady ? 'ready' : 'unavailable')).trim().toLowerCase();
  const bridgeMessage = String(payload.bridgeMessage || payload.bridge_message || (bridgeReady ? 'Bridge Reachable' : 'Desktop Bridge Unreachable')).trim();
  const peerReachable = Boolean(payload.peerReachable ?? payload.peer_reachable ?? false);
  const peerState = String(payload.peerState || payload.peer_state || (peerReachable ? 'reachable' : (bridgeReady ? 'waiting' : 'unavailable'))).trim().toLowerCase();
  const peerMessage = String(
    payload.peerMessage
    || payload.peer_message
    || (peerReachable
      ? 'Remote Peer Reachable'
      : (bridgeReady ? 'Bridge Ready - Waiting for Remote Peer' : 'Desktop Bridge Unreachable'))
  ).trim();
  const lastError = String(
    payload.lastError
    || payload.last_error
    || toonValue(stateTable, stateRow, 'last_error')
    || ''
  ).trim().toUpperCase();

  return {
    ok: payload.ok == null ? hasTransportRoute || Boolean(envelope.state || envelope.offscreen) : Boolean(payload.ok),
    transportOwner: String(envelope.transportOwner || envelope.transport_owner || 'offscreen'),
    statusSource: String(envelope.statusSource || envelope.status_source || 'offscreen'),
    bridgeReady,
    bridgeState,
    bridgeMessage,
    peerReachable,
    peerState,
    peerMessage,
    peerDeviceID: String(payload.peerDeviceID || payload.peer_device_id || ''),
    manualCode: String(payload.manualCode || payload.manual_code || ''),
    secretCode: String(payload.secretCode || payload.secret_code || payload.manualCode || payload.manual_code || ''),
    wsURL: String(payload.wsURL || payload.ws_url || payload.websocket_url || ''),
    localIP: String(payload.localIP || payload.local_ip || payload.host_ip || ''),
    port: SYNC_PORT,
    pairingTOON: String(payload.pairingTOON || payload.pairing_toon || payload.toon || ''),
    discoveryTOON: sanitizeTOONPayload(
      String(payload.discoveryTOON || payload.discovery_toon || offscreenState?.discovery_toon || ''),
      { localDeviceID }
    ),
    linkedDevicesTOON: sanitizeTOONPayload(
      String(payload.linkedDevicesTOON || payload.linked_devices_toon || offscreenState?.linked_devices_toon || ''),
      { localDeviceID }
    ),
    connectionState: String(
      payload.connectionState
      || payload.connection_state
      || connectionStateFromTOON(offscreenState?.state_toon || '')
      || (bridgeReady ? 'idle' : 'unavailable')
    ),
    lastError,
    sessionID: String(payload.sessionID || payload.session_id || ''),
    anchorSessionID: String(payload.anchorSessionID || payload.anchor_session_id || ''),
    resumeToken: String(payload.resumeToken || payload.resume_token || ''),
    bridgeID: String(payload.bridgeID || payload.bridge_id || ''),
    bridgeDeviceID: String(payload.bridgeDeviceID || payload.bridge_device_id || ''),
    connectRequested: Boolean(payload.connectRequested ?? payload.connect_requested)
  };
}

function extractHostFromURL(rawValue) {
  const trimmed = String(rawValue || '').trim();
  if (!trimmed) {
    return '';
  }

  try {
    return new URL(trimmed).hostname.trim();
  } catch (_) {
    return '';
  }
}

function isSupportedDirectRouteIPv4(host) {
  const octets = String(host || '')
    .split('.')
    .map((value) => Number.parseInt(value, 10));

  if (octets.length !== 4 || octets.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) {
    return false;
  }

  const [first, second] = octets;
  return first === 10
    || (first === 172 && second >= 16 && second <= 31)
    || (first === 192 && second === 168);
}

function resolvePopupRemoteDeviceID(tab) {
  return String(
    tab?.targetDeviceID
    || tab?.peerDeviceID
    || tab?.deviceID
    || tab?.device_id
    || tab?.origin_id
    || tab?.originID
    || ''
  ).trim();
}

function normalizePopupHostInput(rawValue) {
  const trimmed = String(rawValue || '').trim();
  if (!trimmed) {
    return '';
  }

  if (!COMPLETE_IPV4_PATTERN.test(trimmed)) {
    return '';
  }

  const normalized = trimmed
    .split('.')
    .map((value) => String(Number.parseInt(value, 10)))
    .join('.');

  return isSupportedDirectRouteIPv4(normalized) ? normalized : '';
}

function popupRouteIP(transportState) {
  const directIP = normalizePopupHostInput(transportState?.localIP || '');
  if (directIP) {
    return directIP;
  }

  return normalizePopupHostInput(extractHostFromURL(transportState?.wsURL || ''));
}

function popupRouteMessage(transportState, routeIP) {
  const connectionState = String(transportState?.connectionState || '').trim().toLowerCase();
  const lastError = String(transportState?.lastError || '').trim().toUpperCase();

  if (lastError === 'ETIMEDOUT') {
    return 'Verify iPhone is on the same Wi-Fi and the App is open.';
  }

  if (lastError === 'ECONNREFUSED') {
    return routeIP
      ? 'The saved iPhone route refused the connection. Retrying shortly.'
      : 'TabSyncBridge found the iPhone app, but it is not accepting the link yet. Retrying shortly.';
  }

  if (routeIP && transportState?.peerReachable) {
    return 'Connected to the iPhone app.';
  }

  if (routeIP && connectionState === 'connecting') {
    return 'Reconnecting to the saved iPhone address. Keep TabSyncBridge open on iPhone.';
  }

  if (routeIP && transportState?.bridgeReady) {
    return 'Saved iPhone address ready. Click Reconnect to retry now, or update it if the device moved.';
  }

  if (routeIP) {
    return 'Using the saved iPhone address. Click Reconnect after opening TabSyncBridge on iPhone.';
  }

  return 'Enter the address shown in the TabSyncBridge iPhone app.';
}

async function queryOpenTabs() {
  if (typeof chrome.tabs?.query !== 'function') {
    return [];
  }

  try {
    return await chrome.tabs.query({});
  } catch (_) {
    return [];
  }
}

function isSyncableTabURL(rawValue) {
  const trimmed = String(rawValue || '').trim();
  if (!trimmed) {
    return false;
  }

  try {
    const url = new URL(trimmed);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (_) {
    return false;
  }
}

function resolveLocalTabContext(pairingState, originID) {
  const browserName = detectBrowserName();
  const platform = detectPlatform();
  const deviceID = String(originID || pairingState?.deviceID || pairingState?.device_id || '').trim() || originID;
  const deviceName = String(
    pairingState?.deviceName
    || pairingState?.host_name
    || pairingState?.device_name
    || `${browserName} Profile`
  ).trim() || `${browserName} Profile`;

  return {
    originID,
    deviceID,
    deviceName,
    browserName,
    platform,
    updatedAt: new Date().toISOString()
  };
}

function buildLegacyTabDataTOON(tabs, context) {
  return encodeTOON(
    'tabs',
    ['tab_id', 'origin_id', 'device_id', 'url', 'title', 'last_updated_timestamp', 'device_name', 'browser_name', 'platform'],
    (Array.isArray(tabs) ? tabs : [])
      .filter((tab) => isSyncableTabURL(tab?.url))
      .map((tab) => ([
        String(tab?.id ?? ''),
        context.originID,
        context.deviceID,
        String(tab?.url || ''),
        String(tab?.title || ''),
        context.updatedAt,
        context.deviceName,
        context.browserName,
        context.platform
      ]))
  );
}

async function buildTabDataPayload(tabs) {
  const originID = await getOrCreateDeviceID();
  const stored = await storageGet([STORAGE_KEYS.pairingState]);
  const pairingState = stored[STORAGE_KEYS.pairingState] && typeof stored[STORAGE_KEYS.pairingState] === 'object'
    ? stored[STORAGE_KEYS.pairingState]
    : {};
  const context = resolveLocalTabContext(pairingState, originID);

  return {
    jsonPayload: JSON.stringify(
      (Array.isArray(tabs) ? tabs : [])
        .filter((tab) => isSyncableTabURL(tab?.url))
        .map((tab) => ({
          id: String(tab?.id ?? ''),
          tab_id: String(tab?.id ?? ''),
          origin_id: context.originID,
          device_id: context.deviceID,
          title: String(tab?.title || ''),
          url: String(tab?.url || ''),
          browser: context.browserName,
          browser_name: context.browserName,
          device: context.deviceName,
          device_name: context.deviceName,
          platform: context.platform,
          updated_at: context.updatedAt,
          last_updated_timestamp: context.updatedAt
        }))
    ),
    legacyPayload: buildLegacyTabDataTOON(tabs, context)
  };
}

function detectBrowserName() {
  const brands = Array.isArray(globalThis.navigator?.userAgentData?.brands)
    ? globalThis.navigator.userAgentData.brands.map((entry) => String(entry?.brand || '').trim())
    : [];
  const userAgent = String(globalThis.navigator?.userAgent || '');

  if (brands.some((brand) => /microsoft edge/i.test(brand)) || /\bEdg\//i.test(userAgent)) {
    return 'Edge';
  }

  if (brands.some((brand) => /brave/i.test(brand)) || /\bBrave\//i.test(userAgent)) {
    return 'Brave';
  }

  if (brands.some((brand) => /opera/i.test(brand)) || /\bOPR\//i.test(userAgent)) {
    return 'Opera';
  }

  if (/\bVivaldi\//i.test(userAgent)) {
    return 'Vivaldi';
  }

  if (brands.some((brand) => /chrome|chromium/i.test(brand)) || /\bChrome\//i.test(userAgent)) {
    return 'Chrome';
  }

  return 'Browser';
}

function detectPlatform() {
  const platform = String(globalThis.navigator?.userAgentData?.platform || globalThis.navigator?.platform || '').toLowerCase();
  if (platform.includes('mac')) {
    return 'macos';
  }
  if (platform.includes('win')) {
    return 'windows';
  }
  if (platform.includes('linux')) {
    return 'linux';
  }
  return 'desktop';
}

async function buildCurrentTabDataPayload() {
  const tabs = await queryOpenTabs();
  return buildTabDataPayload(tabs);
}

async function sendTabData(reason) {
  const payload = await buildCurrentTabDataPayload();
  const response = await callOffscreen({
    type: 'OFFSCREEN_SEND_TAB_SNAPSHOT',
    reason,
    jsonPayload: payload.jsonPayload,
    fallbackTOON: payload.legacyPayload
  });
  return {
    ok: Boolean(response?.ok),
    payload: payload.jsonPayload,
    legacyPayload: payload.legacyPayload
  };
}

function formatPopupTimestamp(rawValue) {
  const date = new Date(String(rawValue || ''));
  if (Number.isNaN(date.getTime())) {
    return 'Now';
  }

  return new Intl.DateTimeFormat(undefined, {
    hour: 'numeric',
    minute: '2-digit'
  }).format(date);
}

function isIOSDeviceID(rawValue) {
  const normalized = String(rawValue || '').trim().toLowerCase();
  if (!normalized) {
    return false;
  }

  return normalized.startsWith('ios-') || normalized.startsWith('safari-');
}

function popupTabsFromTOON(rawValue, localDeviceIDs = []) {
  const parsed = decodeTOON(String(rawValue || ''));
  if (!parsed || parsed.name !== 'tabs') {
    return [];
  }

  const normalizedLocalDeviceIDs = new Set(
    (Array.isArray(localDeviceIDs) ? localDeviceIDs : [localDeviceIDs])
      .map((value) => String(value || '').trim())
      .filter(Boolean)
  );
  const seenTabKeys = new Set();

  return parsed.rows
    .map((row) => {
      const originID = String(toonValue(parsed, row, 'origin_id', ['device_id', 'source_device_id']) || '').trim();
      const deviceID = String(toonValue(parsed, row, 'device_id', ['origin_id']) || originID).trim();
      const tabID = String(toonValue(parsed, row, 'tab_id', ['id']) || '').trim();
      const url = String(toonValue(parsed, row, 'url') || '').trim();
      if (!originID || !isSyncableTabURL(url)) {
        return null;
      }

      return {
        id: `${tabID || url}|${originID}`,
        tabID: tabID || `${originID}|${url}`,
        origin_id: originID,
        deviceID,
        deviceName: String(toonValue(parsed, row, 'device_name', ['host_name', 'display_name']) || deviceID).trim() || deviceID,
        browserName: String(toonValue(parsed, row, 'browser_name', ['browser', 'client_name']) || 'Browser').trim() || 'Browser',
        platform: String(toonValue(parsed, row, 'platform') || 'desktop').trim() || 'desktop',
        title: String(toonValue(parsed, row, 'title') || '').trim(),
        url,
        targetDeviceID: originID,
        updatedAt: String(toonValue(parsed, row, 'last_updated_timestamp', ['updated_at']) || new Date().toISOString()).trim(),
        source: 'shared'
      };
    })
    .filter((tab) => {
      if (!tab) {
        return false;
      }

      const remoteDeviceID = resolvePopupRemoteDeviceID(tab) || tab.deviceID || tab.origin_id;
      if (
        normalizedLocalDeviceIDs.has(tab.origin_id)
        || normalizedLocalDeviceIDs.has(tab.deviceID)
        || normalizedLocalDeviceIDs.has(remoteDeviceID)
      ) {
        return false;
      }

      const dedupeKey = `${String(tab.tabID || tab.id || tab.url).trim()}|${tab.origin_id}|${tab.url}`;
      if (seenTabKeys.has(dedupeKey)) {
        return false;
      }

      seenTabKeys.add(dedupeKey);
      return true;
    });
}

function closeQueueKey(originID, tabID, url) {
  const normalizedOriginID = String(originID || '').trim();
  const normalizedTabID = String(tabID || '').trim();
  const normalizedURL = String(url || '').trim();
  const target = normalizedTabID || normalizedURL;
  if (!normalizedOriginID || !target) {
    return '';
  }

  return `${normalizedOriginID}|${target}|${normalizedURL}`;
}

function closeQueueKeyForTab(tab) {
  return closeQueueKey(
    tab?.origin_id || tab?.originID || tab?.targetDeviceID || tab?.deviceID || tab?.device_id || '',
    tab?.tabID || tab?.tab_id || tab?.id || '',
    tab?.url || ''
  );
}

function closeQueueRowsFromTOON(rawValue) {
  const parsed = decodeTOON(String(rawValue || ''));
  if (!parsed || parsed.name !== 'close_queue') {
    return [];
  }

  return parsed.rows
    .map((row) => CLOSE_QUEUE_HEADER.map((column) => String(toonValue(parsed, row, column) || '').trim()))
    .filter((row) => closeQueueKey(row[1], row[0], row[3]) && isSyncableTabURL(row[3]));
}

function closeQueueRowsToTOON(rows) {
  return encodeTOON('close_queue', CLOSE_QUEUE_HEADER, Array.isArray(rows) ? rows : []);
}

function closeQueueRowsToTabs(rows) {
  return (Array.isArray(rows) ? rows : [])
    .map((row) => {
      const tabID = String(row?.[0] || '').trim();
      const originID = String(row?.[1] || '').trim();
      const deviceID = String(row?.[2] || originID).trim() || originID;
      const url = String(row?.[3] || '').trim();
      const requestedAt = String(row?.[9] || '').trim();
      const updatedAt = String(row?.[5] || requestedAt || new Date().toISOString()).trim();
      if (!originID || (!tabID && !url) || !isSyncableTabURL(url)) {
        return null;
      }

      return {
        id: `${tabID || url}|${originID}|queued`,
        tabID: tabID || `${originID}|${url}`,
        origin_id: originID,
        deviceID,
        deviceName: String(row?.[6] || deviceID || 'Remote Device').trim() || 'Remote Device',
        browserName: String(row?.[7] || 'Browser').trim() || 'Browser',
        platform: String(row?.[8] || 'desktop').trim() || 'desktop',
        title: String(row?.[4] || url || 'Remote Tab').trim(),
        url,
        targetDeviceID: originID,
        updatedAt,
        requestedAt,
        sourceDeviceID: String(row?.[10] || '').trim(),
        source: 'close_queue'
      };
    })
    .filter(Boolean);
}

function closeActionAckRowsFromTOON(toon) {
  const parsed = decodeTOON(String(toon || ''));
  if (!parsed || parsed.name !== 'close_action_ack') {
    return [];
  }

  return parsed.rows
    .map((row) => {
      const status = String(toonValue(parsed, row, 'status', ['result']) || '').trim().toLowerCase();
      if (status !== 'closed' && status !== 'ok' && status !== 'success') {
        return null;
      }

      const targetOriginID = String(
        toonValue(parsed, row, 'target_device_id', ['target_origin_id', 'origin_id', 'device_id'])
        || ''
      ).trim();
      const tabID = String(toonValue(parsed, row, 'tab_id', ['id']) || '').trim();
      const url = String(toonValue(parsed, row, 'url', ['target_url']) || '').trim();
      const requestedAt = String(toonValue(parsed, row, 'requested_at') || '').trim();
      if (!targetOriginID || (!tabID && !url)) {
        return null;
      }

      return {
        targetOriginID,
        tabID,
        url,
        requestedAt
      };
    })
    .filter(Boolean);
}

async function handleCloseActionAckTOON(toon) {
  const acknowledgements = closeActionAckRowsFromTOON(toon);
  if (acknowledgements.length === 0) {
    return buildPopupState();
  }

  const rows = (await readCloseQueueRows()).filter((row) => {
    const rowOriginID = String(row?.[1] || '').trim();
    const rowTabID = String(row?.[0] || '').trim();
    const rowURL = String(row?.[3] || '').trim();
    const rowRequestedAt = String(row?.[9] || '').trim();
    return !acknowledgements.some((ack) => (
      closeQueueKey(rowOriginID, rowTabID, rowURL) === closeQueueKey(ack.targetOriginID, ack.tabID, ack.url)
      && (!ack.requestedAt || !rowRequestedAt || ack.requestedAt === rowRequestedAt)
    ));
  });
  await writeCloseQueueRows(rows);
  return buildPopupState();
}

function pruneCloseQueueRows(rows, tabs, isConnected) {
  const now = Date.now();
  const activeKeys = new Set((Array.isArray(tabs) ? tabs : []).map(closeQueueKeyForTab).filter(Boolean));
  return (Array.isArray(rows) ? rows : []).filter((row) => {
    const requestedAt = Date.parse(String(row?.[9] || row?.[5] || ''));
    if (Number.isFinite(requestedAt) && now - requestedAt > CLOSE_QUEUE_MAX_AGE_MS) {
      return false;
    }

    if (!isSyncableTabURL(row?.[3])) {
      return false;
    }

    if (!isConnected) {
      return true;
    }

    return activeKeys.has(closeQueueKey(row?.[1], row?.[0], row?.[3]));
  });
}

async function readCloseQueueRows() {
  const stored = await storageGet([STORAGE_KEYS.closeQueue]);
  return closeQueueRowsFromTOON(stored[STORAGE_KEYS.closeQueue]);
}

async function writeCloseQueueRows(rows) {
  return storageSet({ [STORAGE_KEYS.closeQueue]: closeQueueRowsToTOON(rows) });
}

async function queueCloseRequest({
  sourceDeviceID,
  targetDeviceID,
  tabID,
  url,
  title,
  updatedAt,
  deviceName,
  browserName,
  platform,
  requestedAt
}) {
  const normalizedTargetDeviceID = String(targetDeviceID || '').trim();
  const normalizedTabID = String(tabID || '').trim();
  const normalizedURL = String(url || '').trim();
  if (!normalizedTargetDeviceID || (!normalizedTabID && !normalizedURL) || !isSyncableTabURL(normalizedURL)) {
    return [];
  }

  const normalizedRequestedAt = String(requestedAt || new Date().toISOString()).trim();
  const nextRow = [
    normalizedTabID,
    normalizedTargetDeviceID,
    normalizedTargetDeviceID,
    normalizedURL,
    String(title || normalizedURL || 'Remote Tab').trim(),
    String(updatedAt || normalizedRequestedAt).trim(),
    String(deviceName || normalizedTargetDeviceID || 'Remote Device').trim(),
    String(browserName || 'Browser').trim(),
    String(platform || 'desktop').trim(),
    normalizedRequestedAt,
    String(sourceDeviceID || '').trim()
  ];
  const key = closeQueueKey(nextRow[1], nextRow[0], nextRow[3]);
  const rows = (await readCloseQueueRows()).filter((row) => closeQueueKey(row[1], row[0], row[3]) !== key);
  rows.push(nextRow);
  await writeCloseQueueRows(pruneCloseQueueRows(rows, [], false));
  return rows;
}

async function flushQueuedCloseRequests(reason) {
  if (closeQueueFlushPromise) {
    return closeQueueFlushPromise;
  }

  const now = Date.now();
  if (now - lastCloseQueueFlushAt < CLOSE_QUEUE_FLUSH_INTERVAL_MS) {
    return false;
  }

  closeQueueFlushPromise = (async () => {
    lastCloseQueueFlushAt = now;
    const rows = await readCloseQueueRows();
    for (const row of rows) {
      const targetDeviceID = String(row?.[1] || '').trim();
      const tabID = String(row?.[0] || '').trim();
      const url = String(row?.[3] || '').trim();
      let sourceDeviceID = String(row?.[10] || '').trim();
      if (!sourceDeviceID) {
        sourceDeviceID = String(await getOrCreateDeviceID()).trim();
      }
      if (!targetDeviceID || (!tabID && !url)) {
        continue;
      }

      try {
        await callOffscreen({
          type: 'OFFSCREEN_SEND_TOON',
          toon: buildCloseActionTOON({
            sourceDeviceID,
            targetDeviceID,
            tabID,
            url,
            requestedAt: String(row?.[9] || new Date().toISOString()).trim()
          }),
          reason
        });
      } catch (_) {
      }
    }
    return rows.length > 0;
  })();

  try {
    return await closeQueueFlushPromise;
  } finally {
    closeQueueFlushPromise = null;
  }
}

function popupSyncStatus(transportState) {
  const connectionState = String(transportState?.connectionState || '').trim().toLowerCase();
  const lastError = String(transportState?.lastError || '').trim().toUpperCase();
  if (transportState?.peerReachable) {
    return 'Connected';
  }

  if (lastError === 'HEARTBEAT_TIMEOUT' || lastError === 'HEARTBEAT_DELAYED') {
    return 'Reconnecting...';
  }

  if (lastError === 'ECONNREFUSED') {
    return 'Reconnecting...';
  }

  if (lastError === 'ETIMEDOUT') {
    return 'Check Wi-Fi';
  }

  if (connectionState === 'connecting') {
    return 'Connecting...';
  }

  if (transportState?.bridgeReady && (transportState?.wsURL || transportState?.localIP || transportState?.port)) {
    return 'Ready to Connect';
  }

  if (transportState?.bridgeReady) {
    return 'Waiting for Socket';
  }

  if (connectionState === 'failed' || connectionState === 'error' || connectionState === 'unavailable') {
    return 'Connection Failed';
  }

  return 'Not Connected';
}

async function buildPopupState() {
  const stored = await storageGet([STORAGE_KEYS.hiddenDevices]);
  const hiddenDevices = new Set(Array.isArray(stored[STORAGE_KEYS.hiddenDevices])
    ? stored[STORAGE_KEYS.hiddenDevices].map((value) => String(value || '').trim()).filter(Boolean)
    : []);
  let transportSnapshot = await fetchOffscreenTransportStatus({
    initialize: false,
    reason: 'popup_state'
  });
  let normalizedTransport = normalizePairingResponse(transportSnapshot);
  let needsRestore = normalizedTransport.connectRequested
    && !normalizedTransport.peerReachable
    && (
      shouldReconnectForState(normalizedTransport.connectionState)
      || normalizedTransport.connectionState === 'connected'
      || normalizedTransport.connectionState === 'connecting'
    );
  if (needsRestore) {
    await evaluateConnectivity('popup_state_restore', true);
    transportSnapshot = await fetchOffscreenTransportStatus({
      initialize: false,
      reason: 'popup_state_after_restore'
    });
    normalizedTransport = normalizePairingResponse(transportSnapshot);
    needsRestore = false;
  }
  const storedLocalDeviceID = String(await getOrCreateDeviceID()).trim();
  const transportLocalDeviceID = String(transportSnapshot?.localDeviceID || '').trim();
  const normalizedLocalDeviceID = String(
    normalizedTransport?.localDeviceID
    || normalizedTransport?.deviceID
    || normalizedTransport?.device_id
    || ''
  ).trim();
  const localDeviceID = transportLocalDeviceID || normalizedLocalDeviceID || storedLocalDeviceID;
  const tabs = popupTabsFromTOON(
    transportSnapshot?.offscreen?.tabs_toon || '',
    [storedLocalDeviceID, transportLocalDeviceID, normalizedLocalDeviceID, localDeviceID]
  ).filter((tab) => !hiddenDevices.has(String(tab?.origin_id || tab?.deviceID || tab?.device_id || '').trim()));
  const isConnected = Boolean(normalizedTransport.peerReachable);
  const closeQueueRows = pruneCloseQueueRows(
    await readCloseQueueRows(),
    tabs,
    isConnected
  );
  await writeCloseQueueRows(closeQueueRows);
  if (isConnected && closeQueueRows.length > 0) {
    void flushQueuedCloseRequests('popup_state_connected');
  }
  const routeIP = popupRouteIP(normalizedTransport)
    || popupRouteIP(transportSnapshot?.state || {})
    || popupRouteIP(transportSnapshot?.pairing || {});
  const hasSavedRoute = Boolean(routeIP || normalizedTransport.wsURL || normalizedTransport.localIP);

  return {
    status: 'ready',
    command: 'GET_POPUP_STATE',
    localDeviceID,
    syncStatus: popupSyncStatus(normalizedTransport),
    isConnected,
    isReadyToConnect: !isConnected && (normalizedTransport.bridgeReady || hasSavedRoute),
    routeIP,
    routeMessage: popupRouteMessage(normalizedTransport, routeIP),
    lastError: normalizedTransport.lastError,
    tabs,
    closeQueue: closeQueueRowsToTabs(closeQueueRows),
    emptyTitle: 'No Remote Tabs',
    emptyMessage: isConnected
      ? 'Tabs from your other browsers and devices appear here.'
      : 'Connect to a TabSyncBridge device to load remote tabs.'
  };
}

async function hideRemoteDevice(originID) {
  const normalizedOriginID = String(originID || '').trim();
  if (!normalizedOriginID) {
    return { ok: false, error: 'missing_origin_id' };
  }

  const stored = await storageGet([STORAGE_KEYS.hiddenDevices]);
  const hiddenDevices = new Set(Array.isArray(stored[STORAGE_KEYS.hiddenDevices]) ? stored[STORAGE_KEYS.hiddenDevices] : []);
  hiddenDevices.add(normalizedOriginID);
  await storageSet({ [STORAGE_KEYS.hiddenDevices]: Array.from(hiddenDevices) });
  const queueRows = (await readCloseQueueRows()).filter((row) => {
    const rowOriginID = String(row?.[1] || '').trim();
    const rowDeviceID = String(row?.[2] || '').trim();
    return rowOriginID !== normalizedOriginID && rowDeviceID !== normalizedOriginID;
  });
  await writeCloseQueueRows(queueRows);
  try {
    await callOffscreen({ type: 'OFFSCREEN_REMOVE_DEVICE', originID: normalizedOriginID });
  } catch (_) {
  }
  return { ok: true };
}

async function buildDeviceVisibilityTOON(targetOriginID) {
  const sourceDeviceID = String(await getOrCreateDeviceID()).trim();
  return encodeTOON(
    'device_visibility',
    ['action', 'origin_id', 'source_device_id', 'target_origin_id', 'requested_at'],
    [[
      'REMOVE_DEVICE',
      sourceDeviceID,
      sourceDeviceID,
      String(targetOriginID || '').trim(),
      new Date().toISOString()
    ]]
  );
}

function deviceVisibilityTargetOriginIDs(toon) {
  const parsed = decodeTOON(String(toon || ''));
  if (!parsed || parsed.name !== 'device_visibility') {
    return [];
  }

  const targets = new Set();
  for (const row of parsed.rows) {
    const action = String(toonValue(parsed, row, 'action') || '').trim().toUpperCase();
    if (
      action !== 'REMOVE_DEVICE'
      && action !== 'ACTION:REMOVE_DEVICE'
      && action !== 'HIDE_DEVICE'
      && action !== 'REMOVE'
      && action !== 'HIDE'
    ) {
      continue;
    }

    const explicitTarget = String(
      toonValue(parsed, row, 'target_origin_id', ['target_device_id', 'device_id'])
      || ''
    ).trim();
    if (explicitTarget) {
      targets.add(explicitTarget);
      continue;
    }

    const sourceDeviceID = String(toonValue(parsed, row, 'source_device_id') || '').trim();
    const legacyTarget = sourceDeviceID ? '' : String(toonValue(parsed, row, 'origin_id') || '').trim();
    if (legacyTarget) {
      targets.add(legacyTarget);
    }
  }

  return Array.from(targets);
}

async function handleDeviceVisibilityTOON(toon) {
  const targetOriginIDs = deviceVisibilityTargetOriginIDs(toon);
  for (const originID of targetOriginIDs) {
    await hideRemoteDevice(originID);
  }
  return buildPopupState();
}

async function removeRemoteDevice(message) {
  const originID = String(message?.originID || message?.origin_id || message?.deviceID || message?.device_id || '').trim();
  if (!originID) {
    return { status: 'invalid_request', error: 'missing_origin_id' };
  }

  await hideRemoteDevice(originID);
  try {
    await callOffscreen({
      type: 'OFFSCREEN_SEND_TOON',
      toon: await buildDeviceVisibilityTOON(originID),
      reason: 'device_removed'
    });
  } catch (_) {
  }
  return buildPopupState();
}

async function setPopupRouteIP(message) {
  const rawHostIP = String(message?.hostIP || message?.routeIP || '').trim();
  const hostIP = normalizePopupHostInput(rawHostIP);
  const connectRequested = message?.connect !== false;

  if (rawHostIP && !hostIP) {
    return {
      status: 'invalid_request',
      error: 'invalid_ipv4'
    };
  }

  const stored = await storageGet([STORAGE_KEYS.pairingState]);
  const currentPairingState = stored[STORAGE_KEYS.pairingState] && typeof stored[STORAGE_KEYS.pairingState] === 'object'
    ? stored[STORAGE_KEYS.pairingState]
    : {};
  let nextPairingState = { ...currentPairingState };

  if (hostIP) {
    nextPairingState = {
      localIP: hostIP,
      port: SYNC_PORT,
      bridgeURL: `http://${hostIP}:${SYNC_PORT}`,
      wsURL: `ws://${hostIP}:${SYNC_PORT}/bridge`,
      sessionID: '',
      resumeToken: '',
      manualCode: '',
      secretCode: '',
      bridgeReady: true,
      bridgeState: 'ready',
      bridgeMessage: connectRequested ? 'Connecting to saved route' : 'Direct route saved',
      connectionState: connectRequested ? 'connecting' : 'idle',
      connectRequested,
      lastError: ''
    };
  } else {
    delete nextPairingState.localIP;
    delete nextPairingState.local_ip;
    delete nextPairingState.host_ip;
    delete nextPairingState.port;
    delete nextPairingState.bridgeURL;
    delete nextPairingState.wsURL;
    delete nextPairingState.ws_url;
    delete nextPairingState.websocket_url;
    delete nextPairingState.sessionID;
    delete nextPairingState.session_id;
    delete nextPairingState.resumeToken;
    delete nextPairingState.resume_token;
    delete nextPairingState.manualCode;
    delete nextPairingState.manual_code;
    delete nextPairingState.secretCode;
    delete nextPairingState.secret_code;
    delete nextPairingState.bridgeReady;
    delete nextPairingState.bridgeState;
    delete nextPairingState.bridgeMessage;
    delete nextPairingState.connectionState;
    delete nextPairingState.connectRequested;
    delete nextPairingState.lastError;
  }

  await storageSet({
    [STORAGE_KEYS.pairingState]: nextPairingState,
    [STORAGE_KEYS.savedRoute]: hostIP
      ? {
          localIP: hostIP,
          port: SYNC_PORT,
          bridgeURL: `http://${hostIP}:${SYNC_PORT}`,
          wsURL: `ws://${hostIP}:${SYNC_PORT}/bridge`,
          updatedAt: new Date().toISOString()
        }
      : null
  });
  if (hostIP && connectRequested) {
    const configTOON = encodeTOON(
      'pairing_config',
      ['host_ip', 'port', 'ws_url', 'connection_mode', 'connect_requested', 'updated_at'],
      [[
        hostIP,
        String(SYNC_PORT),
        `ws://${hostIP}:${SYNC_PORT}/bridge`,
        'direct_socket',
        'true',
        new Date().toISOString()
      ]]
    );
    const restoreResult = await callOffscreen({
      type: 'OFFSCREEN_CONNECT',
      toon: configTOON,
      reason: 'popup_route_override'
    });
    if (restoreResult?.ok !== false) {
      await sendTabData('popup_route_override');
    }
  } else {
    await callOffscreen({ type: 'OFFSCREEN_DISCONNECT' });
  }
  return buildPopupState();
}

async function markRouteInputDraft() {
  return buildPopupState();
}

function buildCloseActionTOON({
  sourceDeviceID,
  targetDeviceID,
  tabID,
  url,
  requestedAt = new Date().toISOString()
}) {
  return encodeTOON(
    'remote_tab_action',
    ['action', 'origin_id', 'source_device_id', 'target_device_id', 'tab_id', 'url', 'requested_at'],
    [[
      'ACTION:CLOSE',
      sourceDeviceID,
      sourceDeviceID,
      targetDeviceID,
      tabID,
      url,
      requestedAt
    ]]
  );
}

function closeActionTargetDeviceID(parsed, row) {
  return String(
    toonValue(parsed, row, 'target_device_id', ['target_origin_id', 'target'])
    || ''
  ).trim();
}

async function isCloseActionForThisProfile(parsed, row) {
  const targetDeviceID = closeActionTargetDeviceID(parsed, row);
  if (!targetDeviceID) {
    return true;
  }

  const localDeviceID = String(await getOrCreateDeviceID()).trim();
  return targetDeviceID === localDeviceID;
}

async function buildCloseActionAckTOON(parsed, row) {
  const localDeviceID = String(await getOrCreateDeviceID()).trim();
  const tabID = String(toonValue(parsed, row, 'tab_id', ['id']) || '').trim();
  const url = String(toonValue(parsed, row, 'url', ['target_url']) || '').trim();
  const requestedAt = String(toonValue(parsed, row, 'requested_at') || '').trim();
  const targetDeviceID = closeActionTargetDeviceID(parsed, row) || localDeviceID;
  return encodeTOON(
    'close_action_ack',
    ['status', 'origin_id', 'target_device_id', 'tab_id', 'url', 'requested_at', 'closed_at'],
    [[
      'closed',
      localDeviceID,
      targetDeviceID,
      tabID,
      url,
      requestedAt,
      new Date().toISOString()
    ]]
  );
}

async function sendCloseActionAck(parsed, row) {
  try {
    await callOffscreen({
      type: 'OFFSCREEN_SEND_TOON',
      toon: await buildCloseActionAckTOON(parsed, row),
      reason: 'remote_close_ack'
    });
  } catch (_) {
  }
}

async function dispatchRemoteClose(message) {
  const sourceDeviceID = String(message?.sourceDeviceID || message?.source_device_id || await getOrCreateDeviceID()).trim();
  const targetDeviceID = String(message?.targetDeviceID || message?.target_device_id || '').trim();
  const tabID = String(message?.tabID || message?.tab_id || '').trim();
  const url = String(message?.url || '').trim();
  const requestedAt = new Date().toISOString();

  if (!sourceDeviceID || !targetDeviceID || (!tabID && !url) || !isSyncableTabURL(url)) {
    return {
      status: 'invalid_request',
      error: 'missing_close_fields'
    };
  }

  await queueCloseRequest({
    sourceDeviceID,
    targetDeviceID,
    tabID,
    url,
    title: message?.title || '',
    updatedAt: message?.updatedAt || message?.updated_at || message?.last_updated_timestamp || '',
    deviceName: message?.deviceName || message?.device_name || '',
    browserName: message?.browserName || message?.browser_name || '',
    platform: message?.platform || '',
    requestedAt
  });
  const commandTOON = buildCloseActionTOON({
    sourceDeviceID,
    targetDeviceID,
    tabID,
    url,
    requestedAt
  });
  let response = null;
  try {
    response = await callOffscreen({
      type: 'OFFSCREEN_SEND_TOON',
      toon: commandTOON
    });
  } catch (error) {
    response = { ok: false, error: error?.message || 'send_failed' };
  }
  void evaluateConnectivity('remote_close_reconnect_guard', false);

  return {
    status: response?.ok ? 'ready' : 'queued',
    command: 'ACTION:CLOSE',
    transport: response?.ok ? 'websocket' : 'queued',
    route: 'desktop_peer',
    note: 'Safari may close the tab after the iOS Safari extension next runs.',
    origin_id: sourceDeviceID,
    target_device_id: targetDeviceID,
    tab_id: tabID,
    url,
    closeQueue: closeQueueRowsToTabs(await readCloseQueueRows()),
    error: response?.ok ? '' : response?.error || '',
    commandTOON
  };
}

async function handleRemoteClose(parsed, row) {
  const replayDecision = await remoteCloseReplayDecision(parsed, row);
  if (replayDecision.ignore) {
    await sendTabData(replayDecision.reason);
    return { ok: true, ignored: true, reason: replayDecision.reason };
  }

  const tabID = Number.parseInt(String(toonValue(parsed, row, 'tab_id', ['id']) || ''), 10);
  const targetURL = String(toonValue(parsed, row, 'url', ['target_url']) || '').trim();

  if (Number.isInteger(tabID)) {
    try {
      await chrome.tabs.remove(tabID);
      await sendTabData('remote_close_applied');
      return { ok: true, closed: true, tab_id: String(tabID), url: targetURL };
    } catch (_) {
    }
  }

  if (targetURL) {
    const tabs = await chrome.tabs.query({});
    const matchingTabID = (Array.isArray(tabs) ? tabs : [])
      .find((tab) => Number.isInteger(tab?.id) && String(tab?.url || '').trim() === targetURL)
      ?.id;
    if (Number.isInteger(matchingTabID)) {
      await chrome.tabs.remove(matchingTabID);
      await sendTabData('remote_close_applied');
      return { ok: true, closed: true, tab_id: String(matchingTabID), url: targetURL };
    }
  }

  await sendTabData('remote_close_not_found');
  return { ok: false, closed: false, error: 'tab_not_found' };
}

async function handleRemoteOpen(parsed, row) {
  const url = String(toonValue(parsed, row, 'url', ['target_url']) || '').trim();
  if (!url) {
    return { ok: false, error: 'invalid_open_url' };
  }

  await chrome.tabs.create({
    url,
    active: false
  });
  return { ok: true };
}

async function handleRemoteTOON(toon) {
  const parsed = decodeTOON(String(toon || ''));
  const row = parsed?.rows?.[0] || [];
  if (!parsed || parsed.name !== 'remote_tab_action') {
    return { ok: false, error: 'unsupported_toon' };
  }

  const action = String(toonValue(parsed, row, 'action', ['command']) || '').trim().toUpperCase();
  if (action === 'ACTION:CLOSE' || action === 'CLOSE' || action === 'CLOSE_TAB') {
    if (!(await isCloseActionForThisProfile(parsed, row))) {
      return { ok: true, ignored: true, reason: 'not_target_profile' };
    }

    const result = await handleRemoteClose(parsed, row);
    if (result?.ok && result?.closed) {
      void sendCloseActionAck(parsed, row);
    }
    return result;
  }

  if (action === 'ACTION:OPEN' || action === 'OPEN' || action === 'OPEN_TAB') {
    return handleRemoteOpen(parsed, row);
  }

  return { ok: false, error: 'unsupported_action' };
}

chrome.runtime?.onInstalled?.addListener?.(() => {
  void initializeBackgroundTransport('installed');
});

chrome.runtime?.onStartup?.addListener?.(() => {
  void (async () => {
    await armStartupRemoteCloseGuard('startup');
    await initializeBackgroundTransport('startup');
  })();
});

chrome.action?.onClicked?.addListener?.(() => {
  void initializeBackgroundTransport('action_clicked');
});

chrome.storage?.onChanged?.addListener?.((changes, areaName) => {
  if (areaName !== 'local') {
    return;
  }

  const pairingChange = changes[STORAGE_KEYS.pairingState];
  if (pairingChange) {
    const previous = pairingChange.oldValue || null;
    const next = pairingChange.newValue || null;
    const endpointChanged = String(previous?.localIP || previous?.wsURL || '') !== String(next?.localIP || next?.wsURL || '');
    if (endpointChanged) {
      void evaluateConnectivity('pairing_state_changed', true);
    } else if (shouldReconnectForState(next?.connectionState)) {
      void evaluateConnectivity('pairing_state_connection_lost', false);
    }
  }

  const savedRouteChange = changes[STORAGE_KEYS.savedRoute];
  if (savedRouteChange) {
    const previousRoute = normalizeSavedRoute(savedRouteChange.oldValue || null);
    const nextRoute = normalizeSavedRoute(savedRouteChange.newValue || null);
    const routeChanged = String(previousRoute?.wsURL || '') !== String(nextRoute?.wsURL || '');
    if (nextRoute && routeChanged) {
      void evaluateConnectivity('saved_route_changed', true);
    }
  }

  const offscreenChange = changes[STORAGE_KEYS.offscreenRuntimeState] || changes[STORAGE_KEYS.offscreenState];
  if (offscreenChange) {
    const nextState = connectionStateFromTOON(
      typeof offscreenChange.newValue === 'string'
        ? offscreenChange.newValue
        : offscreenChange.newValue?.state_toon || ''
    );
    if (shouldReconnectForState(nextState)) {
      void evaluateConnectivity('offscreen_state_changed', false);
    } else if (nextState === 'connected' || offscreenChange.newValue?.peerReachable) {
      void flushQueuedCloseRequests('offscreen_state_connected');
    }
  }
});

chrome.alarms?.onAlarm?.addListener?.((alarm) => {
  if (alarm?.name === FAST_RECONNECT_ALARM_NAME) {
    void evaluateConnectivity('fast_reconnect_alarm', true);
    return;
  }

  if (alarm?.name !== CONNECTIVITY_ALARM_NAME) {
    return;
  }

  void evaluateConnectivity(activeSyncPorts.size > 0 ? 'active_sync_alarm_heartbeat' : 'alarm_reconnect_scan', false);
});

chrome.runtime?.onConnect?.addListener?.((port) => {
  if (port?.name !== ACTIVE_SYNC_PORT_NAME) {
    return;
  }

  activeSyncPorts.add(port);
  void ensureConnectivityAlarm();
  void evaluateConnectivity('active_sync_port_connected', false);

  port.onMessage?.addListener?.((message) => {
    const type = String(message?.type || '').toUpperCase();
    if (type !== 'TABSYNC_ACTIVE_HEARTBEAT') {
      return;
    }

    void evaluateConnectivity('active_sync_port_heartbeat', false);
    try {
      port.postMessage({
        type: 'TABSYNC_ACTIVE_ACK',
        receivedAt: new Date().toISOString()
      });
    } catch (_) {
    }
  });

  port.onDisconnect?.addListener?.(() => {
    activeSyncPorts.delete(port);
  });
});

chrome.runtime?.onMessage?.addListener?.((message, _sender, sendResponse) => {
  const type = String(message?.type || '').toUpperCase();

  if (type === 'GET_POPUP_STATE' || type === 'POPUP_STATE') {
    void buildPopupState()
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({
        status: 'failed',
        error: error?.message || 'popup_state_unavailable',
        syncStatus: 'Not Connected',
        isConnected: false,
        isReadyToConnect: false,
        tabs: []
      }));
    return true;
  }

  if (type === 'MARK_ROUTE_INPUT_DRAFT') {
    void markRouteInputDraft()
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({ status: 'failed', error: error?.message || 'route_draft_failed' }));
    return true;
  }

  if (type === 'CLOSE_REMOTE_TAB') {
    void dispatchRemoteClose(message)
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({
        status: 'failed',
        error: error?.message || 'close_remote_tab_failed'
      }));
    return true;
  }

  if (type === 'REMOVE_REMOTE_DEVICE') {
    void removeRemoteDevice(message)
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({ status: 'failed', error: error?.message || 'remove_remote_device_failed' }));
    return true;
  }

  if (type === 'SET_DIRECT_ROUTE_IP') {
    void setPopupRouteIP(message)
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({
        status: 'failed',
        error: error?.message || 'set_direct_route_ip_failed'
      }));
    return true;
  }

  if (type === 'OFFSCREEN_EVENT') {
    void persistOffscreenEvent(message)
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'persist_failed' }));
    return true;
  }

  if (type === 'OFFSCREEN_REMOTE_TOON') {
    void handleRemoteTOON(message?.toon || '')
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'remote_action_failed' }));
    return true;
  }

  if (type === 'OFFSCREEN_CLOSE_ACTION_ACK') {
    void handleCloseActionAckTOON(message?.toon || '')
      .then((response) => sendResponse({ ok: true, ...response }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'close_ack_failed' }));
    return true;
  }

  if (type === 'OFFSCREEN_DEVICE_VISIBILITY') {
    void handleDeviceVisibilityTOON(message?.toon || '')
      .then((response) => sendResponse({ ok: true, ...response }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'device_visibility_failed' }));
    return true;
  }

  if (type === 'REQUEST_TAB_SNAPSHOT') {
    void buildCurrentTabDataPayload()
      .then((payload) => sendResponse({ ok: true, payload }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'snapshot_failed' }));
    return true;
  }

  if (type === 'SEND_TAB_DATA') {
    void sendTabData(String(message?.reason || 'manual_tab_sync'))
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'snapshot_failed' }));
    return true;
  }

  if (type === 'ENSURE_OFFSCREEN_DOCUMENT') {
    void ensureOffscreenDocument()
      .then(async (ok) => {
        if (!ok) {
          return { ok: false, error: 'offscreen_bootstrap_failed' };
        }

        const status = await fetchOffscreenTransportStatus({
          initialize: true,
          reason: 'ensure_offscreen_document'
        });
        return {
          ok: Boolean(status?.ok),
          transportOwner: status.transportOwner,
          statusSource: status.statusSource
        };
      })
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'offscreen_bootstrap_failed' }));
    return true;
  }

  if (type === 'GET_PAIRING_STATE' || type === 'REFRESH_PAIRING_STATE') {
    void fetchOffscreenTransportStatus({
      initialize: type === 'REFRESH_PAIRING_STATE',
      forceRefresh: type === 'REFRESH_PAIRING_STATE',
      reason: type === 'REFRESH_PAIRING_STATE' ? 'refresh_pairing_state' : 'get_pairing_state'
    })
      .then((response) => sendResponse(normalizePairingResponse(response)))
      .catch((error) => sendResponse(normalizePairingResponse({
        ok: false,
        transportOwner: 'offscreen',
        statusSource: 'worker_error',
        bridgeReady: false,
        bridgeState: 'unavailable',
        bridgeMessage: 'Desktop Bridge Unreachable',
        error: error?.message || 'pairing_unavailable'
      })));
    return true;
  }

  if (type === 'GET_WEBRTC_STATE') {
    void fetchOffscreenTransportStatus({
      initialize: false,
      reason: 'get_webrtc_state'
    })
      .then((snapshot) => {
        sendResponse({
          ok: Boolean(snapshot?.ok),
          state: snapshot?.state || null,
          offscreen: snapshot?.offscreen || null,
          signal: snapshot?.signal || '',
          transportOwner: snapshot?.transportOwner || 'offscreen',
          statusSource: snapshot?.statusSource || 'storage'
        });
      })
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'state_unavailable' }));
    return true;
  }

  if (type === 'CONNECT_PERSISTENT_LINK') {
    void callOffscreen({ type: 'OFFSCREEN_CONNECT', toon: String(message?.toon || message?.configTOON || '') })
      .then((response) => sendResponse(response || { ok: false, error: 'persistent_connect_failed' }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'persistent_connect_failed' }));
    return true;
  }

  if (type === 'SEND_PERSISTENT_TOON') {
    void callOffscreen({ type: 'OFFSCREEN_SEND_TOON', toon: String(message?.toon || '') })
      .then((response) => sendResponse(response || { ok: false, error: 'persistent_send_failed' }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'persistent_send_failed' }));
    return true;
  }

  if (type === 'GET_PERSISTENT_LINK_STATE') {
    void fetchOffscreenTransportStatus({
      initialize: false,
      reason: 'get_persistent_link_state'
    })
      .then((response) => sendResponse(response || { ok: false, error: 'persistent_state_failed' }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'persistent_state_failed' }));
    return true;
  }

  if (type === 'DISCONNECT_PERSISTENT_LINK') {
    void callOffscreen({ type: 'OFFSCREEN_DISCONNECT' })
      .then((response) => sendResponse(response || { ok: false, error: 'persistent_disconnect_failed' }))
      .catch((error) => sendResponse({ ok: false, error: error?.message || 'persistent_disconnect_failed' }));
    return true;
  }

  return false;
});

chrome.tabs?.onUpdated?.addListener?.((tabID, changeInfo, tab) => {
  if (!changeInfo.url && changeInfo.status !== 'complete' && !changeInfo.title) {
    return;
  }

  void sendTabData('tab_updated');
});

chrome.tabs?.onCreated?.addListener?.((tab) => {
  void sendTabData('tab_created');
});

chrome.tabs?.onRemoved?.addListener?.(() => {
  void sendTabData('tab_removed');
});

void (async () => {
  await armStartupRemoteCloseGuard('service_worker_boot');
  await initializeSavedRouteOnWorkerStart('service_worker_boot');
})();
