const extensionAPI = globalThis.chrome ?? null;
const runtimeAPI = extensionAPI?.runtime ?? null;
const tabsAPI = extensionAPI?.tabs ?? null;
const MAX_IPV4_INPUT_LENGTH = 15;
const ROUTE_INPUT_DEBOUNCE_MS = 1500;
const POPUP_REFRESH_MS = 2_000;
const COMPLETE_IPV4_PATTERN = /^(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)(?:\.(?:25[0-5]|2[0-4]\d|1\d\d|[1-9]?\d)){3}$/;

const statusDot = document.getElementById('status-dot');
const statusText = document.getElementById('status-text');
const routeInput = document.getElementById('route-ip');
const routeSave = document.getElementById('route-save');
const routeMessage = document.getElementById('route-message');
const tabTree = document.getElementById('tab-tree');
const emptyState = document.getElementById('empty-state');
const emptyTitle = document.getElementById('empty-title');
const emptyMessage = document.getElementById('empty-message');

let currentPopupState = {
  localDeviceID: '',
  tabs: [],
  closeQueue: [],
  isConnected: false,
  isReadyToConnect: false,
  syncStatus: 'Not Connected',
  routeIP: '',
  routeMessage: 'Enter the address shown in the TabSyncBridge iPhone app.',
  emptyTitle: 'No Remote Tabs',
  emptyMessage: 'Tabs from your other browsers and devices will appear here after you connect.'
};
let isSavingRoute = false;
let routeInputSettled = true;
let routeInputDebounceTimer = null;
let debouncedRouteValue = '';
let popupRefreshTimer = null;
let routeInputIsEditing = false;
let routeDraftMarked = false;
let pendingStateLoad = null;
let stateLoadTimer = 0;
let renderFingerprint = '';

document.addEventListener('DOMContentLoaded', () => {
  routeSave.addEventListener('click', () => {
    void saveRouteIP();
  });
  routeInput.addEventListener('input', () => {
    routeInputIsEditing = true;
    void markRouteDraft();
    const sanitizedValue = sanitizeRouteInput(routeInput.value);
    if (routeInput.value !== sanitizedValue) {
      routeInput.value = sanitizedValue;
    }
    scheduleRouteValidation();
    syncRouteControls();
  });
  routeInput.addEventListener('focus', () => {
    routeInputIsEditing = true;
  });
  routeInput.addEventListener('blur', () => {
    routeInputIsEditing = false;
    syncRouteControls();
  });
  routeInput.addEventListener('keydown', (event) => {
    if (event.key === 'Enter') {
      event.preventDefault();
      routeMessage.textContent = 'Click Connect to start the link.';
    }
  });
  void loadPopupState();
  startPopupRefresh();
});

globalThis.addEventListener('unload', () => {
  if (popupRefreshTimer) {
    globalThis.clearInterval(popupRefreshTimer);
    popupRefreshTimer = null;
  }
});

function defaultPopupState() {
  return {
    status: 'ready',
    localDeviceID: '',
    syncStatus: 'Not Connected',
    isConnected: false,
    isReadyToConnect: false,
    routeIP: '',
    routeMessage: 'Enter the address shown in the TabSyncBridge iPhone app.',
    emptyTitle: 'No Remote Tabs',
    emptyMessage: 'Tabs from your other browsers and devices will appear here after you connect.',
    tabs: [],
    closeQueue: []
  };
}

function clearRouteValidationTimer() {
  if (!routeInputDebounceTimer) {
    return;
  }

  globalThis.clearTimeout(routeInputDebounceTimer);
  routeInputDebounceTimer = null;
}

function sanitizeRouteInput(rawValue) {
  return String(rawValue || '')
    .replace(/[^\d.]/g, '')
    .slice(0, MAX_IPV4_INPUT_LENGTH);
}

function isSupportedDirectRouteIPv4(host) {
  const octets = String(host || '')
    .split('.')
    .map((value) => Number.parseInt(value, 10));

  if (octets.length !== 4 || octets.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) {
    return false;
  }

  const [first, second] = octets;
  return first === 10
    || (first === 172 && second >= 16 && second <= 31)
    || (first === 192 && second === 168);
}

function normalizeHostInput(rawValue) {
  const trimmed = String(rawValue || '').trim();
  if (!trimmed || !COMPLETE_IPV4_PATTERN.test(trimmed)) {
    return '';
  }

  const normalized = trimmed
    .split('.')
    .map((value) => String(Number.parseInt(value, 10)))
    .join('.');

  return isSupportedDirectRouteIPv4(normalized) ? normalized : '';
}

function setRouteInputValue(value) {
  clearRouteValidationTimer();
  routeInput.value = String(value || '');
  debouncedRouteValue = routeInput.value.trim();
  routeInputSettled = true;
}

function scheduleRouteValidation() {
  clearRouteValidationTimer();

  const rawValue = routeInput.value.trim();
  if (!rawValue) {
    debouncedRouteValue = '';
    routeInputSettled = true;
    return;
  }

  if (normalizeHostInput(rawValue)) {
    debouncedRouteValue = rawValue;
    routeInputSettled = true;
    return;
  }

  routeInputSettled = false;
  routeInputDebounceTimer = globalThis.setTimeout(() => {
    routeInputDebounceTimer = null;
    debouncedRouteValue = routeInput.value.trim();
    routeInputSettled = true;
    syncRouteControls();
  }, ROUTE_INPUT_DEBOUNCE_MS);
}

async function fetchPopupState() {
  if (typeof runtimeAPI?.sendMessage !== 'function') {
    return defaultPopupState();
  }

  try {
    const response = await runtimeAPI.sendMessage({ type: 'GET_POPUP_STATE' });
    if (response?.status === 'ready') {
      return response;
    }
  } catch (_) {
  }

  return defaultPopupState();
}

function normalizeOriginID(value) {
  return String(value || '').trim();
}

function isSyncableTabURL(rawValue) {
  const trimmed = String(rawValue || '').trim();
  if (!trimmed) {
    return false;
  }

  try {
    const url = new URL(trimmed);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (_) {
    return false;
  }
}

function formatTimestamp(rawValue) {
  const date = new Date(String(rawValue || ''));
  if (Number.isNaN(date.getTime())) {
    return 'Now';
  }

  return new Intl.DateTimeFormat(undefined, {
    hour: 'numeric',
    minute: '2-digit'
  }).format(date);
}

function filterRemoteTabs(tabs, localOriginID) {
  const normalizedLocalOriginID = normalizeOriginID(localOriginID);
  const seenTabKeys = new Set();

  return (Array.isArray(tabs) ? tabs : []).filter((tab) => {
    const originID = normalizeOriginID(tab?.origin_id || tab?.originID);
    const deviceID = normalizeOriginID(tab?.device_id || tab?.deviceID || originID);
    const url = String(tab?.url || '').trim();
    const tabID = String(tab?.tabID || tab?.tab_id || tab?.id || '').trim();

    if ((!originID && !deviceID) || !isSyncableTabURL(url)) {
      return false;
    }

    if (
      normalizedLocalOriginID
      && (
        originID === normalizedLocalOriginID
        || deviceID === normalizedLocalOriginID
      )
    ) {
      return false;
    }

    const dedupeOrigin = originID || deviceID;
    const dedupeKey = `${dedupeOrigin}|${tabID || url}|${url}`;
    if (seenTabKeys.has(dedupeKey)) {
      return false;
    }

    seenTabKeys.add(dedupeKey);
    return true;
  });
}

function closeQueueKey(tab) {
  const originID = normalizeOriginID(tab?.origin_id || tab?.originID || tab?.targetDeviceID || tab?.deviceID || tab?.device_id);
  const tabID = String(tab?.tabID || tab?.tab_id || tab?.id || '').trim();
  const url = String(tab?.url || '').trim();
  const target = tabID || url;
  return originID && target && isSyncableTabURL(url) ? `${originID}|${target}|${url}` : '';
}

function normalizeCloseQueueTabs(tabs) {
  const seen = new Set();
  return (Array.isArray(tabs) ? tabs : []).filter((tab) => {
    const key = closeQueueKey(tab);
    if (!key || seen.has(key)) {
      return false;
    }
    seen.add(key);
    return true;
  });
}

function buildTabTree(tabs) {
  const deviceMap = new Map();

  for (const tab of tabs) {
    const deviceID = String(tab?.deviceID || tab?.device_id || tab?.origin_id || '').trim();
    const deviceName = String(tab?.deviceName || tab?.device_name || tab?.device || deviceID || 'Remote Device').trim() || 'Remote Device';
    const browserName = String(tab?.browserName || tab?.browser_name || tab?.browser || 'Browser').trim() || 'Browser';
    const updatedAt = Date.parse(String(tab?.updatedAt || tab?.updated_at || '')) || 0;
    const deviceKey = deviceID || deviceName;

    if (!deviceMap.has(deviceKey)) {
      deviceMap.set(deviceKey, {
        id: deviceKey,
        name: deviceName,
        latestUpdated: updatedAt,
        browsers: new Map()
      });
    }

    const deviceGroup = deviceMap.get(deviceKey);
    deviceGroup.latestUpdated = Math.max(deviceGroup.latestUpdated, updatedAt);

    const browserKey = browserName.toLowerCase();
    if (!deviceGroup.browsers.has(browserKey)) {
      deviceGroup.browsers.set(browserKey, {
        id: `${deviceKey}|${browserKey}`,
        name: browserName,
        latestUpdated: updatedAt,
        tabs: []
      });
    }

    const browserGroup = deviceGroup.browsers.get(browserKey);
    browserGroup.latestUpdated = Math.max(browserGroup.latestUpdated, updatedAt);
    browserGroup.tabs.push(tab);
  }

  return Array.from(deviceMap.values())
    .map((deviceGroup) => ({
      ...deviceGroup,
      browsers: Array.from(deviceGroup.browsers.values())
        .map((browserGroup) => ({
          ...browserGroup,
          tabs: browserGroup.tabs.sort((left, right) => {
            const leftUpdated = Date.parse(String(left?.updatedAt || left?.updated_at || '')) || 0;
            const rightUpdated = Date.parse(String(right?.updatedAt || right?.updated_at || '')) || 0;
            if (leftUpdated === rightUpdated) {
              return String(left?.title || left?.url || '').localeCompare(String(right?.title || right?.url || ''));
            }
            return rightUpdated - leftUpdated;
          })
        }))
        .sort((left, right) => {
          if (left.latestUpdated === right.latestUpdated) {
            return left.name.localeCompare(right.name);
          }
          return right.latestUpdated - left.latestUpdated;
        })
    }))
    .sort((left, right) => {
      if (left.latestUpdated === right.latestUpdated) {
        return left.name.localeCompare(right.name);
      }
      return right.latestUpdated - left.latestUpdated;
    });
}

async function loadPopupState() {
  if (pendingStateLoad) {
    return pendingStateLoad;
  }

  pendingStateLoad = (async () => {
    const state = await fetchPopupState();
    renderPopup(state);
  })();

  try {
    await pendingStateLoad;
  } finally {
    pendingStateLoad = null;
  }
}

function schedulePopupStateLoad() {
  globalThis.clearTimeout(stateLoadTimer);
  stateLoadTimer = globalThis.setTimeout(() => {
    void loadPopupState();
  }, 120);
}

function startPopupRefresh() {
  if (popupRefreshTimer) {
    return;
  }

  popupRefreshTimer = globalThis.setInterval(() => {
    if (isSavingRoute || routeInputIsEditing || !routeInputSettled || document.hidden) {
      return;
    }

    void loadPopupState();
  }, POPUP_REFRESH_MS);

  extensionAPI?.storage?.onChanged?.addListener?.((changes, areaName) => {
    if (areaName !== 'local') {
      return;
    }

    if (
      changes.tabsync_local_pairing
      || changes.tabsync_saved_direct_route
      || changes.offscreen_state_toon
      || changes.tabsync_offscreen_runtime_state
      || changes.offscreen_linked_devices_toon
      || changes.offscreen_signal_toon
      || changes.tabsync_close_queue_toon
    ) {
      schedulePopupStateLoad();
    }
  });
}

function renderPopup(state) {
  currentPopupState = {
    ...currentPopupState,
    ...state
  };

  const localOriginID = String(currentPopupState.localDeviceID || '');
  const remoteTabs = filterRemoteTabs(
    Array.isArray(currentPopupState.tabs) ? currentPopupState.tabs : [],
    localOriginID
  );
  const closeQueueTabs = filterRemoteTabs(
    normalizeCloseQueueTabs(currentPopupState.closeQueue),
    localOriginID
  );
  const queuedKeys = new Set(closeQueueTabs.map(closeQueueKey).filter(Boolean));
  const activeRemoteTabs = remoteTabs.filter((tab) => !queuedKeys.has(closeQueueKey(tab)));
  const queuedGroups = buildTabTree(closeQueueTabs);
  const deviceGroups = buildTabTree(activeRemoteTabs);
  const nextFingerprint = JSON.stringify({
    status: currentPopupState.syncStatus || '',
    connected: Boolean(currentPopupState.isConnected),
    ready: Boolean(currentPopupState.isReadyToConnect),
    routeIP: currentPopupState.routeIP || '',
    routeMessage: currentPopupState.routeMessage || '',
    tabs: activeRemoteTabs.map((tab) => [
      tab.tabID || tab.tab_id || tab.id || '',
      tab.origin_id || tab.originID || '',
      tab.deviceID || tab.device_id || '',
      tab.title || '',
      tab.url || '',
      tab.updatedAt || tab.updated_at || ''
    ]),
    closeQueue: closeQueueTabs.map((tab) => [
      tab.tabID || tab.tab_id || tab.id || '',
      tab.origin_id || tab.originID || '',
      tab.deviceID || tab.device_id || '',
      tab.title || '',
      tab.url || '',
      tab.updatedAt || tab.updated_at || '',
      tab.requestedAt || tab.requested_at || ''
    ])
  });

  if (nextFingerprint === renderFingerprint && !routeInputIsEditing) {
    return;
  }
  renderFingerprint = nextFingerprint;

  tabTree.replaceChildren();
  emptyState.hidden = deviceGroups.length > 0 || queuedGroups.length > 0;
  emptyTitle.textContent = currentPopupState.emptyTitle || defaultPopupState().emptyTitle;
  emptyMessage.textContent = currentPopupState.emptyMessage || defaultPopupState().emptyMessage;

  statusText.textContent = currentPopupState.syncStatus || 'Not Connected';
  statusDot.className = 'status-dot';
  if (currentPopupState.isConnected) {
    statusDot.classList.add('connected');
  } else if (currentPopupState.isReadyToConnect) {
    statusDot.classList.add('ready');
  }

  if (!routeInputIsEditing && document.activeElement !== routeInput) {
    setRouteInputValue(currentPopupState.routeIP || '');
  }
  routeMessage.textContent = currentPopupState.routeMessage || defaultPopupState().routeMessage;
  syncRouteControls();

  if (queuedGroups.length > 0) {
    tabTree.appendChild(renderCloseQueueSection(queuedGroups));
  }

  for (const deviceGroup of deviceGroups) {
    tabTree.appendChild(renderDeviceGroup(deviceGroup));
  }
}

function renderCloseQueueSection(groups) {
  const section = document.createElement('section');
  section.className = 'close-queue-section';

  const title = document.createElement('h2');
  title.className = 'close-queue-title';
  title.textContent = 'Close Queued';
  section.append(title);

  for (const group of groups) {
    section.appendChild(renderDeviceGroup(group, { queued: true }));
  }

  return section;
}

function renderDeviceGroup(group, options = {}) {
  const isQueued = Boolean(options.queued);
  const section = document.createElement('section');
  section.className = isQueued ? 'device-group close-queue-group' : 'device-group';

  const header = document.createElement('div');
  header.className = 'device-header';

  const titleBlock = document.createElement('div');
  titleBlock.className = 'device-title-block';

  const title = document.createElement('h2');
  title.className = 'device-title';
  title.textContent = group.name;

  const subtitle = document.createElement('p');
  subtitle.className = 'device-subtitle';
  subtitle.textContent = isQueued
    ? `${group.browsers.reduce((count, browser) => count + browser.tabs.length, 0)} close queued`
    : `${group.browsers.reduce((count, browser) => count + browser.tabs.length, 0)} remote tabs`;

  titleBlock.append(title, subtitle);
  header.append(titleBlock);
  if (isQueued) {
    const queuedBadge = document.createElement('span');
    queuedBadge.className = 'queued-badge';
    queuedBadge.textContent = 'Queued';
    header.append(queuedBadge);
  } else {
    const removeButton = document.createElement('button');
    removeButton.className = 'device-remove-button';
    removeButton.type = 'button';
    removeButton.textContent = 'Remove';
    removeButton.addEventListener('click', () => {
      void removeDeviceGroup(group, removeButton);
    });
    header.append(removeButton);
  }
  section.append(header);

  for (const browserGroup of group.browsers) {
    section.appendChild(renderBrowserGroup(browserGroup, { queued: isQueued }));
  }

  return section;
}

function renderBrowserGroup(group, options = {}) {
  const isQueued = Boolean(options.queued);
  const section = document.createElement('section');
  section.className = 'browser-group';

  const header = document.createElement('div');
  header.className = 'browser-header';

  const title = document.createElement('h3');
  title.className = 'browser-title';
  title.textContent = group.name;

  const count = document.createElement('span');
  count.className = 'browser-count';
  count.textContent = String(group.tabs.length);

  header.append(title, count);
  section.append(header);

  const list = document.createElement('div');
  list.className = 'tab-list';
  for (const tab of group.tabs) {
    list.appendChild(renderTabRow(tab, { queued: isQueued }));
  }

  section.append(list);
  return section;
}

function renderTabRow(tab, options = {}) {
  const isQueued = Boolean(options.queued);
  const row = document.createElement('article');
  row.className = isQueued ? 'tab-row close-queued' : 'tab-row';

  const openButton = document.createElement('button');
  openButton.className = 'tab-open';
  openButton.type = 'button';
  openButton.addEventListener('click', () => {
    if (tab?.url) {
      if (typeof tabsAPI?.create === 'function') {
        void tabsAPI.create({ url: tab.url });
      } else {
        globalThis.open(tab.url, '_blank');
      }
    }
  });

  const title = document.createElement('p');
  title.className = 'tab-title';
  title.textContent = tab.title || tab.url || 'Remote Tab';

  openButton.append(title);

  const meta = document.createElement('div');
  meta.className = 'tab-meta';

  const updated = document.createElement('span');
  updated.className = 'tab-updated';
  updated.textContent = `${isQueued ? 'Queued' : 'Updated'} ${formatTimestamp(tab.requestedAt || tab.requested_at || tab.updatedAt || tab.updated_at)}`;

  const closeButton = document.createElement('button');
  closeButton.className = isQueued ? 'close-button queued' : 'close-button';
  closeButton.type = 'button';
  closeButton.textContent = isQueued ? 'Queued' : 'Close';
  closeButton.disabled = isQueued;
  if (!isQueued) {
    closeButton.addEventListener('click', () => {
      void closeTab(tab, closeButton);
    });
  }

  meta.append(updated, closeButton);
  row.append(openButton, meta);
  return row;
}

function syncRouteControls() {
  const rawValue = routeInput.value.trim();
  const normalizedInput = normalizeHostInput(rawValue);
  const normalizedSettledInput = routeInputSettled ? normalizeHostInput(debouncedRouteValue) : '';
  const normalizedSavedRoute = normalizeHostInput(currentPopupState.routeIP || '');
  const hasPendingInput = rawValue.length > 0 && !routeInputSettled;
  const hasValidationError = rawValue.length > 0 && routeInputSettled && !normalizedInput;
  const canClearSavedRoute = rawValue.length === 0 && Boolean(normalizedSavedRoute);
  const canSaveNewRoute = rawValue.length > 0
    && Boolean(normalizedSettledInput)
    && normalizedSettledInput === normalizedInput
    && normalizedInput !== normalizedSavedRoute;
  const canReconnectSavedRoute = rawValue.length > 0
    && !currentPopupState.isConnected
    && Boolean(normalizedSavedRoute)
    && Boolean(normalizedSettledInput)
    && normalizedSettledInput === normalizedInput
    && normalizedInput === normalizedSavedRoute;

  routeInput.classList.toggle('invalid', hasValidationError);
  routeSave.disabled = isSavingRoute
    || hasPendingInput
    || hasValidationError
    || (!canClearSavedRoute && !canSaveNewRoute && !canReconnectSavedRoute);
  routeSave.textContent = rawValue.length === 0
    ? 'Clear'
    : hasPendingInput
      ? 'Waiting'
      : canReconnectSavedRoute
        ? 'Reconnect'
        : 'Connect';

  if (hasPendingInput) {
    routeMessage.textContent = 'Finish entering the iPhone address before TabSyncBridge connects.';
  } else if (hasValidationError) {
    routeMessage.textContent = 'Enter the private Wi-Fi address shown in the iPhone app.';
  } else if (canReconnectSavedRoute) {
    routeMessage.textContent = currentPopupState.routeMessage || 'Click Reconnect to retry the saved iPhone address.';
  } else {
    routeMessage.textContent = currentPopupState.routeMessage || defaultPopupState().routeMessage;
  }
}

function renderPendingRouteState() {
  statusDot.className = 'status-dot ready';
  statusText.textContent = 'Connecting...';
  routeMessage.textContent = 'Connecting to the iPhone app.';
}

async function saveRouteIP() {
  if (isSavingRoute || typeof runtimeAPI?.sendMessage !== 'function') {
    return;
  }

  const rawValue = routeInput.value.trim();
  const normalizedHost = routeInputSettled ? normalizeHostInput(debouncedRouteValue) : '';
  if (rawValue.length > 0 && !routeInputSettled) {
    routeMessage.textContent = 'Finish entering the iPhone address before TabSyncBridge connects.';
    syncRouteControls();
    return;
  }

  if (rawValue.length > 0 && !normalizedHost) {
    routeMessage.textContent = 'Enter the private Wi-Fi address shown in the iPhone app.';
    syncRouteControls();
    return;
  }

  isSavingRoute = true;
  routeSave.textContent = 'Saving';
  routeSave.disabled = true;
  renderPendingRouteState();

  try {
    const response = await runtimeAPI.sendMessage({
      type: 'SET_DIRECT_ROUTE_IP',
      hostIP: normalizedHost,
      connect: true
    });

    if (response?.status === 'ready') {
      routeInputIsEditing = false;
      routeDraftMarked = false;
      renderPopup(response);
      return;
    }

    routeMessage.textContent = 'TabSyncBridge could not save that IPv4 route.';
  } catch (_) {
    routeMessage.textContent = 'TabSyncBridge could not reach the background service.';
  } finally {
    isSavingRoute = false;
    syncRouteControls();
  }
}

async function markRouteDraft() {
  if (routeDraftMarked || typeof runtimeAPI?.sendMessage !== 'function') {
    return;
  }

  routeDraftMarked = true;
  try {
    await runtimeAPI.sendMessage({ type: 'MARK_ROUTE_INPUT_DRAFT' });
  } catch (_) {
  }
}

async function closeTab(tab, button) {
  button.disabled = true;
  button.textContent = 'Closing';

  if (typeof runtimeAPI?.sendMessage !== 'function') {
    button.disabled = false;
    button.textContent = 'Close';
    return;
  }

  try {
    const response = await runtimeAPI.sendMessage({
      type: 'CLOSE_REMOTE_TAB',
      sourceDeviceID: currentPopupState.localDeviceID || '',
      targetDeviceID: tab.targetDeviceID || tab.origin_id || tab.originID || '',
      tabID: tab.tabID || tab.tab_id || tab.id || '',
      url: tab.url || '',
      title: tab.title || '',
      updatedAt: tab.updatedAt || tab.updated_at || '',
      deviceName: tab.deviceName || tab.device_name || tab.device || '',
      browserName: tab.browserName || tab.browser_name || tab.browser || '',
      platform: tab.platform || ''
    });

    if (response?.status === 'ready' || response?.status === 'queued') {
      button.textContent = response.status === 'queued' ? 'Queued' : 'Closing';
      if (Array.isArray(response?.closeQueue)) {
        currentPopupState.closeQueue = response.closeQueue;
      }
      await loadPopupState();
      return;
    }
  } catch (_) {
  }

  button.disabled = false;
  button.textContent = 'Close';
}

async function removeDeviceGroup(group, button) {
  const firstTab = group?.browsers?.flatMap((browser) => browser.tabs || [])?.[0] || null;
  const originID = String(firstTab?.origin_id || firstTab?.originID || firstTab?.device_id || firstTab?.deviceID || group?.id || '').trim();
  if (!originID || typeof runtimeAPI?.sendMessage !== 'function') {
    return;
  }

  button.disabled = true;
  button.textContent = 'Removing';
  try {
    const response = await runtimeAPI.sendMessage({
      type: 'REMOVE_REMOTE_DEVICE',
      originID
    });
    if (response?.status === 'ready') {
      renderPopup(response);
      return;
    }
  } catch (_) {
  }
  button.disabled = false;
  button.textContent = 'Remove';
}
