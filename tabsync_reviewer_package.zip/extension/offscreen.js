(() => {
  'use strict';

const extensionAPI = globalThis.chrome ?? null;
const localLinkController = globalThis.TabSyncLocalLink?.createController?.() ?? null;

let controllerReadyPromise = null;
let pairingRefreshPromise = null;
let pairingRefreshForce = false;
const TRANSPORT_HEALTHCHECK_MS = 5_000;
const SERVICE_WORKER_PORT_NAME = 'tabsync-active-sync';
const SERVICE_WORKER_PORT_HEARTBEAT_MS = 20_000;
let serviceWorkerPort = null;
let serviceWorkerPortHeartbeatTimer = null;

function errorMessage(error, fallback) {
  return error?.message || fallback;
}

function ensureControllerReady() {
  if (!localLinkController) {
    return Promise.reject(new Error('local_link_controller_unavailable'));
  }

  if (!controllerReadyPromise) {
    // Gate all transport work behind the initial restore so the offscreen
    // document remains the authoritative transport owner.
    controllerReadyPromise = Promise.resolve(localLinkController.restore());
  }

  return controllerReadyPromise;
}

async function refreshPairing(forceRefresh = false) {
  const wantsForceRefresh = Boolean(forceRefresh);

  if (pairingRefreshPromise) {
    if (!wantsForceRefresh || pairingRefreshForce) {
      return pairingRefreshPromise;
    }

    try {
      await pairingRefreshPromise;
    } catch (_) {
    }
  }

  pairingRefreshForce = wantsForceRefresh;
  pairingRefreshPromise = (async () => {
    await ensureControllerReady();
    return localLinkController.generatePairing(wantsForceRefresh);
  })()
    .finally(() => {
      pairingRefreshPromise = null;
      pairingRefreshForce = false;
    });

  return pairingRefreshPromise;
}

async function buildRuntimeStateResponse(options = {}) {
  await ensureControllerReady();

  let pairing = null;
  if (options.initialize || options.forceRefresh) {
    pairing = await refreshPairing(Boolean(options.forceRefresh));
    await keepTransportAlive(Boolean(options.forceRefresh));
  }

  let runtimeState = localLinkController.getRuntimeState();
  const state = runtimeState?.state || {};
  const connectionState = String(state.connectionState || '').trim().toLowerCase();
  const peerReachable = Boolean(state.peerReachable ?? state.peer_reachable ?? false);
  if (
    state.connectRequested
    && !(connectionState === 'connected' && peerReachable)
    && !options.initialize
    && !options.forceRefresh
  ) {
    await keepTransportAlive(false);
    runtimeState = localLinkController.getRuntimeState();
  }

  return {
    ok: Boolean(pairing?.ok ?? runtimeState?.ok),
    transport_owner: 'offscreen',
    initialized: Boolean(options.initialize || options.forceRefresh),
    pairing: pairing || runtimeState?.state || null,
    state: runtimeState?.state || pairing || null,
    offscreen: runtimeState?.offscreen || null,
    signal: runtimeState?.signal || ''
  };
}

async function keepTransportAlive(forceRefresh = false) {
  await ensureControllerReady();

  const runtimeState = localLinkController.getRuntimeState();
  if (!runtimeState?.state?.connectRequested) {
    return { ok: true, skipped: 'manual_connect_required' };
  }

  const connectionState = String(runtimeState?.state?.connectionState || '').trim().toLowerCase();
  const peerReachable = Boolean(runtimeState?.state?.peerReachable ?? runtimeState?.state?.peer_reachable ?? false);
  if (connectionState === 'connected' && peerReachable) {
    return { ok: true, skipped: 'transport_healthy' };
  }

  await refreshPairing(Boolean(forceRefresh));

  return localLinkController.restoreConnection(
    forceRefresh ? 'offscreen_keepalive_refresh' : 'offscreen_keepalive',
    Boolean(forceRefresh)
  );
}

function postServiceWorkerHeartbeat(reason) {
  if (!serviceWorkerPort) {
    return false;
  }

  try {
    serviceWorkerPort.postMessage({
      type: 'TABSYNC_ACTIVE_HEARTBEAT',
      reason,
      sentAt: new Date().toISOString()
    });
    return true;
  } catch (_) {
    return false;
  }
}

function ensureServiceWorkerPort() {
  if (serviceWorkerPort || !extensionAPI?.runtime?.connect) {
    return Boolean(serviceWorkerPort);
  }

  try {
    serviceWorkerPort = extensionAPI.runtime.connect({ name: SERVICE_WORKER_PORT_NAME });
  } catch (_) {
    serviceWorkerPort = null;
    return false;
  }

  serviceWorkerPort.onDisconnect?.addListener?.(() => {
    serviceWorkerPort = null;
    if (serviceWorkerPortHeartbeatTimer) {
      globalThis.clearInterval(serviceWorkerPortHeartbeatTimer);
      serviceWorkerPortHeartbeatTimer = null;
    }
    globalThis.setTimeout(() => {
      ensureServiceWorkerPort();
    }, 1_000);
  });

  if (!serviceWorkerPortHeartbeatTimer) {
    serviceWorkerPortHeartbeatTimer = globalThis.setInterval(() => {
      if (!postServiceWorkerHeartbeat('offscreen_transport_alive')) {
        ensureServiceWorkerPort();
      }
    }, SERVICE_WORKER_PORT_HEARTBEAT_MS);
  }

  postServiceWorkerHeartbeat('offscreen_transport_started');
  return true;
}

if (localLinkController) {
  ensureServiceWorkerPort();
  void ensureControllerReady();
  void keepTransportAlive(true);
}

const transportHealthTimer = localLinkController
  ? globalThis.setInterval(() => {
    ensureServiceWorkerPort();
    void keepTransportAlive(false).catch(() => {
    });
  }, TRANSPORT_HEALTHCHECK_MS)
  : null;

globalThis.addEventListener('unload', () => {
  if (transportHealthTimer) {
    globalThis.clearInterval(transportHealthTimer);
  }
  if (serviceWorkerPortHeartbeatTimer) {
    globalThis.clearInterval(serviceWorkerPortHeartbeatTimer);
  }
  try {
    serviceWorkerPort?.disconnect?.();
  } catch (_) {
  }
});

extensionAPI?.runtime?.onMessage?.addListener?.((message, _sender, sendResponse) => {
  const type = String(message?.type || '');

  if (type === 'OFFSCREEN_INIT_TRANSPORT') {
    void buildRuntimeStateResponse({
      initialize: true,
      forceRefresh: Boolean(message?.forceRefresh)
    })
      .then((response) => {
        sendResponse({
          ...response,
          reason: String(message?.reason || 'offscreen_init')
        });
      })
      .catch((error) => {
        sendResponse({ ok: false, error: errorMessage(error, 'transport_init_failed') });
      });
    return true;
  }

  if (type === 'OFFSCREEN_CONNECT') {
    void ensureControllerReady()
      .then(() => {
        localLinkController.applyConfig(String(message?.toon || ''));
        const persist = extensionAPI.storage?.local?.set
          ? extensionAPI.storage.local.set({
            [globalThis.TabSyncLocalLink.STORAGE_KEYS.config]: String(message?.toon || '')
          })
          : Promise.resolve();

        return Promise.resolve(persist)
          .then(() => localLinkController.restoreConnection('manual_connect', true))
          .then((result) => {
            sendResponse({
              ok: Boolean(result?.ok),
              document_toon: localLinkController.buildDocumentTOON('active'),
              state_toon: localLinkController.buildSocketStateTOON('connecting')
            });
          });
      })
      .catch((error) => {
        sendResponse({ ok: false, error: errorMessage(error, 'connect_failed') });
      });
    return true;
  }

  if (type === 'OFFSCREEN_SEND_TOON' || type === 'OFFSCREEN_SEND_DATA_TOON') {
    void ensureControllerReady()
      .then(() => {
        const ok = localLinkController.sendTOON(String(message?.toon || ''));
        sendResponse({
          ok,
          via: {
            websocket: true
          }
        });
      })
      .catch((error) => {
        sendResponse({ ok: false, error: errorMessage(error, 'send_failed') });
      });
    return true;
  }

  if (type === 'OFFSCREEN_SEND_TAB_SNAPSHOT') {
    void ensureControllerReady()
      .then(() => {
        const jsonPayload = String(message?.jsonPayload || message?.json_payload || '').trim();
        const fallbackTOON = String(message?.fallbackTOON || message?.fallback_toon || '').trim();

        if (!jsonPayload && !fallbackTOON) {
          sendResponse({ ok: false, error: 'missing_tab_snapshot_payload' });
          return;
        }

        let accepted = false;
        let sentJSON = false;
        let sentLegacy = false;

        if (jsonPayload) {
          accepted = true;
          sentJSON = localLinkController.sendTOON(jsonPayload);
        }

        if (fallbackTOON) {
          accepted = true;
          sentLegacy = localLinkController.sendTOON(fallbackTOON);
        }

        sendResponse({
          ok: accepted,
          sent: {
            json: sentJSON,
            legacy: sentLegacy
          }
        });
      })
      .catch((error) => {
        sendResponse({ ok: false, error: errorMessage(error, 'tab_snapshot_send_failed') });
      });
    return true;
  }

  if (type === 'OFFSCREEN_REPLACE_TABS') {
    void ensureControllerReady()
      .then(() => localLinkController.replaceTabs(String(message?.toon || '')))
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, error: errorMessage(error, 'replace_tabs_failed') }));
    return true;
  }

  if (type === 'OFFSCREEN_REMOVE_DEVICE') {
    void ensureControllerReady()
      .then(() => localLinkController.removeRemoteDevice(String(message?.originID || message?.origin_id || '')))
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, error: errorMessage(error, 'remove_device_failed') }));
    return true;
  }

  if (type === 'OFFSCREEN_GENERATE_PAIRING') {
    void refreshPairing(Boolean(message?.forceRefresh))
      .then((state) => sendResponse({ ok: true, ...state }))
      .catch((error) => sendResponse({ ok: false, error: errorMessage(error, 'pairing_generate_failed') }));
    return true;
  }

  if (type === 'OFFSCREEN_RESTORE_LINK') {
    void ensureControllerReady()
      .then(() => localLinkController.restoreConnection(
        String(message?.reason || 'restore_link'),
        Boolean(message?.forceRefresh)
      ))
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, error: errorMessage(error, 'restore_link_failed') }));
    return true;
  }

  if (type === 'OFFSCREEN_GET_WEBRTC_STATE' || type === 'OFFSCREEN_GET_STATE') {
    void buildRuntimeStateResponse({
      initialize: Boolean(message?.initialize),
      forceRefresh: Boolean(message?.forceRefresh)
    })
      .then((response) => sendResponse(response))
      .catch((error) => sendResponse({ ok: false, error: errorMessage(error, 'state_unavailable') }));
    return true;
  }

  if (type === 'OFFSCREEN_DISCONNECT') {
    void ensureControllerReady()
      .then(() => localLinkController.disconnect())
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, error: errorMessage(error, 'disconnect_failed') }));
    return true;
  }

  return false;
});
})();
