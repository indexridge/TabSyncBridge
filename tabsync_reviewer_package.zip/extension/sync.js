(function attachLocalLinkSync(globalScope) {
  'use strict';

  const extensionAPI = globalScope.chrome ?? null;
  const HEARTBEAT_MS = 20_000;
  const HEARTBEAT_GRACE_MS = 45_000;
  const BASE_RECONNECT_MS = 1_500;
  const MAX_RECONNECT_MS = 20_000;
  const REFUSED_RECONNECT_BASE_MS = 900;
  const REFUSED_RECONNECT_MAX_MS = 4_500;
  const DEFAULT_PORT = 53317;
  const DISCOVERY_PATH = '/v1/discover';
  const PAIR_PATH = '/v1/pair';
  const NATIVE_HOST_NAME = 'com.tabsync.bridge';
  const NATIVE_REQUEST_TIMEOUT_MS = 6_000;
  const BRIDGE_FETCH_TIMEOUT_MS = 4_000;
  const SOCKET_CONNECT_TIMEOUT_MS = 4_000;
  const SOCKET_VALIDATION_TIMEOUT_MS = 60_000;
  const FAST_FAILURE_THRESHOLD_MS = 1_200;
  const MAX_PENDING_TOONS = 128;
  const STORAGE_KEYS = Object.freeze({
    deviceID: 'deviceId',
    pairingState: 'tabsync_local_pairing',
    savedRoute: 'tabsync_saved_direct_route',
    config: 'offscreen_config_toon',
    state: 'offscreen_state_toon',
    tabs: 'offscreen_tabs_toon',
    linked: 'offscreen_linked_devices_toon',
    verification: 'offscreen_verification_toon',
    document: 'offscreen_document_toon',
    signal: 'offscreen_signal_toon',
    discovery: 'offscreen_discovery_toon',
    hiddenDevices: 'tabsync_hidden_device_ids'
  });

  const textEncoder = new TextEncoder();
  const textDecoder = new TextDecoder();

  function storageArea() {
    return extensionAPI?.storage?.local ?? null;
  }

  async function storageGet(keys) {
    const area = storageArea();
    if (!area?.get) {
      return {};
    }

    try {
      return await area.get(keys);
    } catch (_) {
      return {};
    }
  }

  async function storageSet(values) {
    const area = storageArea();
    if (!area?.set) {
      return false;
    }

    try {
      await area.set(values);
      return true;
    } catch (_) {
      return false;
    }
  }

  async function storageRemove(keys) {
    const area = storageArea();
    if (!area?.remove) {
      return false;
    }

    try {
      await area.remove(keys);
      return true;
    } catch (_) {
      return false;
    }
  }

  async function runtimeSendMessage(message) {
    if (!extensionAPI?.runtime?.sendMessage) {
      return { ok: false, error: 'runtime_unavailable' };
    }

    try {
      return await extensionAPI.runtime.sendMessage(message);
    } catch (error) {
      return { ok: false, error: error?.message || 'runtime_message_failed' };
    }
  }

  function currentTimestamp() {
    return new Date().toISOString();
  }

  function escapeTOONValue(value) {
    return String(value ?? '')
      .replace(/\\/g, '\\\\')
      .replace(/\t/g, '\\t')
      .replace(/\n/g, '\\n');
  }

  function unescapeTOONValue(value) {
    let output = '';
    let escaped = false;

    for (const character of String(value ?? '')) {
      if (!escaped) {
        if (character === '\\') {
          escaped = true;
        } else {
          output += character;
        }
        continue;
      }

      if (character === 't') {
        output += '\t';
      } else if (character === 'n') {
        output += '\n';
      } else {
        output += character;
      }

      escaped = false;
    }

    return output;
  }

  function encodeTOON(name, header, rows) {
    const safeRows = Array.isArray(rows) ? rows : [];
    const lines = [`${name}[${safeRows.length}]{${header.join(',')}}:`];

    for (const row of safeRows) {
      const values = Array.isArray(row)
        ? row
        : header.map((column) => row?.[column] ?? '');
      lines.push(header.map((_, index) => escapeTOONValue(values[index] ?? '')).join('\t'));
    }

    return lines.join('\n');
  }

  function decodeTOON(payload) {
    if (typeof payload !== 'string' || payload.trim().length === 0) {
      return null;
    }

    const lines = payload.replace(/\r\n/g, '\n').split('\n');
    const headerLine = lines.shift() || '';
    const match = /^([A-Za-z0-9_]+)\[(\d+)\]\{([^}]*)\}:$/.exec(headerLine.trim());
    if (!match) {
      return null;
    }

    const [, name, countLiteral, headerLiteral] = match;
    const header = headerLiteral.split(',').map((column) => column.trim()).filter(Boolean);
    const rowCount = Number.parseInt(countLiteral, 10) || 0;
    const rows = lines
      .slice(0, rowCount)
      .map((line) => line.split('\t').map(unescapeTOONValue));

    return {
      name,
      header,
      rows,
      indexByHeader: Object.fromEntries(header.map((column, index) => [column, index]))
    };
  }

  function toonValue(table, row, column, aliases = []) {
    for (const key of [column, ...aliases]) {
      const index = table?.indexByHeader?.[key];
      if (index != null && row?.[index] != null) {
        return row[index];
      }
    }

    return '';
  }

  function isDeviceRemovalAction(action) {
    const normalized = String(action || '').trim().toUpperCase();
    return normalized === 'REMOVE_DEVICE'
      || normalized === 'ACTION:REMOVE_DEVICE'
      || normalized === 'HIDE_DEVICE'
      || normalized === 'REMOVE'
      || normalized === 'HIDE';
  }

  function deviceVisibilityTargetOriginIDs(table) {
    if (!table || table.name !== 'device_visibility') {
      return [];
    }

    const targets = new Set();
    for (const row of table.rows) {
      if (!isDeviceRemovalAction(toonValue(table, row, 'action'))) {
        continue;
      }

      const explicitTarget = String(
        toonValue(table, row, 'target_origin_id', ['target_device_id', 'device_id'])
        || ''
      ).trim();
      if (explicitTarget) {
        targets.add(explicitTarget);
        continue;
      }

      const sourceDeviceID = String(toonValue(table, row, 'source_device_id') || '').trim();
      const legacyTarget = sourceDeviceID ? '' : String(toonValue(table, row, 'origin_id') || '').trim();
      if (legacyTarget) {
        targets.add(legacyTarget);
      }
    }

    return Array.from(targets);
  }

  function bytesToBase64URL(bytes) {
    let binary = '';
    for (const value of bytes) {
      binary += String.fromCharCode(value);
    }

    return btoa(binary)
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/g, '');
  }

  function base64URLToBytes(value) {
    const normalized = String(value || '')
      .replace(/-/g, '+')
      .replace(/_/g, '/');
    const padded = normalized + '='.repeat((4 - (normalized.length % 4)) % 4);
    const binary = atob(padded);
    const bytes = new Uint8Array(binary.length);

    for (let index = 0; index < binary.length; index += 1) {
      bytes[index] = binary.charCodeAt(index);
    }

    return bytes;
  }

  function normalizeHost(host) {
    return String(host || '').trim().replace(/^\[|\]$/g, '');
  }

  function normalizeRouteHost(host) {
    const normalizedHost = normalizeHost(host);
    const octets = normalizedHost
      .split('.')
      .map((value) => Number.parseInt(value, 10));

    if (octets.length !== 4 || octets.some((value) => !Number.isInteger(value) || value < 0 || value > 255)) {
      return '';
    }

    const [first, second] = octets;
    const isSupportedPrivateRange = first === 10
      || (first === 172 && second >= 16 && second <= 31)
      || (first === 192 && second === 168);

    if (!isSupportedPrivateRange) {
      return '';
    }

    return octets.join('.');
  }

  function extractRouteHostFromURL(rawValue) {
    const trimmed = String(rawValue || '').trim();
    if (!trimmed) {
      return '';
    }

    try {
      return normalizeRouteHost(new URL(trimmed).hostname);
    } catch (_) {
      return '';
    }
  }

  function parsePeerJSONPayload(rawValue) {
    const trimmed = String(rawValue || '').trim();
    if (!trimmed || (trimmed[0] !== '{' && trimmed[0] !== '[')) {
      return null;
    }

    try {
      return JSON.parse(trimmed);
    } catch (_) {
      return null;
    }
  }

  function isSyncableTabURL(rawValue) {
    const trimmed = String(rawValue || '').trim();
    if (!trimmed) {
      return false;
    }

    try {
      const url = new URL(trimmed);
      return url.protocol === 'http:' || url.protocol === 'https:';
    } catch (_) {
      return false;
    }
  }

  function normalizeWebSocketURL(rawValue) {
    const trimmed = String(rawValue || '').trim();
    if (!trimmed) {
      return '';
    }

    try {
      const url = new URL(
        trimmed.startsWith('ws://')
        || trimmed.startsWith('wss://')
        || trimmed.startsWith('http://')
        || trimmed.startsWith('https://')
          ? trimmed
          : `ws://${trimmed}`
      );
      const host = normalizeRouteHost(url.hostname || url.host);
      if (!host) {
        return '';
      }

      const scheme = (url.protocol === 'https:' || url.protocol === 'wss:') ? 'wss' : 'ws';
      const pathname = url.pathname && url.pathname !== '/' ? url.pathname : '/bridge';
      return `${scheme}://${host}:${DEFAULT_PORT}${pathname}`;
    } catch (_) {
      return '';
    }
  }

  function hasSavedDirectRoute(pairingState) {
    if (!pairingState || typeof pairingState !== 'object') {
      return false;
    }

    return Boolean(
      normalizeRouteHost(pairingState.localIP || pairingState.local_ip || pairingState.host_ip || '')
      || extractRouteHostFromURL(pairingState.wsURL || pairingState.ws_url || pairingState.websocket_url || '')
    );
  }

  function normalizeSavedRoute(savedRoute) {
    if (!savedRoute) {
      return null;
    }

    const routeObject = typeof savedRoute === 'string'
      ? {
          localIP: normalizeRouteHost(savedRoute) || extractRouteHostFromURL(savedRoute),
          wsURL: savedRoute
        }
      : savedRoute;
    if (!routeObject || typeof routeObject !== 'object') {
      return null;
    }

    const hostIP = normalizeRouteHost(
      routeObject.localIP
      || routeObject.local_ip
      || routeObject.hostIP
      || routeObject.host_ip
      || extractRouteHostFromURL(routeObject.wsURL || routeObject.ws_url || routeObject.websocket_url || '')
      || ''
    );
    const wsURL = normalizeWebSocketURL(routeObject.wsURL || routeObject.ws_url || (hostIP ? `ws://${hostIP}:${DEFAULT_PORT}/bridge` : ''));
    if (!hostIP || !wsURL) {
      return null;
    }

    return {
      localIP: hostIP,
      port: DEFAULT_PORT,
      bridgeURL: `http://${hostIP}:${DEFAULT_PORT}`,
      wsURL,
      updatedAt: String(routeObject.updatedAt || routeObject.updated_at || currentTimestamp())
    };
  }

  function pairingStateWithSavedRoute(pairingState, savedRoute) {
    const route = normalizeSavedRoute(savedRoute);
    const base = pairingState && typeof pairingState === 'object' ? pairingState : {};
    if (!route) {
      return Object.keys(base).length > 0 ? base : null;
    }

    const baseHasRoute = hasSavedDirectRoute(base);
    return {
      ...base,
      localIP: baseHasRoute ? (base.localIP || route.localIP) : route.localIP,
      port: DEFAULT_PORT,
      bridgeURL: base.bridgeURL || route.bridgeURL,
      wsURL: baseHasRoute ? (base.wsURL || route.wsURL) : route.wsURL,
      bridgeReady: base.bridgeReady ?? true,
      bridgeState: base.bridgeState || 'ready',
      bridgeMessage: base.bridgeMessage || 'Reconnecting to saved route',
      connectRequested: true,
      connectionState: base.connectionState || 'connecting',
      lastError: ''
    };
  }

  function normalizeHTTPURL(hostIP, port, pathname) {
    const host = normalizeRouteHost(hostIP);
    if (!host) {
      return '';
    }

    return `http://${host}:${DEFAULT_PORT}${pathname}`;
  }

  function createTransportError(code, cause = null) {
    const normalizedCode = String(code || 'transport_error').trim().toUpperCase() || 'TRANSPORT_ERROR';
    const error = new Error(normalizedCode);
    error.code = normalizedCode;
    if (cause) {
      error.cause = cause;
    }
    return error;
  }

  function transportErrorCode(error, fallback = '') {
    const explicitCode = String(error?.code || '').trim().toUpperCase();
    if (explicitCode) {
      return explicitCode;
    }

    const explicitMessage = String(error?.message || '').trim().toUpperCase();
    if (explicitMessage === 'ECONNREFUSED' || explicitMessage === 'ETIMEDOUT') {
      return explicitMessage;
    }

    return String(fallback || '').trim().toUpperCase();
  }

  async function fetchJSON(url, options = {}, timeoutMs = BRIDGE_FETCH_TIMEOUT_MS) {
    const controller = new AbortController();
    const startedAt = Date.now();
    let timedOut = false;
    const timeout = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, timeoutMs);

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal
      });
      const payload = await response.json();
      if (!response.ok) {
        throw new Error(String(payload?.error || `http_${response.status || 0}`));
      }
      return payload;
    } catch (error) {
      if (timedOut || error?.name === 'AbortError') {
        throw createTransportError('ETIMEDOUT', error);
      }

      const failedToFetch = error instanceof TypeError
        || String(error?.message || '').toLowerCase().includes('failed to fetch')
        || String(error?.message || '').toLowerCase().includes('networkerror');
      if (failedToFetch) {
        const elapsedMs = Date.now() - startedAt;
        const code = elapsedMs <= FAST_FAILURE_THRESHOLD_MS ? 'ECONNREFUSED' : 'ETIMEDOUT';
        throw createTransportError(code, error);
      }

      throw error;
    } finally {
      clearTimeout(timeout);
    }
  }

  async function derivePairKey(pairCode, serverNonce, clientNonce) {
    const digest = await crypto.subtle.digest(
      'SHA-256',
      textEncoder.encode(`tabsync-aes128|${String(pairCode || '')}|${String(serverNonce || '')}|${String(clientNonce || '')}`)
    );
    const keyBytes = new Uint8Array(digest).slice(0, 16);

    return crypto.subtle.importKey(
      'raw',
      keyBytes,
      { name: 'AES-GCM' },
      false,
      ['encrypt', 'decrypt']
    );
  }

  async function encryptJSON(key, payload) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encrypted = new Uint8Array(await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      key,
      textEncoder.encode(JSON.stringify(payload))
    ));
    const tag = encrypted.slice(encrypted.length - 16);
    const ciphertext = encrypted.slice(0, encrypted.length - 16);

    return {
      iv: bytesToBase64URL(iv),
      ciphertext: bytesToBase64URL(ciphertext),
      tag: bytesToBase64URL(tag)
    };
  }

  async function decryptJSON(key, payload) {
    const iv = base64URLToBytes(payload?.iv || '');
    const ciphertext = base64URLToBytes(payload?.ciphertext || '');
    const tag = base64URLToBytes(payload?.tag || '');
    const merged = new Uint8Array(ciphertext.length + tag.length);
    merged.set(ciphertext, 0);
    merged.set(tag, ciphertext.length);
    const plaintext = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      key,
      merged
    );
    return JSON.parse(textDecoder.decode(new Uint8Array(plaintext)));
  }

  function websocketQueryURL(baseURL, query) {
    const url = new URL(normalizeWebSocketURL(baseURL));
    for (const [key, value] of Object.entries(query)) {
      if (value != null && value !== '') {
        url.searchParams.set(key, String(value));
      }
    }
    return url.toString();
  }

  function hashFingerprint(value) {
    return crypto.randomUUID ? String(value || '').slice(0, 8) : String(value || '').slice(0, 8);
  }

  function uniqCandidates(candidates) {
    const seen = new Set();
    return (Array.isArray(candidates) ? candidates : []).filter((candidate) => {
      const hostIP = normalizeRouteHost(candidate?.hostIP || candidate?.host_ip || '');
      const key = `${hostIP}:${DEFAULT_PORT}`;
      if (!hostIP || seen.has(key)) {
        return false;
      }
      seen.add(key);
      candidate.hostIP = hostIP;
      candidate.port = DEFAULT_PORT;
      return true;
    });
  }

  class LocalLinkController {
    constructor() {
      this.deviceID = '';
      this.connectionState = 'idle';
      this.lastError = '';
      this.peerURL = '';
      this.pairingAnchor = null;
      this.pairingState = null;
      this.discoveryTOON = '';
      this.linkedDevicesTOON = encodeTOON(
        'linked_devices',
        ['origin_id', 'device_id', 'link_state', 'tab_count', 'last_seen_at'],
        []
      );
      this.verificationTOON = encodeTOON(
        'verification',
        ['status', 'signature', 'peer_device_id', 'received_at'],
        []
      );
      this.signalTOON = '';
      this.remoteTabsByID = new Map();
      this.hiddenDeviceOrigins = new Set();
      this.pendingTOONs = [];
      this.socket = null;
      this.activeSocketURL = '';
      this.socketCloseHandled = false;
      this.heartbeatTimer = null;
      this.validationTimer = null;
      this.lastPeerHeartbeatAt = 0;
      this.lastPeerMessageAt = 0;
      this.reconnectTimer = null;
      this.connectTimeoutTimer = null;
      this.reconnectAttempt = 0;
      this.configTOON = '';
      this.peerValidated = false;
      this.remotePeerID = '';
      this.preventReconnect = false;
      this.bridgeReady = false;
      this.bridgeState = 'unavailable';
      this.bridgeMessage = 'Desktop Bridge Unreachable';
      this.nativePort = null;
      this.nativeReadyPromise = null;
      this.nativeRequests = new Map();
      this.nativeSequence = 0;
    }

    async restore() {
      const stored = await storageGet(Object.values(STORAGE_KEYS));
      this.deviceID = stored[STORAGE_KEYS.deviceID] || '';
      this.pairingState = pairingStateWithSavedRoute(
        stored[STORAGE_KEYS.pairingState] || null,
        stored[STORAGE_KEYS.savedRoute] || null
      );
      this.verificationTOON = stored[STORAGE_KEYS.verification] || this.verificationTOON;
      this.signalTOON = stored[STORAGE_KEYS.signal] || '';
      this.configTOON = stored[STORAGE_KEYS.config] || '';
      this.discoveryTOON = stored[STORAGE_KEYS.discovery] || '';
      this.linkedDevicesTOON = stored[STORAGE_KEYS.linked] || this.linkedDevicesTOON;
      this.hiddenDeviceOrigins = new Set(
        (Array.isArray(stored[STORAGE_KEYS.hiddenDevices]) ? stored[STORAGE_KEYS.hiddenDevices] : [])
          .map((value) => String(value || '').trim())
          .filter(Boolean)
      );

      if (!this.deviceID) {
        this.deviceID = await this.getOrCreateDeviceID();
      }

      const tabsTOON = stored[STORAGE_KEYS.tabs];
      if (tabsTOON) {
        this.replaceTabsFromTOON(tabsTOON);
      }
      this.updateLinkedDevicesTOON();

      if (this.pairingState?.wsURL) {
        this.peerURL = normalizeWebSocketURL(this.pairingState.wsURL);
      }

      if (this.configTOON) {
        this.applyConfig(this.configTOON);
      }

      if (hasSavedDirectRoute(this.pairingState)) {
        this.pairingState = {
          ...(this.pairingState || {}),
          connectRequested: true,
          connectionState: 'connecting',
          peerReachable: false,
          peerState: 'waiting',
          lastError: ''
        };
      }

      await this.ensureSavedRouteConnectIntent('restore');
      await storageSet({ [STORAGE_KEYS.document]: this.buildDocumentTOON('active') });
      await this.restoreConnection('restore', false);
    }

    async getOrCreateDeviceID() {
      if (this.deviceID) {
        return this.deviceID;
      }

      const stored = await storageGet(STORAGE_KEYS.deviceID);
      if (stored[STORAGE_KEYS.deviceID]) {
        this.deviceID = stored[STORAGE_KEYS.deviceID];
        return this.deviceID;
      }

      this.deviceID = crypto.randomUUID();
      await storageSet({ [STORAGE_KEYS.deviceID]: this.deviceID });
      return this.deviceID;
    }

    async ensureSavedRouteConnectIntent(reason = 'saved_route') {
      if (!hasSavedDirectRoute(this.pairingState) || this.pairingState?.connectRequested === true) {
        return false;
      }

      this.pairingState = {
        ...(this.pairingState || {}),
        connectRequested: true,
        connectionState: this.connectionState === 'connected' ? 'connected' : 'connecting',
        bridgeReady: this.bridgeReady,
        bridgeState: this.bridgeState || 'ready',
        bridgeMessage: `Reconnecting to saved route (${reason})`,
        lastError: ''
      };
      await storageSet({ [STORAGE_KEYS.pairingState]: this.pairingState });
      return true;
    }

    buildDocumentTOON(state) {
      return encodeTOON(
        'offscreen_document',
        ['state', 'reason', 'peer_url', 'device_id', 'updated_at'],
        [[
          state,
          'WORKERS',
          this.peerURL,
          this.deviceID,
          currentTimestamp()
        ]]
      );
    }

    buildSocketStateTOON(connectionState, lastError = '') {
      return encodeTOON(
        'offscreen_state',
        ['connection_state', 'peer_url', 'device_id', 'verified_status', 'bridge_state', 'bridge_ready', 'peer_state', 'peer_device_id', 'manual_code', 'last_error', 'updated_at'],
        [[
          connectionState,
          this.peerURL,
          this.deviceID,
          this.currentVerificationStatus(),
          this.bridgeState,
          this.bridgeReady ? 'true' : 'false',
          this.currentPeerState(),
          this.remotePeerID,
          this.currentManualCode(),
          lastError,
          currentTimestamp()
        ]]
      );
    }

    buildTabSnapshotTOON() {
      return encodeTOON(
        'tabs',
        ['tab_id', 'origin_id', 'device_id', 'url', 'title', 'last_updated_timestamp', 'device_name', 'browser_name', 'platform'],
        Array.from(this.remoteTabsByID.values())
          .filter((tab) => isSyncableTabURL(tab?.url))
          .sort((left, right) => right.last_updated_timestamp.localeCompare(left.last_updated_timestamp))
          .map((tab) => ([
            tab.tab_id,
            tab.origin_id,
            tab.device_id,
            tab.url,
            tab.title,
            tab.last_updated_timestamp,
            tab.device_name,
            tab.browser_name,
            tab.platform
          ]))
      );
    }

    buildLinkedDevicesTOON() {
      const byOrigin = new Map();

      for (const tab of this.remoteTabsByID.values()) {
        if (!isSyncableTabURL(tab?.url)) {
          continue;
        }
        const originID = String(tab.origin_id || tab.device_id || '').trim();
        if (!originID || originID === this.deviceID) {
          continue;
        }

        const current = byOrigin.get(originID) || {
          origin_id: originID,
          device_id: String(tab.device_id || originID).trim() || originID,
          link_state: 'reachable',
          tab_count: 0,
          last_seen_at: ''
        };
        current.tab_count += 1;
        current.last_seen_at = String(tab.last_updated_timestamp || current.last_seen_at || '').trim();
        byOrigin.set(originID, current);
      }

      if (this.remotePeerID && this.remotePeerID !== this.deviceID && !byOrigin.has(this.remotePeerID)) {
        byOrigin.set(this.remotePeerID, {
          origin_id: this.remotePeerID,
          device_id: this.remotePeerID,
          link_state: this.currentPeerState(),
          tab_count: 0,
          last_seen_at: currentTimestamp()
        });
      }

      return encodeTOON(
        'linked_devices',
        ['origin_id', 'device_id', 'link_state', 'tab_count', 'last_seen_at'],
        Array.from(byOrigin.values())
          .filter((row) => row.origin_id && row.origin_id !== this.deviceID)
          .sort((left, right) => String(right.last_seen_at || '').localeCompare(String(left.last_seen_at || '')))
          .map((row) => ([
            row.origin_id,
            row.device_id,
            row.link_state,
            String(row.tab_count),
            row.last_seen_at
          ]))
      );
    }

    updateLinkedDevicesTOON() {
      this.linkedDevicesTOON = this.buildLinkedDevicesTOON();
      return this.linkedDevicesTOON;
    }

    currentVerificationStatus() {
      const parsed = decodeTOON(this.verificationTOON);
      const row = parsed?.rows?.[0] || [];
      return toonValue(parsed, row, 'status') || 'pending';
    }

    currentPeerState() {
      if (this.peerValidated && this.connectionState === 'connected') {
        return 'reachable';
      }

      if (!this.bridgeReady) {
        return 'unavailable';
      }

      if (this.connectionState === 'failed' || this.currentVerificationStatus() === 'rejected') {
        return 'rejected';
      }

      if (this.connectionState === 'connecting') {
        return 'linking';
      }

      return 'waiting';
    }

    currentManualCode() {
      return String(this.pairingState?.manualCode || this.pairingAnchor?.manualCode || '').trim();
    }

    currentSecretCode() {
      return String(this.pairingState?.secretCode || this.pairingAnchor?.manualCode || this.currentManualCode()).trim();
    }

    runtimeConnectionState() {
      if (this.connectionState === 'failed' || this.connectionState === 'error') {
        return this.connectionState;
      }

      if (this.socket?.readyState === WebSocket.OPEN) {
        return this.peerValidated ? 'connected' : 'connecting';
      }

      return this.connectionState;
    }

    applyConfig(configTOON) {
      this.configTOON = String(configTOON || '');
      const parsed = decodeTOON(this.configTOON);
      const row = parsed?.rows?.[0] || [];
      if (!parsed) {
        return;
      }

      const hostIP = normalizeRouteHost(
        toonValue(parsed, row, 'host_ip', ['local_ip', 'ip'])
        || extractRouteHostFromURL(toonValue(parsed, row, 'ws_url', ['websocket_url', 'peer_url']) || '')
      );
      const port = DEFAULT_PORT;
      const wsURL = normalizeWebSocketURL(
        toonValue(parsed, row, 'ws_url', ['websocket_url', 'peer_url'])
        || (hostIP ? `ws://${hostIP}:${DEFAULT_PORT}/bridge` : '')
      );
      const manualCode = String(toonValue(parsed, row, 'manual_code', ['secret_code']) || '').trim();
      const secretCode = String(toonValue(parsed, row, 'secret_code', ['manual_code']) || manualCode).trim();
      const connectRequested = String(toonValue(parsed, row, 'connect_requested', ['connect']) || '').trim().toLowerCase() === 'true';
      const previousPeerURL = this.peerURL;
      const hasDirectRouteConfig = Boolean(hostIP || wsURL);
      const nextManualCode = hasDirectRouteConfig ? manualCode : (manualCode || this.pairingState?.manualCode || '');
      const nextSecretCode = hasDirectRouteConfig ? secretCode : (secretCode || this.pairingState?.secretCode || '');

      this.peerURL = wsURL || this.peerURL;
      this.pairingState = {
        ...(this.pairingState || {}),
        localIP: hostIP || this.pairingState?.localIP || '',
        port,
        wsURL: wsURL || this.pairingState?.wsURL || '',
        manualCode: nextManualCode,
        secretCode: nextSecretCode,
        anchorSessionID: this.pairingState?.anchorSessionID || '',
        pairingTOON: this.configTOON,
        bridgeReady: this.bridgeReady,
        bridgeState: this.bridgeState,
        bridgeMessage: this.bridgeMessage,
        connectRequested: connectRequested || Boolean(this.pairingState?.connectRequested)
      };
      if (previousPeerURL && this.peerURL && previousPeerURL !== this.peerURL) {
        this.closeActiveSocket('route_changed');
      }
      const savedRoute = normalizeSavedRoute({
        localIP: this.pairingState.localIP,
        wsURL: this.pairingState.wsURL
      });
      if (savedRoute) {
        void storageSet({ [STORAGE_KEYS.savedRoute]: savedRoute });
      }
    }

    openNativePort() {
      if (this.nativePort || !extensionAPI?.runtime?.connectNative) {
        return Boolean(this.nativePort);
      }

      try {
        const port = extensionAPI.runtime.connectNative(NATIVE_HOST_NAME);
        port.onMessage.addListener((message) => this.handleNativeMessage(message));
        port.onDisconnect.addListener(() => this.handleNativeDisconnect());
        this.nativePort = port;
        return true;
      } catch (_) {
        this.bridgeUnavailable('native_host_unavailable');
        return false;
      }
    }

    bridgeUnavailable(reason) {
      this.bridgeReady = false;
      this.bridgeState = 'unavailable';
      this.bridgeMessage = 'Desktop Bridge Unreachable';
      this.lastError = reason || this.lastError;
    }

    clearConnectTimeout() {
      if (!this.connectTimeoutTimer) {
        return;
      }

      clearTimeout(this.connectTimeoutTimer);
      this.connectTimeoutTimer = null;
    }

    clearValidationTimeout() {
      if (!this.validationTimer) {
        return;
      }

      clearTimeout(this.validationTimer);
      this.validationTimer = null;
    }

    closeActiveSocket(reason = 'reconnect') {
      const activeSocket = this.socket;
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
      this.clearConnectTimeout();
      this.clearValidationTimeout();
      this.stopHeartbeat();
      this.socket = null;
      this.activeSocketURL = '';
      this.socketCloseHandled = false;
      this.peerValidated = false;
      this.connectionState = 'disconnected';

      if (activeSocket) {
        try {
          activeSocket.close(1000, String(reason || 'reconnect'));
        } catch (_) {
        }
      }
    }

    async ensureNativeBridge() {
      if (this.nativeReadyPromise) {
        return this.nativeReadyPromise;
      }

      if (this.nativePort) {
        return true;
      }

      if (!this.openNativePort()) {
        return false;
      }

      this.nativeReadyPromise = this.dispatchNativeRequest('PING', {}, 4_000)
        .then((response) => {
          this.applyHostSnapshot(response);
          return Boolean(response?.bridge_ready ?? response?.ok);
        })
        .catch(() => {
          this.bridgeUnavailable('native_ping_failed');
          return false;
        })
        .finally(() => {
          this.nativeReadyPromise = null;
        });

      return this.nativeReadyPromise;
    }

    dispatchNativeRequest(type, payload = {}, timeoutMs = NATIVE_REQUEST_TIMEOUT_MS) {
      if (!this.nativePort) {
        return Promise.reject(new Error('native_port_unavailable'));
      }

      const requestID = `native-${Date.now()}-${++this.nativeSequence}`;
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          this.nativeRequests.delete(requestID);
          reject(new Error(`native_timeout:${type}`));
        }, timeoutMs);

        this.nativeRequests.set(requestID, {
          resolve,
          reject,
          timeout
        });

        try {
          this.nativePort.postMessage({
            request_id: requestID,
            type,
            extension_id: extensionAPI?.runtime?.id || '',
            ...payload
          });
        } catch (error) {
          clearTimeout(timeout);
          this.nativeRequests.delete(requestID);
          reject(error);
        }
      });
    }

    async nativeRequest(type, payload = {}, timeoutMs = NATIVE_REQUEST_TIMEOUT_MS) {
      const ready = await this.ensureNativeBridge();
      if (!ready) {
        throw new Error('native_host_unavailable');
      }

      const response = await this.dispatchNativeRequest(type, payload, timeoutMs);
      this.applyHostSnapshot(response);
      if (response?.ok === false) {
        throw new Error(String(response.error || `${type.toLowerCase()}_failed`));
      }
      return response;
    }

    handleNativeMessage(message) {
      const requestID = String(message?.request_id || '').trim();
      if (requestID && this.nativeRequests.has(requestID)) {
        const pending = this.nativeRequests.get(requestID);
        clearTimeout(pending.timeout);
        this.nativeRequests.delete(requestID);
        pending.resolve(message);
        return;
      }

      this.applyHostSnapshot(message);
    }

    handleNativeDisconnect() {
      for (const pending of this.nativeRequests.values()) {
        clearTimeout(pending.timeout);
        pending.reject(new Error('native_host_disconnected'));
      }
      this.nativeRequests.clear();
      this.nativePort = null;
      this.bridgeUnavailable('native_host_disconnected');
    }

    async syncPairingAnchor(forceRefresh = false) {
      const anchor = await globalScope.TabSyncPairing?.getStablePairingCode?.(forceRefresh);
      if (!anchor?.manualCode) {
        throw new Error('pairing_anchor_unavailable');
      }

      this.pairingAnchor = anchor;
      this.pairingState = {
        ...(this.pairingState || {}),
        manualCode: anchor.manualCode,
        secretCode: anchor.manualCode,
        anchorSessionID: anchor.sessionID,
        anchorCreatedAt: anchor.createdAt,
        anchorExpiresAt: anchor.expiresAt
      };

      const response = await this.nativeRequest('SET_PAIRING_ANCHOR', {
        manual_code: anchor.manualCode,
        anchor_session_id: anchor.sessionID,
        created_at: anchor.createdAt,
        expires_at: anchor.expiresAt
      });
      this.applyHostSnapshot(response);
      return anchor;
    }

    applyHostSnapshot(snapshot) {
      if (!snapshot || typeof snapshot !== 'object') {
        return;
      }

      this.bridgeReady = Boolean(snapshot.bridge_ready ?? snapshot.ok);
      this.bridgeState = String(snapshot.bridge_state || (this.bridgeReady ? 'ready' : 'unavailable')).trim().toLowerCase();
      this.bridgeMessage = String(snapshot.bridge_message || (this.bridgeReady ? 'Bridge Reachable' : 'Desktop Bridge Unreachable')).trim();

      const hostIP = normalizeRouteHost(
        snapshot.host_ip
        || snapshot.local_ip
        || extractRouteHostFromURL(snapshot.ws_url || snapshot.websocket_url || '')
      );
      const port = DEFAULT_PORT;
      const wsURL = normalizeWebSocketURL(
        snapshot.ws_url
        || snapshot.websocket_url
        || (hostIP ? `ws://${hostIP}:${DEFAULT_PORT}/bridge` : '')
      );
      const manualCode = String(snapshot.manual_code || this.pairingAnchor?.manualCode || '').trim();
      const secretCode = String(snapshot.secret_code || manualCode).trim();
      const sessionID = String(snapshot.session_id || '').trim();
      const resumeToken = String(snapshot.resume_token || '').trim();
      const expiresAt = String(snapshot.expires_at || '').trim();
      const pairingTOON = String(snapshot.pairing_toon || snapshot.toon || '').trim();
      const anchorSessionID = String(snapshot.anchor_session_id || this.pairingAnchor?.sessionID || '').trim();
      const hostName = String(snapshot.host_name || '').trim();

      if (!this.pairingState && (hostIP || wsURL || manualCode || pairingTOON)) {
        this.pairingState = {};
      }

      if (this.pairingState) {
        this.pairingState = {
          ...this.pairingState,
          localIP: hostIP || this.pairingState.localIP || '',
          port,
          wsURL: wsURL || this.pairingState.wsURL || '',
          manualCode: manualCode || this.pairingState.manualCode || '',
          secretCode: secretCode || this.pairingState.secretCode || '',
          sessionID: sessionID || this.pairingState.sessionID || '',
          resumeToken: resumeToken || this.pairingState.resumeToken || '',
          expiresAt: expiresAt || this.pairingState.expiresAt || '',
          anchorSessionID: anchorSessionID || this.pairingState.anchorSessionID || '',
          pairingTOON: pairingTOON || this.pairingState.pairingTOON || '',
          hostName: hostName || this.pairingState.hostName || '',
          bridgeID: String(snapshot.bridge_id || this.pairingState.bridgeID || '').trim(),
          bridgeDeviceID: String(snapshot.device_id || this.pairingState.bridgeDeviceID || '').trim(),
          bridgeReady: this.bridgeReady,
          bridgeState: this.bridgeState,
          bridgeMessage: this.bridgeMessage,
          peerReachable: this.peerValidated,
          peerState: this.currentPeerState(),
          peerDeviceID: this.remotePeerID,
          connectionState: this.connectionState
        };
      }

      if (wsURL) {
        this.peerURL = wsURL;
      }
    }

    hasDirectBridgeSession() {
      const sessionID = String(this.pairingState?.sessionID || '').trim();
      const resumeToken = String(this.pairingState?.resumeToken || '').trim();
      const socketURL = normalizeWebSocketURL(this.peerURL || this.pairingState?.wsURL || '');
      return Boolean(sessionID && resumeToken && socketURL);
    }

    hasDirectSocketRoute() {
      const socketURL = normalizeWebSocketURL(
        this.peerURL
        || this.pairingState?.wsURL
        || (this.pairingState?.localIP
          ? `ws://${this.pairingState.localIP}:${this.pairingState?.port || DEFAULT_PORT}/bridge`
          : '')
      );
      return Boolean(socketURL);
    }

    candidateSupportsDirectWebSocket(candidate) {
      const source = String(candidate?.source || candidate?.serviceType || candidate?.service_type || '').trim().toLowerCase();
      if (source.includes('self')) {
        return false;
      }

      if (candidate?.resumeSupported === false || candidate?.resume_supported === false) {
        return true;
      }

      const resumeSupported = String(candidate?.resumeSupported ?? candidate?.resume_supported ?? '').trim().toLowerCase();
      return source.includes('ios') || source.includes('direct') || resumeSupported === 'false';
    }

    async applyDirectSocketCandidate(candidate) {
      const hostIP = normalizeRouteHost(candidate?.hostIP || candidate?.host_ip || '');
      const port = DEFAULT_PORT;
      const wsURL = normalizeWebSocketURL(candidate?.wsURL || candidate?.websocketURL || candidate?.ws_url || (hostIP ? `ws://${hostIP}:${port}/bridge` : ''));
      if (!hostIP || !wsURL) {
        throw new Error('direct_socket_route_unavailable');
      }

      const previousPeerURL = this.peerURL;
      this.peerURL = wsURL;
      if (previousPeerURL && previousPeerURL !== this.peerURL) {
        this.closeActiveSocket('direct_candidate_route_changed');
      }
      this.bridgeReady = true;
      this.bridgeState = 'ready';
      this.bridgeMessage = 'Direct route ready';
      this.pairingState = {
        ...(this.pairingState || {}),
        localIP: hostIP,
        port,
        wsURL,
        sessionID: '',
        resumeToken: '',
        bridgeID: String(candidate?.bridgeID || candidate?.bridge_id || '').trim(),
        bridgeDeviceID: String(candidate?.deviceID || candidate?.device_id || '').trim(),
        hostName: String(candidate?.hostName || candidate?.host_name || '').trim(),
        bridgeReady: true,
        bridgeState: this.bridgeState,
        bridgeMessage: this.bridgeMessage,
        peerReachable: this.peerValidated,
        peerState: this.currentPeerState(),
        peerDeviceID: this.remotePeerID,
        connectionState: this.connectionState,
        lastError: ''
      };
      await storageSet({
        [STORAGE_KEYS.pairingState]: this.pairingState,
        [STORAGE_KEYS.savedRoute]: normalizeSavedRoute({ localIP: hostIP, wsURL })
      });
      return this.pairingState;
    }

    async discoverBridgeCandidates() {
      const response = await this.nativeRequest('DISCOVER_LOCAL_BRIDGES', {}, 12_000);
      this.discoveryTOON = String(response?.toon || '');
      await storageSet({ [STORAGE_KEYS.discovery]: this.discoveryTOON });
      return uniqCandidates(response?.candidates || []);
    }

    async pairWithBridge(candidate, manualCode) {
      const hostIP = normalizeRouteHost(candidate?.hostIP || candidate?.host_ip || this.pairingState?.localIP || '');
      const port = DEFAULT_PORT;
      if (!hostIP || !manualCode) {
        throw new Error('pairing_endpoint_unavailable');
      }

      const discovery = await fetchJSON(
        normalizeHTTPURL(hostIP, port, DISCOVERY_PATH),
        { method: 'GET' },
        BRIDGE_FETCH_TIMEOUT_MS
      );

      const clientNonceBytes = crypto.getRandomValues(new Uint8Array(16));
      const clientNonce = bytesToBase64URL(clientNonceBytes);
      const pairKey = await derivePairKey(manualCode, discovery.challenge_nonce, clientNonce);
      const encryptedRequest = await encryptJSON(pairKey, {
        purpose: 'tabsync.bridge.pair.v1',
        client_id: this.deviceID,
        origin_id: this.deviceID,
        requested_at: currentTimestamp(),
        requested_server_ip: hostIP
      });

      const response = await fetchJSON(
        normalizeHTTPURL(hostIP, port, PAIR_PATH),
        {
          method: 'POST',
          headers: {
            'content-type': 'application/json'
          },
          body: JSON.stringify({
            challenge_id: discovery.challenge_id,
            client_id: this.deviceID,
            client_nonce: clientNonce,
            ...encryptedRequest
          })
        },
        BRIDGE_FETCH_TIMEOUT_MS
      );

      const decrypted = await decryptJSON(pairKey, response);
      const boundServerIP = normalizeRouteHost(decrypted?.bound_server_ip || hostIP);
      const websocketURL = normalizeWebSocketURL(decrypted?.websocket_url || `ws://${hostIP}:${DEFAULT_PORT}/bridge`);
      if (!websocketURL || !decrypted?.resume_token) {
        throw new Error('pairing_ack_invalid');
      }

      return {
        sessionID: String(decrypted.session_id || response.session_id || '').trim(),
        resumeToken: String(decrypted.resume_token || '').trim(),
        wsURL: websocketURL,
        boundServerIP,
        observedClientIP: String(decrypted.observed_client_ip || '').trim(),
        bridgeID: String(decrypted.bridge_id || candidate?.bridgeID || '').trim(),
        bridgeDeviceID: String(decrypted.bridge_device_id || candidate?.deviceID || '').trim(),
        expiresAt: String(decrypted.expires_at || '').trim(),
        port
      };
    }

    async establishBridgeSession(forceRefresh = false) {
      if (this.hasDirectBridgeSession() && !forceRefresh) {
        return this.pairingState;
      }

      const manualCode = this.currentManualCode();
      if (!manualCode && this.hasDirectBridgeSession()) {
        return this.pairingState;
      }

      if (!manualCode) {
        throw new Error('bridge_session_unavailable');
      }

      const directCandidate = this.pairingState?.localIP
        ? [{
            hostIP: this.pairingState.localIP,
            port: this.pairingState.port || DEFAULT_PORT,
            bridgeID: this.pairingState.bridgeID || '',
            deviceID: this.pairingState.bridgeDeviceID || ''
          }]
        : [];
      const scanCandidates = forceRefresh || directCandidate.length === 0
        ? await this.discoverBridgeCandidates()
        : [];
      const candidates = uniqCandidates([...directCandidate, ...scanCandidates]).filter((candidate) => {
        const source = String(candidate?.source || '').trim().toLowerCase();
        const candidateDeviceID = String(candidate?.deviceID || candidate?.device_id || '').trim();
        return source !== 'self' && candidateDeviceID !== this.deviceID;
      });

      const directSocketCandidate = candidates.find((candidate) => this.candidateSupportsDirectWebSocket(candidate));
      if (directSocketCandidate) {
        return this.applyDirectSocketCandidate(directSocketCandidate);
      }

      let lastError = null;
      for (const candidate of candidates) {
        try {
          const session = await this.pairWithBridge(candidate, manualCode);
          this.peerURL = session.wsURL;
          this.pairingState = {
            ...(this.pairingState || {}),
            localIP: session.boundServerIP || candidate.hostIP || '',
            port: session.port || candidate.port || DEFAULT_PORT,
            wsURL: session.wsURL,
            sessionID: session.sessionID,
            resumeToken: session.resumeToken,
            bridgeID: session.bridgeID || candidate.bridgeID || this.pairingState?.bridgeID || '',
            bridgeDeviceID: session.bridgeDeviceID || candidate.deviceID || this.pairingState?.bridgeDeviceID || '',
            observedClientIP: session.observedClientIP,
            expiresAt: session.expiresAt,
            bridgeReady: this.bridgeReady,
            bridgeState: this.bridgeState,
            bridgeMessage: this.bridgeMessage,
            lastError: ''
          };
          await storageSet({
            [STORAGE_KEYS.pairingState]: this.pairingState,
            [STORAGE_KEYS.savedRoute]: normalizeSavedRoute({
              localIP: this.pairingState.localIP,
              wsURL: this.pairingState.wsURL
            })
          });
          return session;
        } catch (error) {
          lastError = error;
        }
      }

      throw lastError || new Error('bridge_scan_exhausted');
    }

    websocketConnectURL() {
      const baseURL = normalizeWebSocketURL(
        this.peerURL
        || this.pairingState?.wsURL
        || (this.pairingState?.localIP
          ? `ws://${this.pairingState.localIP}:${this.pairingState?.port || DEFAULT_PORT}/bridge`
          : '')
      );
      if (!baseURL) {
        return '';
      }

      const query = {
        client_id: this.deviceID,
        origin_id: this.deviceID
      };

      if (this.hasDirectBridgeSession()) {
        query.session_id = this.pairingState?.sessionID || '';
        query.resume_token = this.pairingState?.resumeToken || '';
      }

      return websocketQueryURL(baseURL, query);
    }

    async generatePairing(forceRefresh = false) {
      let anchor = null;
      let directLinkError = null;
      try {
        const canUseDirectSocketRoute = this.hasDirectSocketRoute();

        if (canUseDirectSocketRoute) {
          if (forceRefresh) {
            try {
              const nativeReady = await this.ensureNativeBridge();
              if (nativeReady) {
                const candidates = await this.discoverBridgeCandidates();
                const directSocketCandidate = candidates.find((candidate) => this.candidateSupportsDirectWebSocket(candidate));
                if (directSocketCandidate) {
                  await this.applyDirectSocketCandidate(directSocketCandidate);
                }
              }
            } catch (_) {
              this.bridgeReady = true;
              this.bridgeState = 'ready';
              this.bridgeMessage = 'Direct route ready';
            }
          }

          this.bridgeReady = true;
          this.bridgeState = 'ready';
          this.bridgeMessage = 'Direct route ready';
          await this.persistTransportState(this.runtimeConnectionState(), this.lastError);
          return {
            ok: true,
            ...this.pairingState,
            bridgeReady: this.bridgeReady,
            bridgeState: this.bridgeState,
            bridgeMessage: this.bridgeMessage,
            peerReachable: this.peerValidated,
            peerState: this.currentPeerState(),
            peerDeviceID: this.remotePeerID,
            discoveryTOON: this.discoveryTOON,
            linkedDevicesTOON: this.linkedDevicesTOON
          };
        }

        const nativeReady = await this.ensureNativeBridge();
        if (!nativeReady && this.hasDirectSocketRoute()) {
          this.bridgeReady = true;
          this.bridgeState = 'ready';
          this.bridgeMessage = 'Direct route ready';
          await this.persistTransportState(this.runtimeConnectionState(), this.lastError);
          return {
            ok: true,
            ...this.pairingState,
            bridgeReady: this.bridgeReady,
            bridgeState: this.bridgeState,
            bridgeMessage: this.bridgeMessage,
            peerReachable: this.peerValidated,
            peerState: this.currentPeerState(),
            peerDeviceID: this.remotePeerID,
            discoveryTOON: this.discoveryTOON,
            linkedDevicesTOON: this.linkedDevicesTOON
          };
        }

        if (this.bridgeReady && (forceRefresh || !this.hasDirectBridgeSession())) {
          try {
            await this.establishBridgeSession(forceRefresh);
          } catch (error) {
            directLinkError = error;
          }
        }

        if (!this.hasDirectBridgeSession()) {
          anchor = await this.syncPairingAnchor(forceRefresh);
        }

        if (this.bridgeReady && (forceRefresh || !this.hasDirectBridgeSession())) {
          await this.establishBridgeSession(forceRefresh);
        }

        if (!this.hasDirectBridgeSession()) {
          const missingSessionError = directLinkError?.message || 'bridge_session_unavailable';
          await this.persistTransportState('idle', missingSessionError);
          return {
            ok: false,
            ...this.pairingState,
            bridgeReady: this.bridgeReady,
            bridgeState: this.bridgeState,
            bridgeMessage: this.bridgeMessage,
            peerReachable: this.peerValidated,
            peerState: this.currentPeerState(),
            peerDeviceID: this.remotePeerID,
            discoveryTOON: this.discoveryTOON,
            linkedDevicesTOON: this.linkedDevicesTOON,
            error: missingSessionError
          };
        }

        await this.persistTransportState(this.runtimeConnectionState(), this.lastError);
        return {
          ok: true,
          ...this.pairingState,
          bridgeReady: this.bridgeReady,
          bridgeState: this.bridgeState,
          bridgeMessage: this.bridgeMessage,
          peerReachable: this.peerValidated,
          peerState: this.currentPeerState(),
          peerDeviceID: this.remotePeerID,
          discoveryTOON: this.discoveryTOON,
          linkedDevicesTOON: this.linkedDevicesTOON
        };
      } catch (error) {
        this.bridgeUnavailable(error?.message || 'pairing_generate_failed');
        await this.persistTransportState('idle', error?.message || 'pairing_generate_failed');
        return {
          ok: Boolean(this.hasDirectBridgeSession() || anchor?.manualCode || this.pairingState?.manualCode),
          ...this.pairingState,
          bridgeReady: false,
          bridgeState: this.bridgeState,
          bridgeMessage: this.bridgeMessage,
          peerReachable: false,
          peerState: this.currentPeerState(),
          peerDeviceID: this.remotePeerID,
          discoveryTOON: this.discoveryTOON,
          linkedDevicesTOON: this.linkedDevicesTOON,
          error: error?.message || 'pairing_generate_failed'
        };
      }
    }

    async restoreConnection(reason = 'restore', forceRefreshPairing = false) {
      await this.ensureSavedRouteConnectIntent(reason);
      const pairingState = await this.generatePairing(forceRefreshPairing);
      if (!pairingState?.ok || !this.hasDirectSocketRoute()) {
        return {
          ok: false,
          restored: false,
          error: pairingState?.error || 'socket_route_unavailable'
        };
      }

      if (forceRefreshPairing) {
        this.closeActiveSocket(`${reason}_refresh`);
      }
      this.connect(reason, forceRefreshPairing);
      return {
        ok: true,
        restored: true,
        state_toon: this.buildSocketStateTOON('connecting'),
        document_toon: this.buildDocumentTOON('active')
      };
    }

    connect(_reason = 'connect', forceReconnect = false) {
      if (!this.hasDirectSocketRoute()) {
        return;
      }

      const socketURL = this.websocketConnectURL();
      if (!socketURL) {
        void this.persistTransportState('idle', 'socket_url_unavailable');
        return;
      }

      if (forceReconnect) {
        this.closeActiveSocket(`${_reason}_force_reconnect`);
      } else if (this.socket && (this.socket.readyState === WebSocket.OPEN || this.socket.readyState === WebSocket.CONNECTING)) {
        if (this.activeSocketURL === socketURL) {
          return;
        }
        this.closeActiveSocket(`${_reason}_socket_url_changed`);
      }

      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
      this.clearConnectTimeout();
      this.clearValidationTimeout();

      this.socket = new WebSocket(socketURL);
      this.activeSocketURL = socketURL;
      this.socketCloseHandled = false;
      this.peerValidated = false;
      this.lastPeerMessageAt = Date.now();
      this.preventReconnect = false;
      this.connectionState = 'connecting';
      this.lastError = '';
      void this.persistTransportState('connecting');

      const connectStartedAt = Date.now();
      let socketOpened = false;
      let connectSettled = false;
      const classifyPreflightFailure = (elapsedMs) => (
        elapsedMs >= SOCKET_CONNECT_TIMEOUT_MS - 250 ? 'ETIMEDOUT' : 'ECONNREFUSED'
      );
      const finalizePreflightFailure = (code) => {
        if (connectSettled || socketOpened) {
          return false;
        }

        connectSettled = true;
        const normalizedCode = transportErrorCode({ code }, 'ECONNREFUSED') || 'ECONNREFUSED';
        this.clearConnectTimeout();
        this.clearValidationTimeout();
        this.stopHeartbeat();
        this.socket = null;
        this.activeSocketURL = '';
        this.peerValidated = false;
        this.preventReconnect = false;
        this.connectionState = 'disconnected';
        this.lastError = normalizedCode;
        this.updateLinkedDevicesTOON();
        void this.persistTransportState(this.connectionState, normalizedCode);
        void this.publishRuntimeUpdate(normalizedCode === 'ETIMEDOUT' ? 'socket_timeout' : 'socket_refused');
        this.scheduleReconnect(normalizedCode === 'ECONNREFUSED' ? 'refused' : 'default');
        return true;
      };

      this.connectTimeoutTimer = setTimeout(() => {
        const activeSocket = this.socket;
        finalizePreflightFailure('ETIMEDOUT');
        try {
          activeSocket?.close();
        } catch (_) {
        }
      }, SOCKET_CONNECT_TIMEOUT_MS);

      this.socket.addEventListener('open', (event) => {
        if (event?.target && event.target !== this.socket) {
          return;
        }

        socketOpened = true;
        connectSettled = true;
        this.clearConnectTimeout();
        this.peerValidated = false;
        this.preventReconnect = false;
        this.connectionState = 'connecting';
        this.reconnectAttempt = 0;
        this.sendSocketTOON(
          encodeTOON(
            'bridge_session',
            ['event', 'origin_id', 'session_id', 'resume_fingerprint', 'transport', 'opened_at'],
            [[
              this.hasDirectBridgeSession() ? 'resume' : 'open',
              this.deviceID,
              this.pairingState?.sessionID || '',
              hashFingerprint(this.pairingState?.resumeToken || ''),
              'websocket',
              currentTimestamp()
            ]]
          )
        );
        this.startHeartbeat();
        this.clearValidationTimeout();
        this.validationTimer = setTimeout(() => {
          if (this.peerValidated || this.socket?.readyState !== WebSocket.OPEN) {
            return;
          }

          if (Date.now() - this.lastPeerMessageAt < SOCKET_VALIDATION_TIMEOUT_MS) {
            this.clearValidationTimeout();
            this.validationTimer = setTimeout(() => {
              if (!this.peerValidated && this.socket?.readyState === WebSocket.OPEN && Date.now() - this.lastPeerMessageAt >= SOCKET_VALIDATION_TIMEOUT_MS) {
                this.lastError = 'validation_timeout';
                void this.persistTransportState('connecting', this.lastError);
                void this.publishRuntimeUpdate('validation_waiting');
              }
            }, SOCKET_VALIDATION_TIMEOUT_MS);
            return;
          }

          this.lastError = 'validation_timeout';
          void this.persistTransportState('connecting', this.lastError);
          void this.publishRuntimeUpdate('validation_waiting');
        }, SOCKET_VALIDATION_TIMEOUT_MS);
        void this.persistTransportState('connecting');
        void this.publishRuntimeUpdate('socket_open');
      });

      this.socket.addEventListener('message', (event) => {
        if (event?.target && event.target !== this.socket) {
          return;
        }

        if (typeof event.data !== 'string') {
          return;
        }
        this.handlePeerPayload(event.data);
      });

      this.socket.addEventListener('close', (event) => {
        if (event?.target && event.target !== this.socket) {
          return;
        }

        if (this.socketCloseHandled) {
          this.socketCloseHandled = false;
          return;
        }

        const elapsedMs = Date.now() - connectStartedAt;
        if (finalizePreflightFailure(classifyPreflightFailure(elapsedMs))) {
          return;
        }

        this.clearConnectTimeout();
        this.clearValidationTimeout();
        this.stopHeartbeat();
        this.socket = null;
        this.activeSocketURL = '';
        this.peerValidated = false;
        this.updateLinkedDevicesTOON();

        if (this.preventReconnect || this.lastError === 'pairing_rejected') {
          this.connectionState = 'failed';
          void this.persistTransportState('failed', this.lastError || 'pairing_rejected');
          void this.publishRuntimeUpdate('handshake_rejected');
          return;
        }

        this.connectionState = 'disconnected';
        void this.persistTransportState('disconnected', this.lastError);
        void this.publishRuntimeUpdate('socket_closed');
        this.scheduleReconnect();
      });

      this.socket.addEventListener('error', (event) => {
        if (event?.target && event.target !== this.socket) {
          return;
        }

        const elapsedMs = Date.now() - connectStartedAt;
        if (!socketOpened) {
          finalizePreflightFailure(classifyPreflightFailure(elapsedMs));
          return;
        }

        this.clearConnectTimeout();
        this.clearValidationTimeout();
        this.stopHeartbeat();
        const activeSocket = this.socket;
        this.socket = null;
        this.activeSocketURL = '';
        this.peerValidated = false;
        this.updateLinkedDevicesTOON();
        if (this.preventReconnect) {
          this.connectionState = 'failed';
          void this.persistTransportState('failed', this.lastError || 'pairing_rejected');
          void this.publishRuntimeUpdate('handshake_rejected');
          return;
        }

        this.connectionState = 'error';
        this.lastError = 'socket_error';
        void this.persistTransportState('error', this.lastError);
        void this.publishRuntimeUpdate('socket_error');
        try {
          activeSocket?.close?.(1001, 'socket_error');
        } catch (_) {
        }
        this.scheduleReconnect();
      });
    }

    scheduleReconnect(strategy = 'default') {
      this.reconnectAttempt += 1;
      const isRefusedRetry = strategy === 'refused';
      const baseDelay = isRefusedRetry ? REFUSED_RECONNECT_BASE_MS : BASE_RECONNECT_MS;
      const maxDelay = isRefusedRetry ? REFUSED_RECONNECT_MAX_MS : MAX_RECONNECT_MS;
      const exponent = Math.min(Math.max(this.reconnectAttempt - 1, 0), isRefusedRetry ? 2 : 4);
      const delay = Math.min(maxDelay, baseDelay * (2 ** exponent));
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = setTimeout(() => {
        void this.restoreConnection(
          isRefusedRetry ? 'refused_retry' : 'reconnect',
          this.reconnectAttempt > 1
        );
      }, delay);
    }

    startHeartbeat() {
      this.stopHeartbeat();
      this.lastPeerHeartbeatAt = Date.now();
      this.lastPeerMessageAt = this.lastPeerHeartbeatAt;
      this.heartbeatTimer = setInterval(() => {
        const sent = this.sendSocketTOON(
          encodeTOON(
            'heartbeat',
            ['event', 'origin_id', 'device_id', 'sent_at'],
            [[
              'ping',
              this.deviceID,
              this.deviceID,
              currentTimestamp()
            ]]
          )
        );
        const lastPeerActivityAt = Math.max(this.lastPeerHeartbeatAt, this.lastPeerMessageAt);
        if (sent && Date.now() - lastPeerActivityAt > HEARTBEAT_GRACE_MS) {
          this.handleHeartbeatTimeout();
        }
      }, HEARTBEAT_MS);
    }

    handleHeartbeatTimeout() {
      if (this.connectionState === 'disconnected' && this.lastError === 'heartbeat_timeout') {
        return;
      }

      const activeSocket = this.socket;
      this.clearConnectTimeout();
      this.clearValidationTimeout();
      this.stopHeartbeat();
      this.socket = null;
      this.socketCloseHandled = false;
      this.peerValidated = false;
      this.connectionState = 'disconnected';
      this.lastError = 'heartbeat_timeout';
      this.updateLinkedDevicesTOON();
      void this.persistTransportState('disconnected', this.lastError);
      void this.publishRuntimeUpdate('heartbeat_timeout');
      try {
        activeSocket?.close?.(1001, 'heartbeat_timeout');
      } catch (_) {
      }
      this.scheduleReconnect();
    }

    stopHeartbeat() {
      if (this.heartbeatTimer) {
        clearInterval(this.heartbeatTimer);
        this.heartbeatTimer = null;
      }
    }

    sendSocketTOON(toon) {
      if (!this.socket || this.socket.readyState !== WebSocket.OPEN) {
        return false;
      }

      this.socket.send(String(toon || ''));
      return true;
    }

    queuePendingTOON(payload) {
      const normalizedPayload = String(payload || '').trim();
      if (!normalizedPayload) {
        return;
      }

      const parsed = decodeTOON(normalizedPayload);
      if (parsed?.name === 'tabs') {
        this.pendingTOONs = this.pendingTOONs.filter((item) => decodeTOON(item)?.name !== 'tabs');
      }

      this.pendingTOONs.push(normalizedPayload);
      if (this.pendingTOONs.length > MAX_PENDING_TOONS) {
        this.pendingTOONs.splice(0, this.pendingTOONs.length - MAX_PENDING_TOONS);
      }

      if ((parsed?.name === 'remote_tab_action' || parsed?.name === 'device_visibility')
        && hasSavedDirectRoute(this.pairingState)) {
        this.pairingState = {
          ...(this.pairingState || {}),
          connectRequested: true,
          connectionState: 'connecting',
          lastError: ''
        };
        void storageSet({ [STORAGE_KEYS.pairingState]: this.pairingState });
      }
    }

    sendTOON(toon) {
      const payload = String(toon || '');
      if (!payload.trim()) {
        return false;
      }

      if (!this.peerValidated) {
        this.queuePendingTOON(payload);
        return false;
      }

      if (!this.sendSocketTOON(payload)) {
        this.queuePendingTOON(payload);
        return false;
      }

      return true;
    }

    flushPendingTOONs() {
      if (!this.peerValidated) {
        return;
      }

      while (this.pendingTOONs.length > 0 && this.socket?.readyState === WebSocket.OPEN) {
        this.socket.send(this.pendingTOONs.shift());
      }
    }

    async requestTabSnapshot(reason) {
      const response = await runtimeSendMessage({
        type: 'REQUEST_TAB_SNAPSHOT',
        reason
      });

      const payload = String(response?.payload || response?.toon || '').trim();
      if (response?.ok && payload) {
        this.sendTOON(payload);
      }
    }

    storeVerification(status, signature, peerDeviceID) {
      this.remotePeerID = String(peerDeviceID || '').trim();
      this.verificationTOON = encodeTOON(
        'verification',
        ['status', 'signature', 'peer_device_id', 'received_at'],
        [[
          status,
          signature,
          peerDeviceID,
          currentTimestamp()
        ]]
      );
      this.updateLinkedDevicesTOON();
      void storageSet({
        [STORAGE_KEYS.verification]: this.verificationTOON,
        [STORAGE_KEYS.linked]: this.linkedDevicesTOON
      });
    }

    async finalizeSecureLink(reason = 'securely_linked') {
      if (this.peerValidated && this.connectionState === 'connected' && !this.lastError) {
        return;
      }

      this.peerValidated = true;
      this.preventReconnect = false;
      this.connectionState = 'connected';
      this.lastError = '';
      this.reconnectAttempt = 0;
      this.clearValidationTimeout();
      this.flushPendingTOONs();
      this.updateLinkedDevicesTOON();
      await this.requestTabSnapshot(reason);
      await this.persistTransportState('connected');
      await this.publishRuntimeUpdate(reason);
    }

    applyBridgeStatusEnvelope(payload) {
      const server = payload && typeof payload === 'object' ? (payload.server || {}) : {};
      const hostIP = normalizeRouteHost(server.ip_address || server.host_ip || '');
      const port = DEFAULT_PORT;
      const peerDeviceID = String(server.id || payload?.peer_device_id || '').trim();
      const status = String(payload?.status || '').trim().toLowerCase();
      const wsURL = hostIP ? normalizeWebSocketURL(`ws://${hostIP}:${port}/bridge`) : '';

      if (peerDeviceID) {
        this.remotePeerID = peerDeviceID;
      }

      if (!this.pairingState) {
        this.pairingState = {};
      }

      this.bridgeReady = status === 'ready' || this.bridgeReady;
      this.bridgeState = this.bridgeReady ? 'ready' : (this.bridgeState || 'waiting');
      this.bridgeMessage = this.bridgeReady ? 'Bridge Reachable' : (this.bridgeMessage || 'Waiting for Bridge');
      this.pairingState = {
        ...this.pairingState,
        localIP: hostIP || this.pairingState.localIP || '',
        port,
        wsURL: wsURL || this.pairingState.wsURL || '',
        hostName: String(server.name || payload?.host_name || this.pairingState.hostName || '').trim(),
        bridgeReady: this.bridgeReady,
        bridgeState: this.bridgeState,
        bridgeMessage: this.bridgeMessage,
        peerDeviceID: this.remotePeerID || this.pairingState.peerDeviceID || ''
      };
    }

    normalizeRemoteTabRecord(source = {}, fallbackOriginID = '') {
      const originID = String(source.origin_id || source.originID || fallbackOriginID || source.device_id || source.deviceID || '').trim();
      const deviceID = String(source.device_id || source.deviceID || originID).trim() || originID;
      const url = String(source.url || '').trim();
      const tabID = String(source.tab_id || source.tabID || source.id || `${originID}|${url}`).trim();
      if (!originID || !tabID || !isSyncableTabURL(url) || originID === this.deviceID || deviceID === this.deviceID) {
        return null;
      }
      if (this.hiddenDeviceOrigins.has(originID) || this.hiddenDeviceOrigins.has(deviceID)) {
        return null;
      }

      return {
        cache_key: this.remoteTabKey(originID, tabID, url),
        tab_id: tabID,
        origin_id: originID,
        device_id: deviceID,
        url,
        title: String(source.title || '').trim(),
        last_updated_timestamp: String(source.last_updated_timestamp || source.updated_at || source.updatedAt || currentTimestamp()).trim(),
        device_name: String(source.device_name || source.deviceName || source.device || source.host_name || source.hostName || deviceID).trim() || deviceID,
        browser_name: String(source.browser_name || source.browserName || source.browser || 'Browser').trim() || 'Browser',
        platform: String(source.platform || 'desktop').trim() || 'desktop'
      };
    }

    isIOSSafariTab(tab) {
      const platform = String(tab?.platform || '').trim().toLowerCase();
      const browserName = String(tab?.browser_name || tab?.browserName || tab?.browser || '').trim().toLowerCase();
      const originID = String(tab?.origin_id || tab?.originID || tab?.device_id || tab?.deviceID || '').trim().toLowerCase();
      return platform === 'ios'
        || originID.startsWith('ios-')
        || originID.startsWith('safari-ios')
        || (browserName === 'safari' && platform !== 'macos' && platform !== 'desktop');
    }

    expandIOSSafariReplacementOrigins(originsInSnapshot, normalizedTabs) {
      if (!Array.isArray(normalizedTabs) || !normalizedTabs.some((tab) => this.isIOSSafariTab(tab))) {
        return;
      }

      for (const tab of this.remoteTabsByID.values()) {
        if (this.isIOSSafariTab(tab)) {
          const originID = String(tab?.origin_id || tab?.device_id || '').trim();
          if (originID) {
            originsInSnapshot.add(originID);
          }
        }
      }
    }

    clearIOSSafariTabs() {
      let didChange = false;
      for (const [cacheKey, tab] of this.remoteTabsByID.entries()) {
        if (this.isIOSSafariTab(tab)) {
          this.remoteTabsByID.delete(cacheKey);
          didChange = true;
        }
      }
      return didChange;
    }

    remoteTabKey(originID, tabID, url) {
      const resolvedOriginID = String(originID || '').trim();
      const resolvedTabID = String(tabID || '').trim();
      if (resolvedTabID) {
        return `${resolvedOriginID}|${resolvedTabID}`;
      }
      return `${resolvedOriginID}|${String(url || '').trim()}`;
    }

    replaceTabsFromJSONArray(tabs) {
      const normalizedTabs = [];
      const originsInSnapshot = new Set();

      for (const item of Array.isArray(tabs) ? tabs : []) {
        const rawOriginID = String(item?.origin_id || item?.originID || item?.device_id || item?.deviceID || this.remotePeerID || '').trim();
        if (rawOriginID) {
          originsInSnapshot.add(rawOriginID);
        }
        const normalized = this.normalizeRemoteTabRecord(item, this.remotePeerID);
        if (!normalized) {
          continue;
        }

        normalizedTabs.push(normalized);
        originsInSnapshot.add(normalized.origin_id);
      }

      if (normalizedTabs.length === 0 && Array.isArray(tabs) && tabs.length === 0) {
        this.clearIOSSafariTabs();
      }
      this.expandIOSSafariReplacementOrigins(originsInSnapshot, normalizedTabs);
      this.replaceTabsForOrigins(originsInSnapshot, normalizedTabs);
      this.updateLinkedDevicesTOON();
    }

    handlePeerPayload(toon) {
      this.lastPeerMessageAt = Date.now();
      const jsonPayload = parsePeerJSONPayload(toon);
      if (Array.isArray(jsonPayload)) {
        this.replaceTabsFromJSONArray(jsonPayload);
        void storageSet({
          [STORAGE_KEYS.tabs]: this.buildTabSnapshotTOON(),
          [STORAGE_KEYS.linked]: this.linkedDevicesTOON
        });
        void this.publishRuntimeUpdate('tabs_snapshot_json');
        return;
      }

      if (jsonPayload && typeof jsonPayload === 'object') {
        if (String(jsonPayload.type || '').trim().toLowerCase() === 'bridge_status') {
          this.lastPeerHeartbeatAt = Date.now();
          this.applyBridgeStatusEnvelope(jsonPayload);
          void this.persistTransportState(this.runtimeConnectionState(), this.lastError);
          void this.publishRuntimeUpdate('bridge_status');
          return;
        }

        return;
      }

      const parsed = decodeTOON(toon);
      if (!parsed) {
        this.lastError = 'invalid_toon_from_peer';
        void this.persistTransportState('error', this.lastError);
        return;
      }

      if (parsed.name === 'heartbeat') {
        this.lastPeerHeartbeatAt = Date.now();
        const row = parsed.rows[0] || [];
        const event = String(toonValue(parsed, row, 'event') || '').trim().toLowerCase();
        if (event === 'ping') {
          this.sendSocketTOON(
            encodeTOON(
              'heartbeat',
              ['event', 'origin_id', 'device_id', 'sent_at'],
              [[
                'pong',
                this.deviceID,
                this.deviceID,
                currentTimestamp()
              ]]
            )
          );
        }
        if (event === 'ping' || event === 'pong') {
          this.lastError = '';
          void this.persistTransportState(this.runtimeConnectionState(), this.lastError);
        }
        return;
      }

      if (parsed.name === 'verification') {
        const row = parsed.rows[0] || [];
        const status = String(toonValue(parsed, row, 'status', ['verified']) || 'pending').trim().toLowerCase();
        if (status === 'verified') {
          this.storeVerification(
            'verified',
            toonValue(parsed, row, 'signature', ['sig']),
            toonValue(parsed, row, 'peer_device_id', ['peer', 'peer_id'])
          );
          void this.finalizeSecureLink('securely_linked');
          return;
        }

        if (status === 'rejected' || status === 'denied' || status === 'failed') {
          this.peerValidated = false;
          this.preventReconnect = true;
          this.connectionState = 'failed';
          this.lastError = 'pairing_rejected';
          this.storeVerification(
            status,
            toonValue(parsed, row, 'signature', ['sig']),
            toonValue(parsed, row, 'peer_device_id', ['peer', 'peer_id'])
          );
          void this.persistTransportState('failed', this.lastError);
          void this.publishRuntimeUpdate('handshake_rejected');
        }
        return;
      }

      if (parsed.name === 'remote_tab_action') {
        if (!this.peerValidated) {
          return;
        }

        this.signalTOON = toon;
        void storageSet({ [STORAGE_KEYS.signal]: this.signalTOON });
        void runtimeSendMessage({
          type: 'OFFSCREEN_REMOTE_TOON',
          source: 'socket',
          toon
        });
        void this.publishRuntimeUpdate('remote_action');
        return;
      }

      if (parsed.name === 'device_visibility') {
        if (!this.peerValidated) {
          return;
        }

        for (const originID of deviceVisibilityTargetOriginIDs(parsed)) {
          void this.removeRemoteDevice(originID);
        }
        this.signalTOON = toon;
        void storageSet({ [STORAGE_KEYS.signal]: this.signalTOON });
        void runtimeSendMessage({
          type: 'OFFSCREEN_DEVICE_VISIBILITY',
          source: 'socket',
          toon
        });
        void this.publishRuntimeUpdate('device_visibility');
        return;
      }

      if (parsed.name === 'close_action_ack') {
        if (!this.peerValidated) {
          return;
        }

        this.applyCloseActionAck(parsed);
        this.signalTOON = toon;
        void storageSet({
          [STORAGE_KEYS.tabs]: this.buildTabSnapshotTOON(),
          [STORAGE_KEYS.linked]: this.linkedDevicesTOON,
          [STORAGE_KEYS.signal]: this.signalTOON
        });
        void runtimeSendMessage({
          type: 'OFFSCREEN_CLOSE_ACTION_ACK',
          source: 'socket',
          toon
        });
        void this.publishRuntimeUpdate('close_action_ack');
        return;
      }

      if (parsed.name === 'tab_origin_snapshot') {
        this.applyOriginSnapshot(parsed);
        void storageSet({
          [STORAGE_KEYS.tabs]: this.buildTabSnapshotTOON(),
          [STORAGE_KEYS.linked]: this.linkedDevicesTOON
        });
        void this.publishRuntimeUpdate('tab_origin_snapshot');
        return;
      }

      if (parsed.name === 'tabs_delta') {
        if (!this.peerValidated) {
          return;
        }

        this.applyDeltaRows(parsed);
        this.updateLinkedDevicesTOON();
        void storageSet({
          [STORAGE_KEYS.tabs]: this.buildTabSnapshotTOON(),
          [STORAGE_KEYS.linked]: this.linkedDevicesTOON
        });
        void this.publishRuntimeUpdate('tabs_delta');
        return;
      }

      if (parsed.name === 'tabs') {
        this.replaceTabsFromTOON(toon);
        this.updateLinkedDevicesTOON();
        void storageSet({
          [STORAGE_KEYS.tabs]: this.buildTabSnapshotTOON(),
          [STORAGE_KEYS.linked]: this.linkedDevicesTOON
        });
        void this.publishRuntimeUpdate('tabs_snapshot');
        return;
      }

      this.signalTOON = toon;
      void storageSet({ [STORAGE_KEYS.signal]: this.signalTOON });
      void this.publishRuntimeUpdate(parsed.name);
    }

    applyDeltaRows(table) {
      for (const row of table.rows) {
        const originID = String(toonValue(table, row, 'origin_id', ['device_id', 'device']) || '').trim();
        const deviceID = String(toonValue(table, row, 'device_id', ['origin_id', 'device']) || originID).trim();
        const url = String(toonValue(table, row, 'url') || '').trim();
        const tabID = String(toonValue(table, row, 'tab_id', ['id']) || `${originID}|${url}`).trim();
        const cacheKey = this.remoteTabKey(originID, tabID, url);
        if (!tabID) {
          continue;
        }

        if (!originID || originID === this.deviceID || deviceID === this.deviceID || !isSyncableTabURL(url)) {
          this.remoteTabsByID.delete(cacheKey);
          continue;
        }

        if (this.hiddenDeviceOrigins.has(originID) || this.hiddenDeviceOrigins.has(deviceID)) {
          this.remoteTabsByID.delete(cacheKey);
          continue;
        }

        if ((toonValue(table, row, 'change', ['action', 'op']) || '').toLowerCase() === 'delete') {
          this.remoteTabsByID.delete(cacheKey);
          continue;
        }

        this.remoteTabsByID.set(cacheKey, {
          tab_id: tabID,
          origin_id: originID,
          device_id: deviceID,
          url,
          title: String(toonValue(table, row, 'title') || '').trim(),
          last_updated_timestamp: String(toonValue(table, row, 'last_updated_timestamp', ['updated_at']) || currentTimestamp()).trim(),
          device_name: String(toonValue(table, row, 'device_name', ['host_name', 'display_name']) || deviceID).trim() || deviceID,
          browser_name: String(toonValue(table, row, 'browser_name', ['browser', 'client_name']) || 'Browser').trim() || 'Browser',
          platform: String(toonValue(table, row, 'platform') || 'desktop').trim() || 'desktop'
        });
      }

      this.updateLinkedDevicesTOON();
    }

    applyOriginSnapshot(table) {
      let didChange = false;

      for (const row of table.rows) {
        const originID = String(toonValue(table, row, 'origin_id', ['device_id', 'source_device_id']) || '').trim();
        const deviceID = String(toonValue(table, row, 'device_id', ['origin_id', 'source_device_id']) || originID).trim();
        const browserName = String(toonValue(table, row, 'browser_name', ['browser']) || '').trim().toLowerCase();
        const platform = String(toonValue(table, row, 'platform') || '').trim().toLowerCase();
        const countLiteral = String(toonValue(table, row, 'tab_count', ['count', 'tabs']) || '').trim();
        const tabCount = Number.parseInt(countLiteral, 10);
        if (!originID || originID === this.deviceID || deviceID === this.deviceID) {
          continue;
        }
        if (this.hiddenDeviceOrigins.has(originID) || this.hiddenDeviceOrigins.has(deviceID)) {
          continue;
        }
        if (!Number.isFinite(tabCount) || tabCount > 0) {
          continue;
        }

        const snapshotIsIOSSafari = platform === 'ios' || browserName === 'safari';
        for (const [cacheKey, tab] of this.remoteTabsByID.entries()) {
          const tabOriginID = String(tab?.origin_id || '').trim();
          const tabDeviceID = String(tab?.device_id || '').trim();
          if (
            tabOriginID === originID
            || (originID === deviceID && tabDeviceID === deviceID)
            || (snapshotIsIOSSafari && this.isIOSSafariTab(tab))
          ) {
            this.remoteTabsByID.delete(cacheKey);
            didChange = true;
          }
        }
      }

      if (didChange) {
        this.updateLinkedDevicesTOON();
      }
    }

    applyCloseActionAck(table) {
      for (const row of table.rows) {
        const status = String(toonValue(table, row, 'status', ['result']) || '').trim().toLowerCase();
        if (status !== 'closed' && status !== 'ok' && status !== 'success') {
          continue;
        }

        const originID = String(
          toonValue(table, row, 'target_device_id', ['target_origin_id', 'origin_id', 'device_id'])
          || ''
        ).trim();
        const tabID = String(toonValue(table, row, 'tab_id', ['id']) || '').trim();
        const url = String(toonValue(table, row, 'url', ['target_url']) || '').trim();
        if (!originID || (!tabID && !url)) {
          continue;
        }

        this.remoteTabsByID.delete(this.remoteTabKey(originID, tabID, url));
        if (url) {
          for (const [key, tab] of this.remoteTabsByID.entries()) {
            if (tab?.origin_id === originID && tab?.url === url) {
              this.remoteTabsByID.delete(key);
            }
          }
        }
      }

      this.updateLinkedDevicesTOON();
    }

    replaceTabsFromTOON(toon) {
      const parsed = decodeTOON(toon);
      if (!parsed || parsed.name !== 'tabs') {
        return;
      }

      const normalizedTabs = [];
      const originsInSnapshot = new Set();

      if (parsed.rows.length === 0) {
        this.clearIOSSafariTabs();
        this.updateLinkedDevicesTOON();
        return;
      }

      for (const row of parsed.rows) {
        const originID = String(toonValue(parsed, row, 'origin_id', ['device_id', 'device']) || '').trim();
        const deviceID = String(toonValue(parsed, row, 'device_id', ['origin_id', 'device']) || originID).trim();
        const url = String(toonValue(parsed, row, 'url') || '').trim();
        const tabID = String(toonValue(parsed, row, 'tab_id', ['id']) || `${originID}|${url}`).trim();
        const cacheKey = this.remoteTabKey(originID, tabID, url);
        if (originID) {
          originsInSnapshot.add(originID);
        }
        if (!tabID || !originID || !deviceID || originID === this.deviceID || deviceID === this.deviceID || !isSyncableTabURL(url)) {
          continue;
        }
        if (this.hiddenDeviceOrigins.has(originID) || this.hiddenDeviceOrigins.has(deviceID)) {
          originsInSnapshot.add(originID);
          continue;
        }

        const normalized = {
          cache_key: cacheKey,
          tab_id: tabID,
          origin_id: originID,
          device_id: deviceID,
          url,
          title: String(toonValue(parsed, row, 'title') || '').trim(),
          last_updated_timestamp: String(toonValue(parsed, row, 'last_updated_timestamp', ['updated_at']) || currentTimestamp()).trim(),
          device_name: String(toonValue(parsed, row, 'device_name', ['host_name', 'display_name']) || deviceID).trim() || deviceID,
          browser_name: String(toonValue(parsed, row, 'browser_name', ['browser', 'client_name']) || 'Browser').trim() || 'Browser',
          platform: String(toonValue(parsed, row, 'platform') || 'desktop').trim() || 'desktop'
        };
        normalizedTabs.push(normalized);
      }

      this.expandIOSSafariReplacementOrigins(originsInSnapshot, normalizedTabs);
      this.replaceTabsForOrigins(originsInSnapshot, normalizedTabs);
      this.updateLinkedDevicesTOON();
    }

    replaceTabsForOrigins(originsInSnapshot, normalizedTabs) {
      if (!(originsInSnapshot instanceof Set) || originsInSnapshot.size === 0) {
        return;
      }

      for (const [cacheKey, tab] of this.remoteTabsByID.entries()) {
        const originID = String(tab?.origin_id || tab?.device_id || '').trim();
        if (originsInSnapshot.has(originID)) {
          this.remoteTabsByID.delete(cacheKey);
        }
      }

      for (const tab of Array.isArray(normalizedTabs) ? normalizedTabs : []) {
        const originID = String(tab?.origin_id || '').trim();
        const deviceID = String(tab?.device_id || '').trim();
        if (tab?.cache_key && !this.hiddenDeviceOrigins.has(originID) && !this.hiddenDeviceOrigins.has(deviceID)) {
          this.remoteTabsByID.set(tab.cache_key, tab);
        }
      }
    }

    async replaceTabs(toon) {
      this.replaceTabsFromTOON(toon);
      await storageSet({
        [STORAGE_KEYS.tabs]: this.buildTabSnapshotTOON(),
        [STORAGE_KEYS.linked]: this.linkedDevicesTOON
      });
      return {
        ok: true,
        tabs_toon: this.buildTabSnapshotTOON(),
        linked_devices_toon: this.linkedDevicesTOON
      };
    }

    async removeRemoteDevice(originID) {
      const normalizedOriginID = String(originID || '').trim();
      if (!normalizedOriginID) {
        return { ok: false, error: 'missing_origin_id' };
      }

      this.hiddenDeviceOrigins.add(normalizedOriginID);
      for (const [cacheKey, tab] of this.remoteTabsByID.entries()) {
        if (String(tab?.origin_id || tab?.device_id || '').trim() === normalizedOriginID) {
          this.remoteTabsByID.delete(cacheKey);
        }
      }
      this.updateLinkedDevicesTOON();
      await storageSet({
        [STORAGE_KEYS.tabs]: this.buildTabSnapshotTOON(),
        [STORAGE_KEYS.linked]: this.linkedDevicesTOON,
        [STORAGE_KEYS.hiddenDevices]: Array.from(this.hiddenDeviceOrigins).sort()
      });
      await this.publishRuntimeUpdate('device_removed');
      return {
        ok: true,
        tabs_toon: this.buildTabSnapshotTOON(),
        linked_devices_toon: this.linkedDevicesTOON
      };
    }

    async persistTransportState(connectionState, lastError = '') {
      this.connectionState = connectionState;
      this.lastError = lastError;
      this.updateLinkedDevicesTOON();
      if (this.pairingState) {
        this.pairingState = {
          ...this.pairingState,
          connectionState,
          wsURL: this.peerURL || this.pairingState.wsURL,
          bridgeReady: this.bridgeReady,
          bridgeState: this.bridgeState,
          bridgeMessage: this.bridgeMessage,
          peerReachable: this.peerValidated,
          peerState: this.currentPeerState(),
          peerDeviceID: this.remotePeerID,
          lastError
        };
      }

      await storageSet({
        [STORAGE_KEYS.document]: this.buildDocumentTOON('active'),
        [STORAGE_KEYS.state]: this.buildSocketStateTOON(connectionState, lastError),
        [STORAGE_KEYS.tabs]: this.buildTabSnapshotTOON(),
        [STORAGE_KEYS.linked]: this.linkedDevicesTOON,
        [STORAGE_KEYS.verification]: this.verificationTOON,
        [STORAGE_KEYS.signal]: this.signalTOON,
        [STORAGE_KEYS.discovery]: this.discoveryTOON,
        [STORAGE_KEYS.pairingState]: this.pairingState || null,
        [STORAGE_KEYS.savedRoute]: this.pairingState
          ? normalizeSavedRoute({
              localIP: this.pairingState.localIP,
              wsURL: this.pairingState.wsURL
            })
          : null
      });
    }

    async publishRuntimeUpdate(reason) {
      await this.persistTransportState(this.runtimeConnectionState(), this.lastError);

      await runtimeSendMessage({
        type: 'OFFSCREEN_EVENT',
        reason,
        document_toon: this.buildDocumentTOON('active'),
        state_toon: this.buildSocketStateTOON(this.runtimeConnectionState(), this.lastError),
        tabs_toon: this.buildTabSnapshotTOON(),
        linked_devices_toon: this.linkedDevicesTOON,
        verification_toon: this.verificationTOON,
        signal_toon: this.signalTOON,
        discovery_toon: this.discoveryTOON
      });
    }

    getRuntimeState() {
      return {
        ok: true,
        state: this.pairingState
          ? {
              ...this.pairingState,
              bridgeReady: this.bridgeReady,
              bridgeState: this.bridgeState,
              bridgeMessage: this.bridgeMessage,
              peerReachable: this.peerValidated,
              peerState: this.currentPeerState(),
              peerDeviceID: this.remotePeerID
            }
          : null,
        offscreen: {
          document_toon: this.buildDocumentTOON('active'),
          state_toon: this.buildSocketStateTOON(this.runtimeConnectionState(), this.lastError),
          tabs_toon: this.buildTabSnapshotTOON(),
          linked_devices_toon: this.linkedDevicesTOON,
          verification_toon: this.verificationTOON,
          signal_toon: this.signalTOON,
          discovery_toon: this.discoveryTOON
        },
        signal: this.signalTOON
      };
    }

    async disconnect() {
      this.stopHeartbeat();
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
      this.clearConnectTimeout();
      this.clearValidationTimeout();

      if (this.socket) {
        try {
          this.socket.close(1000, 'manual_disconnect');
        } catch (_) {
        }
        this.socket = null;
        this.activeSocketURL = '';
      }

      this.peerValidated = false;
      this.preventReconnect = false;
      this.remotePeerID = '';
      this.connectionState = 'idle';
      this.signalTOON = '';
      this.pendingTOONs = [];
      this.peerURL = '';
      this.pairingState = null;
      await storageRemove([STORAGE_KEYS.signal, STORAGE_KEYS.savedRoute]);
      await storageSet({ [STORAGE_KEYS.document]: this.buildDocumentTOON('idle') });
      await this.persistTransportState('idle');
      return { ok: true };
    }
  }

  globalScope.TabSyncLocalLink = {
    STORAGE_KEYS,
    createController() {
      return new LocalLinkController();
    },
    decodeTOON,
    encodeTOON
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
