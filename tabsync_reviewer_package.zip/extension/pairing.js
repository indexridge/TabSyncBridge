(function attachPairingSession(globalScope) {
  'use strict';

  const extensionAPI = globalScope.chrome ?? null;
  const LOCAL_STORAGE_KEY = 'tabsync_pairing_session';
  const SESSION_STORAGE_KEY = 'tabsync_pairing_boot_id';
  const SESSION_TTL_MS = 5 * 60 * 1000;
  let memorySession = null;
  let memoryBootID = '';

  function localStorageArea() {
    return extensionAPI?.storage?.local ?? null;
  }

  function sessionStorageArea() {
    return extensionAPI?.storage?.session ?? null;
  }

  async function localStorageGet(key) {
    const area = localStorageArea();
    if (!area?.get) {
      return {};
    }

    try {
      return await area.get(key);
    } catch (_) {
      return {};
    }
  }

  async function localStorageSet(values) {
    const area = localStorageArea();
    if (!area?.set) {
      return false;
    }

    try {
      await area.set(values);
      return true;
    } catch (_) {
      return false;
    }
  }

  async function sessionStorageGet(key) {
    const area = sessionStorageArea();
    if (!area?.get) {
      return {};
    }

    try {
      return await area.get(key);
    } catch (_) {
      return {};
    }
  }

  async function sessionStorageSet(values) {
    const area = sessionStorageArea();
    if (!area?.set) {
      return false;
    }

    try {
      await area.set(values);
      return true;
    } catch (_) {
      return false;
    }
  }

  function deriveManualCode(seedValue) {
    let accumulator = 0;
    for (const character of String(seedValue || '')) {
      accumulator = (accumulator * 31 + character.charCodeAt(0)) % 1_000_000;
    }
    return String(accumulator).padStart(6, '0');
  }

  function sanitizeSession(value) {
    const sessionID = String(value?.sessionID || '').trim();
    const manualCode = String(value?.manualCode || '').replace(/\D/g, '').slice(0, 6);
    const createdAt = String(value?.createdAt || '').trim();
    const expiresAt = String(value?.expiresAt || '').trim();
    const bootID = String(value?.bootID || '').trim();

    if (!sessionID || manualCode.length !== 6 || !createdAt || !expiresAt || !bootID) {
      return null;
    }

    return {
      sessionID,
      manualCode,
      createdAt,
      expiresAt,
      bootID
    };
  }

  function isExpired(session) {
    const expiresAt = Date.parse(String(session?.expiresAt || ''));
    return !Number.isFinite(expiresAt) || expiresAt <= Date.now();
  }

  function createSession(bootID) {
    const sessionID = globalScope.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`;
    const createdAt = new Date().toISOString();
    const expiresAt = new Date(Date.now() + SESSION_TTL_MS).toISOString();

    return {
      sessionID,
      manualCode: deriveManualCode(`${bootID}:${sessionID}:${createdAt}`),
      createdAt,
      expiresAt,
      bootID
    };
  }

  async function getBootID() {
    if (memoryBootID) {
      return memoryBootID;
    }

    const stored = await sessionStorageGet(SESSION_STORAGE_KEY);
    const existingBootID = String(stored?.[SESSION_STORAGE_KEY] || '').trim();
    if (existingBootID) {
      memoryBootID = existingBootID;
      return memoryBootID;
    }

    memoryBootID = globalScope.crypto?.randomUUID?.() || `${Date.now()}-${Math.random()}`;
    await sessionStorageSet({ [SESSION_STORAGE_KEY]: memoryBootID });
    return memoryBootID;
  }

  async function getStablePairingCode(forceRefresh = false) {
    const bootID = await getBootID();

    if (!forceRefresh && memorySession && memorySession.bootID === bootID && !isExpired(memorySession)) {
      return memorySession;
    }

    const stored = await localStorageGet(LOCAL_STORAGE_KEY);
    const session = sanitizeSession(stored?.[LOCAL_STORAGE_KEY]);

    if (session && session.bootID === bootID && !isExpired(session)) {
      memorySession = session;
      return memorySession;
    }

    memorySession = createSession(bootID);
    await localStorageSet({ [LOCAL_STORAGE_KEY]: memorySession });
    return memorySession;
  }

  globalScope.TabSyncPairing = {
    LOCAL_STORAGE_KEY,
    SESSION_TTL_MS,
    getStablePairingCode
  };
})(typeof globalThis !== 'undefined' ? globalThis : window);
